The requests need to be forward or redirect to another page or url sometimes based on the type of the request or operation. Generally the request will be redirect to the home page after logging in the user. The request will be forward to the status page after doing some business logic.

Since the webcenter sites are running on the j2ee based application servers which support jsp technology. In JSP we use response implicit object to redirect to a page and jsp:forward tag is used to forward to a page. Lets see how the forward and redirect request in webcenter sites will be done.

### Forward

Oracle webcenter sites provides a tag to forward the request to another url.

`<render:satellitepage pagename="my/article/detail" args="c,cid" />`

or 

`<render:calltemplate tname="my/article/detail" args="c,cid" />`

### Redirect

Redirecting a request is a tricky part in oracle webcenter sites. The response.sendRedirect code doesn’t work in sites JSP. Because the response headers are committed early in the page evolution, so we can not set the return status code in jsp in sites.

Here is a best solution to achieve this task. We can control this at client side immediately after loading the webpage. In javascript we can set the condition to forward to the respective page/url. Return the below javascript code as the response from the sites’s jsp page.

Code of the sites’s jsp page
```jsp
//here code to prepare the url of home page by using render:gettemplateurl tag.
<script type="text/javascript">
window.location.replace('<%= ics.GetVar("homeUrl") %>');
</script>
```