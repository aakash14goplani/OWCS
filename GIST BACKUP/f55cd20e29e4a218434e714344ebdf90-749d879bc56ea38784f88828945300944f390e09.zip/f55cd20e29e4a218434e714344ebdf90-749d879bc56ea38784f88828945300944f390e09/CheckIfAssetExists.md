```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ taglib prefix="asset" uri="futuretense_cs/asset.tld"
%><%@ page import="COM.FutureTense.Interfaces.*, com.fatwire.assetapi.data.*, com.fatwire.assetapi.*"
%><%
 /******************************************************************************************************************************
   *    Element Name        :  Practice/Automation/CheckIfAssetExists 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (21/06/2018) 
   *    Description         :  Checks if asset already exists in database 
   *    Input Parameters    :  c: required, name of asset (assetName): required
   *    Output              :  "true" if asset exists else "false"
 *****************************************************************************************************************************/
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if><% 
	
	String assetType = ics.GetVar("c");
	String site = ics.GetVar("site");
	String assetName = ics.GetVar("assetName");
	String pubid = "";
	ics.SetVar("assetExists", "null");
	
	if( Utilities.goodString(assetType) && Utilities.goodString(assetName) ) {
		
		try {
			String sqlPubId = "select id from Publication where name='" + site + "'";
			
			%><ics:logmsg msg='<%="SQL to fetch pubid: " + sqlPubId %>' severity="INFO" />
			<ics:sql table="Publication" listname="siteNameList" sql='<%=sqlPubId %>' /><%
		
			if(null != ics.GetList("siteNameList") && ics.GetList("siteNameList").hasData()) {
				pubid = ics.GetList("siteNameList").getValue("id");
			}
		 	String sqlName = "select c.id from " + assetType + " c, AssetPublication ap where c.status !='VO' and LOWER(c.name)=LOWER('" + assetName + "') and c.id=ap.assetid and ap.pubid=" + pubid;
			
			%><ics:logmsg msg='<%="SQL to fetch duplicate asset id: " + sqlName %>' severity="INFO" />
			<ics:sql table='<%=assetType + ", AssetPublication" %>' listname="outputList" sql="<%=sqlName %>" /><%
			
			if(null != ics.GetList("outputList") && ics.GetList("outputList").hasData()) {
				
				%><ics:logmsg msg='<%="Row returned from sqlName: " + ics.GetList("outputList").numRows() %>' severity="INFO" /><%
				
				String fetchedAssetId = ics.GetList("outputList").getValue("id");
				if(Utilities.goodString(fetchedAssetId)) {
					ics.SetVar("assetExists", fetchedAssetId);
					
					%><ics:logmsg msg='<%="setting *assetExists* variable to: " + fetchedAssetId %>' severity="INFO" /><%
				}
			}
		} catch (Exception e) {
			out.println("<div class=\"error\">Exception Occured in CheckIfAssetExists element: " + e.getMessage() + "</div><br/>");
		}
		
		%><ics:logmsg msg='<%="Final variable value: " + ics.GetVar("assetExists") %>' severity="INFO" /><%
	
	} else {
		out.println("<div class=\"error\">AssetType: " + assetType + " or AssetName: " + assetName + " missing in CheckIfAssetExists element</div><br/>");
	}	
%></cs:ftcs>
```