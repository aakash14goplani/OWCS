# Assets as classes, Templates as methods

When you design a content model and its related templates in FatWire, it helps thinking  you should consider Asset types as classes, and Templates as methods, that apply to those classes to render the content. Although it may sound odd, here a few examples.   


Let's start from a Page (that is a common asset you normally use as is). Which methods can you apply to this class? Well, methods here always refers to rendering methods.

It is common you want to display a page like a full page. Because normally header and footer are managed by the Layout, you can call the method Body. So Page/Body is a template (working like a method) that renders a Page in full, as a body. Another case that happens is that I just want to render the Page  like a simple Link. Here another method can help, let's call it  Page/Link. It is also very common you want also render a Summary with Page/Summary.


Now let's consider another type, for example a user defined type like Article; if it is a class, which methods we should use? Obviously we can think of something like before: Article/Body to render an article as the body of a full webpage, Article/Link to render it as a simple linke, and Article/Summary to render just a summary of it.


### The underlying idea

Now, it is important to understand that we should use common method names, and  for a precise reason: if you add to a container an Article or a Page, and you want  to render, for example, a list of summaries to Page or Articles, you can do it without having to write  code to distinguish the different cases.

So, good rules to follow when designing (or naming) the templates are:

1. decide and use a common naming conventions for templates. For example Summary,Link,Body etc
2. give a type, and better a subtype, to each template you use
3. reserve the "apply to many type templates" only to a few templates that (like the Layout) really apply to different types
4. You have to consider that whey you perform a "call template", calling the same template name for different types must template equivalent in function  for that type.


Put simply, a call template for "Summary" must call the Page/Summary if the requested asset is a Page; or Article/Summary if the page is an Article. And both must produce valid html, good for any summary in the design of your site.


This is one of the most powerful (and misunderstood) feature in Fatwire ContentServer.