Controlling presentation includes being able to select which page layout to select to render an entire web page, being able to select which content layout to select to render an asset in a given portion of a web page, and being able to select arguments sent to a pagelet template.   

If you want to allow non-technical users to choose which presentation (i.e. which pagelet template) to use in order to render a particular  page, you must define a slot. The `slotname` attribute value can be any `string`, but it must be unique across all templates of a given site.   

To define a slot, add the insite taglib directory.   

`<%@ taglib prefix="insite" uri="futuretense_cs/insite.tld" %>`   
and add the `slotname` attribute to `insite:calltemplate` tag :   
```jsp
<insite:calltemplate 
      slotname="HelloSlot"
      ...
      tname="HelloDetail"
      args="c,cid" />
```   

### Controlling Template Arguments   

This section provides an example of controlling template arguments. We modify the template to accept an extra argument called `image-width` which will be used to give specific width to the image 200px, 300px or 400px.   

The process is as follows:   

* The "image-width" argument has to be registered as a legal argument for the given template. If this step is skipped, contributors will not be able to set its value from the editorial UI.   

* In order to make sure that caching works properly, the new argument has to be declared as a cache criteria.   

* Finally, the template code is modified in order to use the newly defined argument.   

_Note:_
On Using Eclipse with the WebCenter Sites Developer Tools plug-in: When editing a Template asset from the Admin interface, if this Template is also opened in WSDT at the same time, you must remember to synchronize your changes to the WSDT workspace. Template metadata stored in the WSDT workspace will otherwise override the values entered from the web interface.   

1. Declare "image-width" as a legal argument of given template asset.

   * From the **Admin** interface, edit the required template asset.

   * For **Legal Arguments**, enter `image-width` and click Add Argument.

   * Select Required.

   * For **Argument Description** enter _Image Width_.

   * For **LegalValues**, add the following descriptions:
      + For **Value**: 200px enter **Value Description**: 200px.
      + For **Value**: 300px enter **Value Description**: 300px.
      + For **Value**: 400px enter **Value Description**: 400px.   

   * Click Save.   
   
2. Remember to sync the change made in WebCenter Sites with the WSDT workspace.   

3. Use the WebCenter Sites Developer Tools plug-in to add `image-width` to the set of cache criteria.   

   * Right-click the working Template in the Sites workspace.   

   * Select Properties.   

   * In the **Cache Criteria** field, append `image-width` to the end of the list.   

   * Click **Submit**.   

4. Optionally, a default value could be defined by using the **Additional element parameters** field and specifying the following value, for instance: "image-width=300px".   

5. Modify the working pagelet template code
```jsp
<insite:edit field="practice_image" assetid='<%=ics.GetVar("cid")%>' assettype='<%=ics.GetVar("c")%>' list="imageList" column="value" >
   <img src='<%=ics.GetVar("imageURL")%>' width='<%=ics.GetVar("image-width")%>' height="auto" />
</insite:edit>
```


### References   
   
1. [Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_siteassets.htm#WBCSD1945)   
2. [fatwiredev Blog](https://fatwiredev.blogspot.in/2013/11/example-10-presentation-editing.html)