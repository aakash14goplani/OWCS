# What is Assembler?

WebCenter Sites URL generation tags (`<satellite.link>`, `<satellite.blob>`, `<render.getpageurl>`, `<render.getbloburl>`, `<render.satelliteblob>`, `<rendergettemplateurl>`) are used to construct a link to a WebCenter Sites resource, such as a _page_ or a _blob_. The data, such as tag attributes and nested argument tags which you specify when using the tag, is converted into an abstract object called a **URL definition**. The URL definition is passed into the URL assembler.

### Assemblers available in Webcenter Sites:

Two assemblers are installed with WebCenter Sites, but you have the option of creating your own assemblers in order to directly control the appearance of your URLs.

a. **Query Assembler**:

The Query Assembler creates URLs with query strings. It is the default assembler, and it is automatically registered in WebCenter Sites. Therefore, until you make any modifications (such as changing the default assembler or overriding the default in link tags), Query Assembler will be used to generate all URLs.

b. **QueryAsPathInfo Assembler**:

The QueryAsPathInfo Assembler does not use query strings. Instead, the QueryAsPathInfo Assembler encodes the query string and appends it to the end of the servlet name. The benefit of this assembler is that it creates URLs that can be indexed by search engines. The QueryAsPathInfo Assembler is not automatically registered with WebCenter Sites.

Before you can use the assemblers you create, you must first register them with WebCenter Sites (`ServletRequest.properties`)

Property Name | Property Value
--- | ---
uri.assembler.0.classname | com.fatwire.cs.core.uri.QueryAsPathInfoAssembler
uri.assembler.0.shortform |	pathinfo
uri.assembler.1.classname |	com.fatwire.cs.core.uri.QueryAssembler
uri.assembler.1.shortform |	query

How it works?

If a URL has been created using an assembler other than the default assembler, then the default assembler cannot disassemble the URL. At that point, the next highest ranked assembler attempts to disassemble the URL. If it succeeds in creating a definition, then the assembler engine is said to have “discovered its assembler,” and the definition is converted into parameters for processing. If the next highest ranked assembler fails to disassemble the URL, the third highest ranked assembler is called upon to disassemble it.

This process continues until the URL is successfully disassembled.

**Note**: URL assemblers are only invoked on GET requests

**Modifying Link Tags**: `<satellite:link pagename=“example” assembler=“pathinfo” />`   

### References
[mkbansal](https://mkbansal.wordpress.com/2012/09/19/oracle-webcenter-sites-url-assemblers/)  