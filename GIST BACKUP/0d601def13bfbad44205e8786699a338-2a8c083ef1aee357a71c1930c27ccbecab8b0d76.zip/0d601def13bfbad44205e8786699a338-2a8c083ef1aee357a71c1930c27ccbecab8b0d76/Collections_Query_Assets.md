### Rendering Collections   

1. Load the collection using `asset:load` tag.
2. Fetch the collection list using `asset:children` tag.   

```jsp
<asset:load name="Collection" type='<%=ics.GetVar("c") %>' objectid='<%=ics.GetVar("cid") %>' site='<%=ics.GetVar("site") %>'/>
<asset:children name="Collection" list="queryList"/>
 ```   
 
 ### Rendering Query Assets   
 
 1. Load the collection using `asset:load` tag.
 2. Query can be written in two ways
    + Using `database query` option, it returns `sqlquery` after using `asset:load`.
    + Using `element` option, it returns `element` after using `asset:load`.
 
 ```jsp
<asset:load name="QueryAsset" type='<%=ics.GetVar("asset_type")%>' objectid='<%=ics.GetVar("asset_id")%>'/>
<asset:scatter name="QueryAsset" prefix="query"/>
Element : <ics:getvar name="query:element"/>
SQL Query : <ics:getvar name="query:sqlquery"/>
```  

### References   

[Collections and Query Assets - Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/creating_collections.htm#WBCSD2060)