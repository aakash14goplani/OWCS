# Getting the Parent Page of an Asset

**Problem: you need to know where an asset has been placed in the SitePlan.**

The solution is basically looking into the table `AssetRelationTree` (that stores  all the  parent-children relationship) using the `TreeManager` (an internal server of ContentServerm  accessible with a tag  available in the tag libriry).

How to find the parent pages of a given asset?

The problem, expressed in a more technical way, is: given an asset identified by his content id (stored in the "cid" variable),  find the id of all the pages having that asset as a children. My Solution follows.

Step 1: locate a list of all the children assets in the `AssetRelationTree` with the `TreeManager`

```jsp
<ics:treemanager>
  <ics:argument name="ftcmd" value="findnode"/>
  <ics:argument name="treename" value="AssetRelationTree"/>
  <ics:argument name="where" value="oid"/>
  <ics:argument name="oid" value='<%=ics.GetVar("cid")%>'/>
</ics:treemanager>
```
Step 2: extract parents using their node id (nid) and getparent

The returned list is only a list of the available relations.
Using the nid of such a relation you can look for the parent.

This is the code to retrieve the parents:

```jsp
<ics:copylist from="AssetRelationTree"  to="List"/>
<ics:listloop listname="List">
  <ics:listget listname="List" fieldname="nid"  output="nid" />
  <ics:treemanager>
    <ics:argument name="ftcmd" value="getparent"/>
    <ics:argument name="treename" value="AssetRelationTree"/>
    <ics:argument name="node" value='<%=ics.GetVar("nid")%>'/>
  </ics:treemanager>
  <!-- now do something with the found id - see Step3 -->
</ics:listlooop>
```
Note that I copied the list from  the first `TreeManager` call because another call to `TreeManager` will  store the result always in the same `AssetRelationTree` list. Since I have to call the TreeManager again I am preventing the list to be overwritten and I am working on a copy.

Step 3: grab parents and do something with them.

Inside the loop in Step2, you will get all the parents of the asset.

You can retrive the id of a parent with

`<ics:listget listname="AssetRelationTree" fieldname="oid" output="p"/>`
also you can read the type with

`<ics:listget listname="AssetRelationTree" fieldname="otype" output="ptype"/>`
but it should be always "Page". Now you can do what you want with the parent (in my case, I was just using the retrieved parent to set the p parameter).

Bonus: how to do it all with a simple query
Well, you could retrieve the parent with this simple database query, tested with jumpstart and hypersonic:

```sql
select otype,oid from AssetRelationTree where nid in
(select nparentid from AssetRelationTree where oid = 123456789)
where 123456789 is the cid of the asset you are looking for its parents.
```

However, as a general rule, I do not trust too much explicit queries because they are database dependent.