Flex assets means **FLEXIBLE ASSETS**. Meaning, that we can add fields at any moment to the asset. You can update your site at any time, adding new fields, without disturbing the existing content.

**FLEX ASSET MODEL** has been the favorite model for the developers who concentrate on developing **WEB EXPERIENCE MANAGEMENT** applications. The Flex model helps in achieving the website’s goal of targeting the audience/visitors, and hence improving the overall business by the websites. The Flex Asset Model is the choice of developers, when the data has the following characteristics:

1. **MANY ATTRIBUTES:** The assets have very large number of attributes, like some hundreds of attributes.
2. **NEEDS HIERARCHY:** The assets need to inherit attributes from their parents.
3. **UNPREDICTED ATTRIBUTES:** This means that we know that we cannot predict what attributes might be necessary in the future.
4. **NAVIGATION:** Visitors browse your site by navigating through “drill-down” searches that are based on the attribute values of your data.
5. **ENGAGE:** You want to use Engage.

If implemented correctly, the Flex asset model yields major benefits for the business through websites.

But, to build a Flex asset model, a lot of complex work needs to be done. The following needs to be kept in mind, while choosing this Flex asset model.

* **COMPLEX DATABASE:** The underlying database structure of flex assets is pretty complex.
* **SLOW RATE:** Asset creation is slower that Basic assets.
* **SEARCH:** Searching attributes requires complex code.

### References

[kksays](https://kksays.wordpress.com/2012/02/09/when-to-use-the-flex-asset-model-in-fatwire/)