The **cscacheinfo** and **sscacheinfo** fields of the SiteCatalog are populated with a CacheInfo string. We are now going to discuss about the syntax of the CacheInfo String.

It is a two-part, comma separated string.

* The first part tells whether the page should be cached or not.
* The second part tells about the expiration.

Following is the screenshot which we can see while creating a Template / SiteEntry:

 ![cache 1](https://github.com/aakash14goplani/OWCS/blob/master/images/cache_1.png)


## PART – I

The first part in CacheInfo must be one of the following values:

1. False – If the value is false, then the page will not be cached.
2. True – If the value is true, then the page will be cached according to the information provided in the second element.
3. (blank) – If the value is blank, then Content Server will consult the `uturetense.ini` property `cs.alwaysusedisk`. If this property is set to yes, then a blank value will be interpreted as having the same behavior as true. If the value is set to no , then a blank value will be interpreted as having the same behavior as false.
4. `*` – If the value is `*`, then it will be treated as blank.

## PART – II

The Second part tells us when the cached page should be removed from cache. If the first element is false, then the second element is ignored. There are Five ways of specifying the expiration of a page.

1. **Page Timeout:**  If the second element starts with `~`, then the value following the `~` must be an integer. This is the number of minutes a page will remain in cache. A negative value or `0` indicates that the page will never expire.

2. **Absolute Moment in Time:** If the second element starts with `@`, then the value following the `@` must be a date expressed in the JDBC date string format, namely, `YYYY-MM-DD HH:MM:SS`. After the particular date and time, the cached pages will be flushed from cache.

3. **Time Pattern:** If the second element starts with `#`, then the value following the # must be a valid TimePattern string as defined by the public class `COM.FutureTense.Util.TimePattern`. It allows you to specify expiration at a specific time or times every day, month,week, day of week, and year.

4. **Wildcard:** If the second element is `*`, then the page will assume a timeout expiration behavior, as described in Timeout above. The timeout value will be read from `cs.pgCacheTimeout` property of `futuretense.ini` file.

5. **Blank:** If the second element is blank, then it assumes the same behavior of `*`.

### References

[kksays](https://kksays.wordpress.com/2012/11/29/cacheinfo-string-in-fatwire-oracle-webcenter-sites/)