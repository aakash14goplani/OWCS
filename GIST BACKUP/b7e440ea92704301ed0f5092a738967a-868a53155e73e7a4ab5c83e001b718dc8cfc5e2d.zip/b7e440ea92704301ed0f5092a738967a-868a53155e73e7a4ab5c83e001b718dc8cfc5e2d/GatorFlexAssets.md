# Gator and Flex Assets

While Xcelerate provide the basic functions for creating and editing asset, the more powerful content modeling features are powered by the component called Gator.   


To better understand  which features it provides, in the installer code it is still referred as CatalogCentre, while Xcelerate is referred as ContentCentre. So it looks like to be something good to build Catalogs.   


Basically, Gator extends Xcelerate providing a rich and flexible Content Modeling feature called "Flex Assets". Apparently, the original reason because Flex Assets were introduced was to support the implementation of ecommerce sites. In fact, an e-commerce site usually requires lot of different products whose definition change often and unpredictably. Definitely, to support those requirements, Gator and its Flex Assets provide:
   * ability to upgrade content model easily often, just publishing it
   * a rich taxonomy, since products need to be organized in categories and subcategories
   * an user interface to manipulate content definitions, not just content
   * Flex Assets differences from Basic Assets   


Basic Assets define assets with a descriptor file, while Flex Assets define assets using other assets. In fact, we don't talk normally of "flex assets" but of Flex Families, because Flex Assets are really a group (or family) of assets working together to reach a common goal.   


Creating a new family will  indeed create 6 different types of assets. It can be at a first sight confusing, but can be understood thinking that some of those assets are "structural" (define the type of the content) while only 2 of them defines actual content. Basically, structural assets replace the property descriptor file used in Basic Asset.   


Second, Basic Assets define content once and for all, while Flex Assets define content in an incremental way. We have seen that for a Basic Asset you have to create a descriptor that will list properties. For Flex Assets you instead have to create attributes, that are assets too, then  you put together the asset using a Content Definition asset. An user interface is available to create attributes and assembling definitions.   


This means mostly that while Basic Assets can be upgraded only recreating them from scratch or doing some alterations to the database schema, Flex Assets definition can be actually upgraded just publishing attributes and definitions.   


Using just Basic Assets you cannot directly create hierarchies (you can  only using some special coding). There are only some built-in hierarchies like the SitePlan. Flex Assets make hierarchies very easy to build using Parents,  that are always part of a new family definition. Furthermore, parents are configurable just like content, creating Parent Definitions.   


When you create the content, you can place a content under a parent. Furthermore, a parent can be children of another parent, creating a tree. Using this parent-children relationship you can easily create complex hierarchies, that are very useful when the user needs to organize a large amount of content.   


A parent has the special feature that all its  attributes are inherited by  its  children content. This feature is largely used to create custom hierarchies. Actually given the simplicity, is a bit unusual to find a flex family without parents, since they  are very easy to use.   


Flex Families Components
So, let's recap what we have said so far. 
1. When you create a new Flex Family, you go into the Admin panel in the user interface
2. you  define a new Attribute type, Content_A in the picture. Attributes are  fields of the content,  the building blocks.
3. Then, you will have to create definitions to put attributes together. So basically, to define an Article with a title, an author and a body, you have to create 3 attributes corresponding to the fields, then one Content Definition (a Content_CD asset for the family in the picture) named Article assembling the attributes you have declared. You can create different content definitions, each of them will define a different Content type.
4. Now finally you can create content, this means you will create an actual Flex Asset of type Content, and you will then associate one content definition, like the Article Content_CD you may have created in the previous step.
5. You can also create assets useful to organize content in hierarchies. This works in the same way as the content. First you create a parent definition, assembling attributes, then you can use the parent definitions to create parents. The additional step is that you can now associate content  to parent to get a hierarchy. The whole hierarchy can then be displayed in the WCS user interface.