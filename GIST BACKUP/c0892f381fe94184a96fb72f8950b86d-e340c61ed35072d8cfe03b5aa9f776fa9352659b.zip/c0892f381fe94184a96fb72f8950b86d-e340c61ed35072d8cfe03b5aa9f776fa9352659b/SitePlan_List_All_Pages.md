```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="asset" uri="futuretense_cs/asset.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ taglib prefix="siteplan" uri="futuretense_cs/siteplan.tld"
%><%@ page import="COM.FutureTense.Interfaces.*"
%><%
 /******************************************************************************************************************************
   *    Element Name        :  ListAllPlacedPages 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (24/06/2018) 
   *    Description         :  Retrieve the list of all placed pages ids 
   *    Input Parameters    :  pid: required (page id)
   *    Output              :  list of all placed pages ids
 *****************************************************************************************************************************/
%><cs:ftcs>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=Utilities.goodString(ics.GetVar("pid")) %>'>
		<ics:then>
			<asset:load name="ParentRootNode" type="Page" objectid='<%=ics.GetVar("pid") %>'/>
			<asset:getsitenode name="ParentRootNode" output="PageNodeId"/>
			<ics:if condition='<%=Utilities.goodString(ics.GetVar("PageNodeId")) %>'>
				<ics:then>
					<siteplan:load name="ParentNode" nodeid='<%=ics.GetVar("PageNodeId")%>'/>
					<siteplan:listpages name="ParentNode" placedlist="PlacedPages" />
					<ics:if condition='<%=null != ics.GetList("PlacedPages") && ics.GetList("PlacedPages").hasData() %>'>
						<ics:then>
							<ics:listloop listname="PlacedPages">
								PageName - <ics:listget fieldname="PageName" listname="PlacedPages"/><br>
								ParentName - <ics:listget fieldname="ParentName" listname="PlacedPages"/><br> 
								NodeLevel - <ics:listget fieldname="NodeLevel" listname="PlacedPages"/><br>
								PlacedValue - <ics:listget fieldname="PlacedValue" listname="PlacedPages"/><br>
								AssetType - <ics:listget fieldname="AssetType" listname="PlacedPages"/><br>
								Id - <ics:listget fieldname="Id" listname="PlacedPages"/><br>
								HasChildren - <ics:listget fieldname="HasChildren" listname="PlacedPages"/><br>
								Nid - <ics:listget fieldname="Nid" listname="PlacedPages"/><br><br>
							</ics:listloop>
						</ics:then>
						<ics:else><%
						out.println("PlacedPages null: " + ics.GetList("PlacedPages") + "<br>"); 
						%></ics:else>
					</ics:if>
				</ics:then>
				<ics:else><%
				out.println("Error computing PageNodeId: " + ics.GetVar("PageNodeId") + "<br>"); 
				%></ics:else>
			</ics:if>
		</ics:then>
		<ics:else><%
		out.println("<b>Please provide page id</b>");
		%></ics:else>
	</ics:if>
</cs:ftcs>
```

<b>site specific</b>

```jsp
<device:siteplan site="[sitename goes here]" output="targetSitePlanId"/>
<asset:load name="sitePlanObject" type="SiteNavigation" objectid='<%=ics.GetVar("targetSitePlanId")%>'/>
<asset:getsitenode name="sitePlanObject" output="sitePlanId"/>
<siteplan:load name="thePubNode" nodeid='<%=ics.GetVar("sitePlanId") %>' />
<siteplan:listpages name="thePubNode" placedlist="placedPages"/>

<ics:listloop listname="placedPages">
     <ics:listget listname="placedPages" fieldname="Id">
</ics:listloop>
```