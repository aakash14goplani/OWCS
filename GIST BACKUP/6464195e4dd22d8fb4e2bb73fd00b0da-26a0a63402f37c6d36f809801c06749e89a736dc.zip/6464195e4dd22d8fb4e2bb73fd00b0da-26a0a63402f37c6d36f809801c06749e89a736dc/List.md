To loop a list we make use of `listloop` tag   


### JAVA
```java
IList list = ics.GetList("list_name");
int rows = list.numRows();
int cols = list.numColumns();
String columnName = "", columnValue = "";
out.println("Rows : " + rows + ", " + "Columns : " + cols + " for list " + list.getName() + " : " + list.hasData() + "<br/>");
for(int i=1; i<=rows; i++){
  for(int j=0; j<cols; j++){
    out.println("Is " + list.currentRow() + " last row : " + list.atEnd() + "<br/>");
    columnName = list.getColumnName(j);
    columnValue = list.getValue(columnName);
    out.println(columnName + " : " + columnValue + "<br/>");
    list.moveTo(i+1);
  }
}
```   

### JSP
```jsp
<ics:listloop listname="titleList">
  <ics:listget fieldname="value" listname="titleList"/><br/>
  <ics:listget fieldname="#curRow" listname="titleList"/><br/> // returns current row number
  <ics:listget fieldname="#numCols" listname="titleList"/><br/> // returns total number of columns
  <ics:listget fieldname="#numRows" listname="titleList"/><br/> // return total number of rows
</ics:listloop>
```  

### XML
```xml
<LOOP [FROM="START"] [COUNT="LOOP_TIMES"] LIST="abc" [UNTIL="END"]>
  <ICS.LISTGET LISTNAME="abc" FIELDNAME="value" OUTPUT="some_value" />
</LOOP>
```   
<table summary="" border="1" cellpadding="5" cellspacing="0">
  <caption></caption>
  <tbody><tr>
    <td valign="top">
<div><code>#numRows</code></div></td>
    <td valign="top">
<div>Number of rows in this list</div></td>
  </tr>
  <tr>
    <td valign="top">
<div><code>#curRow</code></div></td>
    <td valign="top">
<div>Current row in this list. </div></td>
  </tr>
  <tr>
    <td valign="top">
<div><code>#moreRows</code></div></td>
    <td valign="top">
<div>Boolean (true/false) to indicate whether there are more rows following the current row. </div></td>
  </tr>
  <tr>
    <td valign="top">
<div><code>#numCols</code></div></td>
    <td valign="top">
<div>Number of columns in this list. </div></td>
  </tr>
  <tr>
    <td valign="top">
<div><code>@&lt;colname&gt;</code></div></td>
    <td valign="top">
<div>Only used on lists that contain resultsets. Contents of the file in the specified column if the colname begins with "url".</div></td>
  </tr>
</tbody></table>   

### Documentation
[LOOP](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/XML/LOOP.html)   
[ICS.LISTGET](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/XML/ICS.LISTGET.html)   
[ics:listloop](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/ics-listloop.html)   
[ics:listget](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/ics-listget.html)
[TomRed Blog](https://www.tomred.net/fatwire/get-details-of-a-list.html)