### General steps to follow   

1. Get handle for `AssetDataManager` which will act as a gateway to interact with Assets.
2. Create unique AssetIdInstance using `AssetIdImpl` and `AssetId` from `c` and `cid` parameters, basis on which read operation would be performed.
3. Call `read()` method of `AssetDataManager` which actually performs read operation and return results.
4. Read results using appropriate interfaces such as `AssetData`, `AttributeData` etc. as per needs.  
5. Once you have all the results with you, you can loop each reult instance and modify the particular attribute's value as per need by calling `update()` method of `AssetDataManager` which actually performs update operation.

```jsp
<%@page import="java.util.ArrayList"%>
<%@page import="java.util.List"%>
<%@page import="com.openmarket.xcelerate.asset.AssetIdImpl"%>
<%@page import="java.util.Arrays"%>
<%@page import="com.fatwire.system.SessionFactory"%>
<%@page import="com.fatwire.system.Session"%>
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="asset" uri="futuretense_cs/asset.tld"
%><%@ taglib prefix="assetset" uri="futuretense_cs/assetset.tld"
%><%@ taglib prefix="commercecontext" uri="futuretense_cs/commercecontext.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="listobject" uri="futuretense_cs/listobject.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ taglib prefix="searchstate" uri="futuretense_cs/searchstate.tld"
%><%@ taglib prefix="siteplan" uri="futuretense_cs/siteplan.tld"
%><%@ page import="COM.FutureTense.Interfaces.*,
                   COM.FutureTense.Util.ftMessage,
                   com.fatwire.assetapi.data.*,
                   com.fatwire.assetapi.*,
                   COM.FutureTense.Util.ftErrors"
%>
<cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if>
<%
	try{
		Session sessionFactory = SessionFactory.getSession();
		AssetDataManager assetDataManager = (AssetDataManager)sessionFactory.getManager(AssetDataManager.class.getName());
		String assetType = "Article_C", assetId = "1374098706086";
		
		Iterable<AssetData> assetDetails = assetDataManager.read(Arrays.<AssetId>asList(new AssetIdImpl(assetType, Long.valueOf(assetId))));
    List<AssetData> assetDataList = new ArrayList<AssetData>();
    for (AssetData a : assetDetails)
    {
        a.getAttributeData("name").setData("Article Asset");
        assetDataList.add(a);            
     }
     assetDataManager.update(assetDataList); 
	}
	catch(Exception e){
		out.println("Exception Occured : " + e.getMessage() + "<br/>" + e);
	}
 %>
</cs:ftcs>
```   

### Refrence   

[Fatwiredev Blog - CURD](https://fatwiredev.blogspot.in/2015/03/example-13-create-update-and-delete.html)      
[Fatwiredev Blog - API](https://fatwiredev.blogspot.in/2015/03/example-12-rendering-basic-and-flex.html)   
[Asset API Tutorial - Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/asset_api_tutorial.htm#WBCSD2387)   