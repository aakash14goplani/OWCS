```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="asset" uri="futuretense_cs/asset.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ taglib prefix="siteplan" uri="futuretense_cs/siteplan.tld"
%><%@ page import="COM.FutureTense.Interfaces.*"
%><%
/******************************************************************************************************************************
   *    Element Name        :  DisplayBreadcrum 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (01/07/2017) 
   *    Description         :  Element that display breadcrum
   *    Input Parameters    :  Variables required by this Element : cid i.e. id of page asset
   *    Output              :  Display breadcrum
 *****************************************************************************************************************************/
%><cs:ftcs>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if>
	<html>
		<head>
			<title>BREADCRUM</title>
			<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
		</head>
		<body>
			<ics:setvar name="c" value="Page"/>
			<ics:if condition='<%=Utilities.goodString(ics.GetVar("cid"))%>'> 
				<ics:then><%
					String title = "";
					String URL = "";
					%><asset:load objectid='<%=ics.GetVar("cid") %>' name="currentpage" type="Page"/>			
					<%--load site node and ancestors of current page --%>
					<asset:getsitenode name="currentpage" output="nodeIDVariableName"/>
					<siteplan:load name="ParentNode" nodeid='<%=ics.GetVar("nodeIDVariableName") %>'/>
					<%-- Returns a list of the currently loaded site node's ancestors in the SitePlanTree --%>
				 	<siteplan:nodepath name="ParentNode" list="ancestors_list" /><%
				 	IList ancestors_list= ics.GetList("ancestors_list");
					int size= ics.GetList("ancestors_list").numRows();
					if(null!=ics.GetList("ancestors_list") && ics.GetList("ancestors_list").hasData()){
						%><ol class="breadcrumb"><%
							/* loop the list from current page to the parent page and fetch its name and url */
							for(int count=size; count>0; count--){
								ancestors_list.moveTo(count);
								String pageid = ancestors_list.getValue("oid");
								String pagetype = ancestors_list.getValue("otype");
								if("Page".equals(pagetype))	{
									%><asset:load objectid='<%=pageid %>' name="loadPage" type='<%=pagetype %>'/>
									<asset:get name="loadPage" field="template" output="templateName"/>
									<asset:get name="loadPage" field="name" output="pageName"/><%
									if(Utilities.goodString(ics.GetVar("templateName"))){
										%><render:gettemplateurl ttype="CSElement" tid='<%=ics.GetVar("eid") %>' outstr="aUrl" c='<%=pagetype%>' cid='<%=pageid%>' tname='<%=ics.GetVar("templateName")%>' /><%
										title = ics.GetVar("pageName");
										URL = ics.GetVar("aUrl");
										%><li><a href="<%=URL %>" ><%=title%></a></li><%
									}
								}
								ics.RemoveVar("templateName");
								ics.RemoveVar("pageName");
							}			 			
							/* Add Current page to breadcrumb */
							%><asset:load objectid='<%=ics.GetVar("cid")  %>' name="loadCurrentPage" type="Page"/>
							<asset:get name="loadCurrentPage" field="name" output="pageName"/><%
							title = ics.GetVar("pageName");
							%><li><%=title%></li>
						</ol><%
						ics.RemoveVar("pageName");
					}
				 %></ics:then>
				 <ics:else>
				 	<%out.println("Null cid passed => "  + ics.GetVar("cid")); %>
				 </ics:else>
			</ics:if>
		</body>
	</html>
</cs:ftcs>
```