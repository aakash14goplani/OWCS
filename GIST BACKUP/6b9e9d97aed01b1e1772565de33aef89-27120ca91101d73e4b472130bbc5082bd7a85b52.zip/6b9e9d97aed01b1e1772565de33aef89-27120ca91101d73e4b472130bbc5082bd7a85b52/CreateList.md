### Create List

```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="listobject" uri="futuretense_cs/listobject.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid")!=null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if>
	<%-- create list --%>
	<listobject:create name="customList" columns="id,name"/>
	<%-- create rows and add values to columns --%>
	<listobject:addrow name="customList">
		<listobject:argument name="id" value="1"/>
		<listobject:argument name="name" value="one"/>
	</listobject:addrow>
	<listobject:addrow name="customList">
		<listobject:argument name="id" value="2"/>
		<listobject:argument name="name" value="two"/>
	</listobject:addrow>
	<listobject:addrow name="customList">
		<listobject:argument name="id" value="3"/>
		<listobject:argument name="name" value="three"/>
	</listobject:addrow>
	<%-- convert listobject to actual list --%>
	<listobject:tolist name="customList" listvarname="simpleCustomList"/>
	<%-- loop the list to see output --%>	
	<ics:listloop listname="simpleCustomList">
		<ics:listget fieldname="id" listname="simpleCustomList"/> : 
		<ics:listget fieldname="name" listname="simpleCustomList"/><br/> 
	</ics:listloop>
</cs:ftcs>
```