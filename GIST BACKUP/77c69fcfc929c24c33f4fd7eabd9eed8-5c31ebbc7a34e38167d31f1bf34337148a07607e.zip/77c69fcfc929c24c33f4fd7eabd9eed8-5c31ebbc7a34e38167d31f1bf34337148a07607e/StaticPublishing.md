The STATIC Publishing method, other wise called as **EXPORT TO DISK** publishing method is a best option, especially when we want to export the files to the file system on the same machine on which the content server is residing. It exports the rendered html files (or any other files that are approved) to the location specified by the user. For example, if we want to export the html, css, js, etc files to an application server residing on the same machine as the content server, we should follow the Static Publishing method. In this topic, we are going to discuss how we should create a static destination, and how to publish (export) the files.

### CREATION OF STATIC PUBLISH DESTINATION:

The following steps are involved in the creation of a **STATIC PUBLISHING DESTINATION**:

1. Login to the Advanced user interface.
2. Go to the admin tab of the tree.
3. Expand **PUBLISHING** -> **DESTINATIONS**.
4. Click on **ADD NEW**. The following screen appears:

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_1.png)

4. In the **DELIVERY TYPE** drop down, select **EXPORT TO DISK: EXPORT WEB FILES TO DISK**.
5. Enter a name for the publishing destination in **NAME** field
6. The **BASE DIRECTORY** is the directory into which the files will be exported. For Jump Start kit, the following is the default location into which the files will be exported: `<Drive>:\FatWire\JSK\7.5Patch5\ContentServer\7.5.5\export`. If we give a name, a new directory will be created under the export folder specified above.
7. Select the roles which approve the assets for publishing to this location.
8. Select the roles which can publish to this destination.
9. Select the sites for which this destination will be available.
10. Click on **ADD NEW DESTINATION** button in the bottom.

### APPROVING THE ASSETS:

After the asset is created (lets take a PAGE asset here) , and a default template is assigned, we need to **APPROVE** the asset for making it available for PUBLISH.

To approve an asset, click on **INSPECT** action item of the asset (a Page here). Then click on MORE drop down list, and then click on **APPROVE FOR PUBLISH**. Check the below screen for the same.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_2.png)

Now, The next step to proceed with is to select the Publishing destination(If not created earlier, check out this link for creation of Static Publishing Destination). Select the appropriate publishing destination, if you have created more than one. Then click on the Approve button. Check the below screen for the same.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_3.png)

If the asset has any dependencies, those dependencies have to be approved first, before approving this asset.

That’s it.. The asset is Approved.

### SETTING STATUS OF ASSETS:

If the assets are published directly, with out setting a specified file name, they will be exported with the **ASSET'S ID** by default. To avoid that, we need to specify a user friendly name. The **STATUS** screen helps us in setting a user friendly name for the asset, path for the asset (under the exported directory), and a starting point for the asset.

For setting the status, click on **STATUS** option of the **MORE** drop down menu. Then the following screen appears. Click on the **SPECIFY PATH/FILENAME, START POINTS** link in the appropriate publishing destination.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_4.png)

The next screen is the place where we need to set the above discussed (Path, File name, Starting points).

1. Specify the Path and filename.
2. If the asset needs to be published, it needs to be a starting point.  For example, if Page is a starting point, then the all the images, css, etc will automatically be exported by the page.
3. Select the template and the wrapper page.
4. Click on Save.

Check the below screen for the same.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_5.png)

### PUBLISHING THE ASSETS:

Now, the final thing to do is to publish the assets. Click on the **PUBLISHING** option in the top of the work area. The following screen appears. Select the appropriate publishing destination. Check the below screen for the same.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_6.png)

The following screen appears next. In that, we need to click on **PUBLISH** button.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_7.png)

To make sure that the files are exported correctly, we need to go to the export location, and check whether they are exported properly or not.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/stat_pub_8.png)


### References

* [kksays 1](https://kksays.wordpress.com/2012/01/19/static-publishing-in-fatwire/)
* [kksays 2](https://kksays.wordpress.com/2012/01/19/static-publishing-in-fatwire-part-2/)