A WRAPPER PAGE in FATWIRE is an ELEMENT (a CSElement, infact) that is called to perform the logic on the content server. Its sole purpose is to perform logic that must always be performed on Content Server even in a fully cached environment.

Following are few of the usages of a wrapper page:

1. Checking security measures
2. Setting default locale
3. Getting the current locale
4. Setting default values for parameters
5. Validating URL
6. Redirecting pages accordingly, etc.

The wrapper page (CSElement) is usually not cached, while the Layout (template) usually is cached.

Creation of a wrapper page is a two step process.

1. A CSElement should be created.
2. A SiteEntry that points to the previously created CSElement. The SiteEntry must be declared as a “Wrapper Page”. 
Untitled

When you have a wrapper page created, you can even remove the external accessibility of the Layout.  In this case, the wrapper page will act as the ONLY entry point for a site.

So, when you create a WRAPPER PAGE in your implementation, what ever the page you view, the request will go to the WRAPPER PAGE first. Then the control will be passed to the respective pages (According to what we code in the wrapper). Hence, WE ARE NOT invoking the wrapper page manually. The wrapper page is getting invoked automatically by the content server.

In general, it is a good and common practice to implement a wrapper page and call it, rather than calling the layout page directly.

### References

[kksays](https://kksays.wordpress.com/2013/02/04/wrapper-page-in-fatwire/)