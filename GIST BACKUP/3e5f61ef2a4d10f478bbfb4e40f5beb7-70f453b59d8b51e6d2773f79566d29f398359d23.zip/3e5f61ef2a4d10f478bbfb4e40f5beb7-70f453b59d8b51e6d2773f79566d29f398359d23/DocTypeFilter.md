The DocType Flex Filter is one of the four filters which are supplied by WebCenter Sites. It is the short form for DOCUMENT TYPE.

The DocType filter is used to know the file-types (for example pdf, doc, etc..), mime-types (for example application/pdf, etc..) of a particular document. Knowing the file types and mime types of a document are important in some situations. This filter could be used in such situations.

### CREATION OF ATTRIBUTES:

First Things First. Create the following attributes, that would be utilized by the filter.

1. **SampleDocument** – (BLOB)

2. **SampleDocumentFileType** – (STRING)

3. **SampleDocumentMimeType** – (STRING)

### CREATION OF FILTER:

1. Go to the Filter creation screen.

2. Enter the **Name** and **Description** of your choice.

3. In the **FILTER** drop down, select **DocType**, and click on **GET ARGUMENTS** button.

4. In the **ARGUMENTS** section, in the name drop-down, select each of the options, and enter the values as follows:

* ATTRIBUTE TO HOLD DERIVED FILETYPE  –  **SampleDocumentFileType**
* ATTRIBUTE TO HOLD DERIVED MIMETYPE – **SampleDocumentMimeType**
* INPUT ATTRIBUTE NAME – **SampleDocument**

5. Save it.

6. Add the Filter to the content definition.

### TESTING THE DOCTYPE FLEX FILTER:

1. Go to the asset creation screen, select the content definition for which you have added the filter.

2. Give a name.

3. Upload a document. Say a sample PDF document.

4. Save it. Click on Inspect. You will be able to see the uploaded document’s FILE TYPE & MIME TYPE. Check the below screen.

We haven’t added the **SampleDocumentFileType** & **SampleDocumentMimeType** in the content definition. But still they have appeared in the Asset Inspection Screen. Coz, these attributes are added by the **DOCTYPE FLEX FILTER**.

### References

[kksays](https://kksays.wordpress.com/2012/11/02/doctype-flex-filter-in-oracle-webcenter-sites-fatwire/)