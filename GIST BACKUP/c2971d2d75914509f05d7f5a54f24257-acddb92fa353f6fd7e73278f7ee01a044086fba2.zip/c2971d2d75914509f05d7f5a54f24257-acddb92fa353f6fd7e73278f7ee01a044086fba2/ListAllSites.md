### Retrieving a list of FatWire sites (Publications)

* This code snippet lists all the FatWire sites on an App Server.   
* This can be used in designing custom forms where you want the user to select the site from a list.

### General steps to follow:

1. Add the Publication tag Library using `<%@ taglib prefix="publication" uri="futuretense_cs/publication.tld" %>`. This makes the functionality available using the publication prefix.

2. We use the tag `publication:list` to retrieve the list of sites and the list attribute takes the output variable name to assign the list to.

3. We then loop through the list created by passing the list name _pubs_ into the `listname` attribute of the `ics:listloop` tag. 

4. We can then access a number of attribute of the site including the `ID`, `Name` and `Description` using `ics:listget` tag passing the name into `listname` attribute and the name of the field you want in the `fieldname` attribute.

5. In this example we retrieve the `ID` and `Name`.

```jsp
<publication:list list="pubs"/>
<ol>
<ics:listloop listname="pubs">
 	<li>
	    ID : <ics:listget listname="pubs" fieldname="id"/>, 
	    Name :<ics:listget listname="pubs" fieldname="name"/>
 	</li>
</ics:listloop>
</ol>
```