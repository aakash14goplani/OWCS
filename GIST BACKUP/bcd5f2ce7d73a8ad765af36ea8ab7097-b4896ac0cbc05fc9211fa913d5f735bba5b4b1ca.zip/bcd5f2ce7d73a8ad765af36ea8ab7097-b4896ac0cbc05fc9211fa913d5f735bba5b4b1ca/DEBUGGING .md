### DEBUGGING   

* At any and all stages of development debug text in useful for locating & resolving errors or simply tracking progress.
* FatWire's main log is called the **FutureTense.txt**. 
* This log can be written to from either the JSP or XML classes using the `ics` library.
* To output debug text to **FutureTense.txt** you can use `ics:logmsg`. 

### Important

* If there are multiple developers developing at the same time it is advisable to enable Browser based logging which output all enabled output to a user specific file based on the users ip address. eg. `futuretense_ip_address.txt > futuretense_192.168.1.20.txt`. 
* This allows each user to work with their own errors and ignore the errors of other developers.
* To enable user specific debugging open the Property editor and edit **futuretense.ini** setting `ft.dbl=yes`.
* This process applies when enabling all debugging settings, find the property in **futuretense.ini** and change the value associated.
* The opposite is `true` for disabling debugging. To disable set the value of the property to `no`.

To enable debugging in java files and JSPs files open the Property editor and edit **futuretense.ini** setting `ft.debug=yes`. 

```
boolean isDebugEnabled = ftMessage.truestr(ics.GetProperty("ft.debug");
if (isDebugEnabled){
    ics.LogMsg("Your Debug Text Here");
}
```
* It is important to note that `ics.LogMsg()` will output your log msg regardless of the value in the property file unless it is wrapped in the code above.
* This is not true for the rest of the debug messages `ics.LogMsg()` is the only one that requires wrapping as it is the only one that is entered directly into the code.
* This is not always necessary, if it is a simple debug job then putting ics.LogMsg directly would be fine (but this is not best practise).
* This tag is now depreciated but it is still useful.

There are a range of further logging options available in the **futuretense.ini** which when set to yes will output the debugging information for that element. These include:

* `ft.cachedebug` outputs cache status messages.
* `ft.dbdebug` outputs database status messages.
* `ft.ssdebug` ouputs session debug messages.
* `ft.timedebug` outputs request performance info.
* `ft.xmldebug` outputs the structure of processed pages.
* `ft.logsize` specifies the maximum size of the log file.    


**`ics:geterrno`** 

* This tag is useful when placed after a functional section, such as a search or save.
* This outputs the error number to the screen so it is easier to identify an error and where it exists.
* It is necessary to clear the error number before calling this tag as it may refer to a separate error or older error.
* This is achieved using the `ics:clearerrno` tag.
```
<ics:clearerrno/>
<ics:xxx some action />
<ics:geterrno/>
```