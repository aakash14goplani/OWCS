Oracle webcenter sites provides you a wide range of pages or pagelets like Page, Template, SiteEntry. Templates provides you a complete aggregation of partial parts stored in pagelets. This article shows you how to render a pagelet using ajax call from cselement and insert data into database.

Let’s take an example of a detail page of an article. It shows the data along with the comments box. The user’s comment will be send to a page (commentService) to submit the comment into the database.

#### Create a CSElement for Detail page

Create a template, detail.jsp for detail page, write code to display for comments box with a text box & submit button. Bind a javascript’s onclick function to the submit button.
```html
<textarea name="comment" id="comment" placeholder="Your Comment here..." ></textarea>
<input name="submit" type="submit" id="submit"  value="Submit" onClick="submitComment()"/>
```

#### Create a page for ajax call

Create a page, **commentService.jsp** to which you make ajax call & write the code to submit comment into database table using `ics:catalogmanager` tag.

#### Write ajax function

Write the script functionality for `submitComment()` function in **detail.jsp**. Generate the url for the **commentService.jsp** page to which ajax call sends data. Use the `render:gettemplateurl` tag to generate the url.
```javascript
<render:gettemplateurl tname="/DevArticle_C/commentService" c="Page" cid="16009269869" outstr="serviceUrl" />

var oReq;

function getXMLHttpRequest() 
{
    if (window.XMLHttpRequest) {
        return new window.XMLHttpRequest;
    }
    else {
        try {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        }
        catch(ex) {
            return null;
        }
    }
}


function submitComment(){
	var commnetService = "<%= ics.GetVar("serviceUrl")%>";
	var author = "<%= ics.GetVar("user") %>";
	var comment = document.getElementById("comment").value;
	var articleId = "<%= ics.GetVar("cid") %>";
	var params = "author="+author+"&comment="+comment+"&aid="+articleId;
	
	oReq = getXMLHttpRequest();
	
	if (oReq != null) {
	    oReq.open("POST", commnetService, true);
	    oReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	    oReq.setRequestHeader("Content-length", params.length);
	    oReq.setRequestHeader("Connection", "close");
	    
	    oReq.onreadystatechange = handler;
	    oReq.send(params);
	}
	else {
	    window.console.log("AJAX (XMLHTTP) not supported.");
	}
	
	return false;
}

function handler()
{
    if (oReq.readyState == 4 /* complete */) {
        if (oReq.status == 200) {
        	alert(oReq.responseText.trim());
        }
    }
}
```

#### Code to submit the data into database table

User the `ics:catalogmanager` to add a new row into the table.
```jsp
<ics:catalogmanager>
	<ics:argument name="ftcmd" value="addrow"/>
	<ics:argument name="tablename" value="DevArticleComments"/>
	<%
	int aid = new java.util.Random().nextInt((99999-11111)+1)+11111;
	String id = String.valueOf(aid);
	DateFormat df = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
	String cDate = df.format( new Date() );
	%>
	<ics:argument name="id" value='<%= id %>'/>
	<ics:argument name="comment" value='<%= ics.GetVar("comment") %>'/>
	<ics:argument name="author" value='<%= ics.GetVar("author") %>'/>
	<ics:argument name="articleid" value='<%= ics.GetVar("aid") %>'/>
	<ics:argument name="createddate" value='<%= cDate %>'/>
	<ics:argument name="modifieddate" value='<%= cDate %>'/>
</ics:catalogmanager>
```