The current REST APIs (for v11.x.x) allow you to the following:

* Read, create and delete Asset Types and read subtypes
* Create, read, edit and delete assets
* Read the asset associations for a specific asset
* Search for assets by asset type, by site, by site and asset type, search assets globally
* Create, read, edit and delete search indexes
* Create, read, edit and delete a Site
* Read the site plan tree
* Create, read, edit and delete Roles
* Create, read, edit and delete WEM Applications (FW_View and FW_Application)
* Create, read, edit and delete users
* List all user locales
* List the attributes defined for user profiles
* List ACL
* List security groups
* Read the server time zone