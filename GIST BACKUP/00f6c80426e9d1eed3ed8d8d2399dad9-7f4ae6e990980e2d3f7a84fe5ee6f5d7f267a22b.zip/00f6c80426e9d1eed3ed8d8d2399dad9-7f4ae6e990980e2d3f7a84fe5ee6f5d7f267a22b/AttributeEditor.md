An attribute editor specifies how data is entered for an attribute when that attribute is displayed on a New or Edit form for a flex asset or a flex parent asset in the WebCenter Sites interface on the management system.   

When you assign an attribute editor to an attribute, it replaces the default input mechanism (style) that would otherwise be used for that attribute. The default input style is based on the data type of the attribute.
presentationobject.dtd file   

### [The presentationobject.dtd file](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/data_attributeeditors.htm#WBCSD2291)
It defines several input styles (presentation objects) that you can use in your attribute editors. This means you do not have to define your own unless the nine that are included do not cover your needs
If you want to create custom attribute editors other than the ones made possible by default, you must first define an XML input style tag, a `PRESENTATIONOBJECT` tag, in the presentationobject.dtd file. To define a new `PRESENTATIONOBJECT` tag, you must do the following:
* Add the new tag (presentation object) to the list in the `<!ELEMENT PRESENTATIONOBJECT...>` statement.
* Add a `<!ELEMENT...>` section that defines the new tag (presentation object) and the arguments that it takes. Follow the normal syntax rules for a .dtd file and follow the conventions used in the `presentationobject.dtd` file.   

### GENERAL STEPS TO FOLLOW:

1. Create an XML file
2. Load the XML file e.g.
3. Create a flex attribute and add your editor in Attribute Editor field
4. Add it to flex definition
5. Create a demo asset and load it
6. Creating Attribute Editors   

**Example : CHECKBOXES**

```xml
<?XML VERSION="1.0"?> 
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 
<PRESENTATIONOBJECT NAME="PersonalizeCheckBox">
 <CHECKBOXES LAYOUT="VERTICAL"><!--default is HORIZONTAL-->
  <ITEM>OUTDOOR GAMES</ITEM><!--to retrieve value from db use QUERYASSETNAME-->
  <ITEM>INDOOR GAMES</ITEM>
 </CHECKBOXES>
</PRESENTATIONOBJECT>

Load the checkboxes

<assetset:setasset name="flexAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar(" cid")%>' />
<assetset:getattributevalues name="flexAsset" typename="ComponentWidget_A" attribute=" checkbox" listvarname="checkboxList"/>	

NAME : <ics:getvar name="asset:name" /><br/>
<ics:listloop listname="checkboxList">
Hobby : <ics:listget listname="checkboxList" fieldname="value" /><br/>
</ics:listloop>
```

[Documentation](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/data_attributeeditors.htm#WBCSD2290)