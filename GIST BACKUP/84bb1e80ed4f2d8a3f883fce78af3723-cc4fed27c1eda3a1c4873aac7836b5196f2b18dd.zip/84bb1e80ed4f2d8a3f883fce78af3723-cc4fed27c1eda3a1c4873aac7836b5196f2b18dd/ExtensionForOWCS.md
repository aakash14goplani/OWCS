The extension is designed using the oracle webcenter sites REST api. The **bSites** is a quick dash board for Oracle Webcenter sites. It gathers all the data in an efficient way and shows in a organized way. The bSites chrome extension saves user’s time by putting major data in a single interface. It is very useful for the guys who is using Oracle Webcenter Sites like contributors, developers, managers, admins.

### FEATURES

1. List of all websites.
2. Upon selection of a site, List out all the enabled asset types,
3. Shows list of assets and asset type.
4. Shows list of users who has permission to site along with roles.
5. Gathers an asset’s full data and shows in a eye catchy style.

### INSTALLATION

1. You can get the chrome extension form chrome webstore. Click [here](https://chrome.google.com/webstore/detail/bsites/dliiinpknhchbhiaabopfmahaemfdkpb) or copy the below url and open in chrome browser: `https://chrome.google.com/webstore/detail/bsites/dliiinpknhchbhiaabopfmahaemfdkpb`

2. After installing the bSites extension, right click on the extension icon on menu bar. Click on Options menu. Provide the server urls, username and password.

   bSites options example:   
   **CS URL:** `http://localhost:9080/cs`   
   **CAS URL:** `http://localhost:9080/cas`   
   **USER ID:** AakashG   
   **PASSWORD:** AakashG

3. Click on Connect button.

### RUN THE BSITES EXTENSION

After saving the preferences. Open the extension by clicking on extension icon in menu bar.