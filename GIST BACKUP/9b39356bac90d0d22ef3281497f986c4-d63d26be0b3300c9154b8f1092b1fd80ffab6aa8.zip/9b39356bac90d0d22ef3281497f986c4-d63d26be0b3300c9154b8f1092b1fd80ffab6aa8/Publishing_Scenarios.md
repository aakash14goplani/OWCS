### Creating a Publishing Destination

1. `Admin` -> `Publishing` -> `Add New Publishing Destination`
2. Enter **Name**
3. Select **Delivery Type:** 	*RealTime: Copy assets to remote dynamic server*, **Select the desired publishing option** *Complete publish*
4. Enter **Destination address:** `http://localhost:9180/cs/`
5. Enter **Remote User:** and **Remote Password:**
6. For **More Arguments:**, enter `PUBLISHASSETTYPES=false&`
7. Select *Any* for **Sites:**, **Roles (Approve for Publish):** and **Roles (Publish)**   

![create_publishing_destination](https://github.com/aakash14goplani/OWCS/blob/master/images/create_publishing_destination.png)   
![publishing_destination_attribute_values](https://github.com/aakash14goplani/OWCS/blob/master/images/publishing_destination_attribute_values.png)

***

**Terms used:**
* Environment A (lower environment used as source in Publishing: `http://localhost:9080/cs/`)
* Environment B (higher environment used as destination in Publishing: `http://localhost:9180/cs/`)

***

#### Scenario 1: Publish (Mirror) all the sites from `Environment A` to `Environment B` 

* This process mirrors all the sites from `Environment A` to `Environment B`. Note - only `pubid` will be published, content (i.e. Asset types and Assets) will not be published

1. `Admin` -> `Publishing` -> `List all Publish Destinations` -> *Select required destination*
2. Click on **Initialize Realtime Destination**
3. Select required sites that you want to publish to `Environment B`
4. Click on **Mirror**

![scenario_1_image_1](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_1_image_1.png)   
![scenario_1_image_2](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_1_image_2.png)   
![scenario_1_image_3](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_1_image_3.png)   

***

#### Scenario 2: Publish (Mirror) Asset Types from `Environment A` to `Environment B`

* This process mirrors all the asset types for selected site from `Environment A` to `Environment B`.

1. Admin -> List All Sites -> *Select site whose asset_types needs to be mirrored*
2. Under **Publish Destinations:** Select required destination where publishing should tak place
3. Select required **Asset Types**, **Start Menu**, **Tree Tabs** and **Roles** to be published
4. Click on **Mirror**
5. Click on Publishing Tab -> Select required **Publish destination**
6. Click on **Select Destination**
7. You can see the Publishing console, once it is 100% complete all the data will be published from source to destination. Often you will see that couple number of assets are held for publishing, in that case click on those assets and manually approve each and every one of those. Once approved, you'll see publishing console.   

![scenario_2_image_1](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_2_image_1.png)   
![scenario_2_image_2](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_2_image_2.png)   
![scenario_2_image_3](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_2_image_3.png)   
![scenario_2_image_4](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_2_image_4.png)      

***

### Scenario 3: Publish (Mirror) a specific asset from Contributor UI from `Environment A` to `Environment B`

1. Click on Approve botton (green colored check mark)
2. Select required Publishing destination
3. Select the required assets and click on **Approve with Dependencies**
4. Go to Admin tab, click on Publishing tab
5. Select required destination (the one which was selected in step 2.)
6. You should see `x number assets are ready to publish` or `x number assets need approval before publish`. Click on this link and select required assets.
7. Click on **Add to On-Demand Queue**  
8. In the **On-Demand Queue** tab, select all the assets and click on **Publish On-Demand Queue**

![scenario_3_image_1](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_3_image_1.png)   
![scenario_3_image_2](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_3_image_2.png)   
![scenario_3_image_3](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_3_image_3.png)   
![scenario_3_image_4](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_3_image_4.png)   
![scenario_3_image_5](https://github.com/aakash14goplani/OWCS/blob/master/images/scenario_3_image_5.png)   
 