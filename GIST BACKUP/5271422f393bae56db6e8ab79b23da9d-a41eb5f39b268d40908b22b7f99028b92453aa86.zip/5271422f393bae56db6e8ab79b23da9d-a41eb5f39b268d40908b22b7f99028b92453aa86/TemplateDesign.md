# Template Design

Once you have a good content model, it is time to go for designing the template hierarchy.

Actually, you need a design for templates. Fatwire has some requirements on template naming built-in in the underlying logic of their tags. Here is a post that tries to explain the underlying ideas of Fatwire template coding. Basically, in a good design, content model types looks like classes, while templates looks like methods.

Well designed templates have a simple name, the code is short and straight forward, and it is very easy to read. Fatwire tags for templates are very verbose, with an overwhelming number of options. But using them in a consistently way will make your code readable.

Actually some developer don't understand the design. Well, they don't even understand the meaning of many parameters (for example the parent, the context, even the appropriate use of `c` and `cid`), and write templates badly.

The biggest and more frequent mistake noticed are templates with very complex Java coding, whose structure and naming coded shows clearly the code don't understand there is an underlying caching system.

For example, they store a parameter as an attribute  and they read it in another template that can be actually cached!!! The result  lead to unnecessary long code and repetitive code, full of  tricks written in Java. And, most important, those templates do not cache properly.

So here there few tips:

**Do:**   

* Think before code. This should be done always. But it looks like that when it comes to implement a Fatwire site, since you have the psd, you have the html, you have the css, since you are late (as always) it looks like you just have to drop templates in Fatwire and you are done. Big mistake.
* Identify common parts. Look to each page and find out which parts are the same everywhere. They are good candidates to define standalone templates.
* So, checking carefully the html of your site, design a template hierarchy. Decide what is in the wrapper, in the layout, in the body, in the detail, for the link and so on. Be consistent.
* Write down this structure in paper, and be sure it matches the content model. Double check every template and be sure that is make sense. Remember: each template applies to a type so it is basically a method of a class.
* Use consistent meaningful naming. Each template must have a name that is simple and meaningful in context. So a name like Summary of an Article makes sense. Names like Template123 or LeftMenuForBoxWhenBreadcumpIsLongertThan2 do not.
* Remember: If you have a good design, your site will work. If you don't have, it won't.

**Do not:**   

* Skip completely the template design phase and rush to code .
* Create a template for everything that render to a full html page.
* Split html according and give random names to each template according the mood of the moment.
* Ignore compositional dependencies and caching strategies until it is too late
* Sadly, I have seen by far too many sites built this way.

**The result normally is:**   

* an explosion of templates all different with inconsistent naming
* a lot of duplication of code
* different ways to do the same thing in inconsistent way (e.g. a breadcrump recoded everywhere)
* a site  completely ummaintenable
* completely broken cache with devastatingly bad performances
* publishing completely broken since many dependencies are wrong
* But I am sure it won't happen to you! 

### References

[]()