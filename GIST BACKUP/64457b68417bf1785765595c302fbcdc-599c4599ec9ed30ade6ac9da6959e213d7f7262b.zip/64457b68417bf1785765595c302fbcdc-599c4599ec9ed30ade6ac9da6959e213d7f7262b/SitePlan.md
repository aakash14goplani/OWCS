### GENERAL STEPS TO FOLLOW:   

1. Load the page asset (using `asset:load` tag) 
2. Get the site node from SitePlanTree table (using `asset:sitenode` tag) 
3. Load the node (using `siteplan:load` tag)
4. Get ChildList from loaded node (using `siteplan:children` tag or using `siteplan:listpages` tag)
5. Loop through childlist to get Page name/id (using `ics:listloop` tag)   

### Using `siteplan:children` tag

```jsp
<asset:load name="assetName" type='Page' objectid='<%=ics.GetVar("cid")%>' site='<%=ics.GetVar("site")%>'/>
<!--  Get site node -->
<asset:getsitenode name="assetName" output="PageNodeId"/>
<!-- Load Home page as a siteplan node object -->
<siteplan:load name="ParentNode" nodeid='<%=ics.GetVar("PageNodeId") %>'/>
<!-- Obtain Home page's child node, save in list and order them by their rank -->
<siteplan:children name="ParentNode" list="ChildPages" order="nrank" code="Placed" objecttype="Page"/>
<!-- Loop through list to get page names's under Home page node -->
<ics:if condition='<%= null != ics.GetList("ChildPages") && ics.GetList("ChildPages").hasData() %>'>
 <ics:listloop listname="ChildPages">
  <ics:listget listname="ChildPages" fieldname="id" output="aid"/>
  <asset:load name="ThePage" type="Page" objectid='<%=ics.GetVar("aid") %>' />
  <p><asset:get field="name"/></p>
 </ics:listloop>
</ics:if>
```   

### Using `siteplan:listpages` tag   
```jsp
<asset:load name="assetName" type='Page' objectid='<%=ics.GetVar("cid")%>' site='<%=ics.GetVar("site")%>'/>
<!--  Get site node -->
<asset:getsitenode name="assetName" output="PageNodeId"/>
<!-- Load Home page as a siteplan node object -->
<siteplan:load name="ParentNode" nodeid='<%=ics.GetVar("PageNodeId") %>'/>
<!-- Query the SitePlanTree table and then creates a list of pages, starting with the page node that you specify. -->
<siteplan:listpages name="ParentNode" placedlist="placedPages" level="1" />
<!-- Loop through list to get page names under specified page node -->
<ics:if condition='<%=null != ics.GetList("placedPages") && ics.GetList("placedPages").hasData() %>'>
 <ics:listloop listname="placedPages">
  <p><ics:listget listname="placedPages" fieldname="PageName"/></p>
 </ics:listloop>
</ics:if>
```   

### References   

[Fatwiredev Blog](https://fatwiredev.blogspot.in/2013/11/example-7-site-plan.html)   
[To load siteplan from bottom to top](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/asset-siteparent.html)