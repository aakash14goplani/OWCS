# Explore WebCenter Sites Tables using Eclipse and HSQLDB

No doubt, WebCenter Sites has provided a great tool called CSExplorer in JSK for exploring the Database contents. But this tool has limitations. This works only on the Windows environments. But in reality, developers work on different environments aswell like MAC, Linux, etc.

**Step  1:**

* Open your `server.xml` file. It can be found under the below location: `[WCS installation Dir ]/apache-tomcat-7.0.42/Sites/conf/server.xml`.
* Get the below values:
   + Username
   + Password
   + URL
See below screen shot.

 ![server_xml](https://github.com/aakash14goplani/OWCS/blob/master/images/hsql_1.png)

**Step  2:**    

* Have your eclipse installed. You can get it from [this link](https://www.eclipse.org/downloads/).

**Step  3:**     

* Download the Data tools platform from eclipse marketplace. To do this, go to the Eclipse market place window, and search for _ECLIPSE DTP (DATA TOOLS PLATFORM) 1.11.1 KEPLER_, and install the plugin.

 ![DTP](https://github.com/aakash14goplani/OWCS/blob/master/images/hsql_2.png)

**Step 4:**     

* Now open the Perspective "Database Development".
* You can do this by going to the Eclipse -> Window -> Open Perspective -> Other – > Database Development

**Step 5:** 

* In the left hand, you will see a new tree opened called `DATA SOURCE EXPLORER`.
* Right click on `DATA CONNECTIONS`, and click on `NEW`.

 ![DATASOURCE](https://github.com/aakash14goplani/OWCS/blob/master/images/hsql_3.png)

**Step 6:**

* You will now get the following `CONNECTION PROFILE` window. Select HSQLDB from the available list of options, and click on `NEXT` button:

 ![conn-profile](https://github.com/aakash14goplani/OWCS/blob/master/images/hsql_4.png)

**Step 7:**

* Enter the `DB` connection details in the below window:
* Enter the following values from the inputs taken in step 1.
   + Database Location: `[WCS Installation Dir]/App_Server/apache-tomcat-7.0.42/Sites/default/data/hypersonic/csDB`
   + UserName: `sa`
   + Password: `blank`
* Then click on the TEST CONNECTION button. It shows a `PING SUCCESSFUL` dialog box. Now click on `FINISH` button.

 ![DB Info Screen](https://github.com/aakash14goplani/OWCS/blob/master/images/hsql_5.png)

**NOTE:** You need to add the `hsqldb.jar` in the above window, by clicking on the `+` button available against the `DRIVER` drop down.

**Step  8:**  

* That’s it. In the Data source explorer tree of left hand side, you can see a new DB connection created to your local JSK. You can explore the tables as shown in the below screenshot.

 ![TABLES](https://github.com/aakash14goplani/OWCS/blob/master/images/hsql_6.png)

### References

[kksays](https://kksays.wordpress.com/2014/12/31/explore-fatwire-webcenter-sites-hsqldb-with-eclipse-alternative-for-csexplorer-for-mac-users/)