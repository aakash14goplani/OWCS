### USING `ics:selectto` TAG

```jsp
<ics:selectto listname="features" table="Feature" what="name,id"  ></ics:selectto>
<ics:listloop listname="features">
	<ics:listget fieldname="name" listname="features"/><br/>
</ics:listloop>
```
```java
IList results = ics.SelectTo("Feature","name,id",null,null,-1,null,false,new StringBuffer("nodata"));
int c = 1;
while( results.hasData() && c<= results.numRows() ){
	results.moveTo(c);
	String feature_name = results.getValue("name");
	out.print(c+". "+feature_name+"<br/>");
	c++;
}
```

### Using `ics:sql`

```jsp
<ics:sql sql="select * from MultiMedia_C" listname="multimediaAssetsList" table="MultiMedia_C" />
<ics:listloop listname="multimediaAssetsList">
	<ics:listget fieldname="name" listname="multimediaAssetsList"/><br/>
</ics:listloop>
```
```java
String sql = "select * from MultiMedia_C";
IList data = ics.SQL("TempObjects", sql,null, -1, true, err);
if(data != null){
    /*logic goes here*/
}
```

### Using `ics:callsql`

```jsp
<ics:callsql qryname='<%="OpenMarket/Xcelerate/AssetType/" + assettype  + "/SelectSummary"%>' listname="assetslist" limit="<%=limit%>"/>
<ics:listloop listname="assetslist">
	<ics:listget fieldname="name" listname="assetslist"/><br/>
</ics:listloop>
```
```java
IList results = ics.CallSQL("OpenMarket/Xcelerate/AssetType/FW_AttributeEditor/SelectSummary", null, -1,true, errStr); 
if (results!=null && results.numRows()>0){
   /*logic goes here*/
}
```

### Using `ics:sqlexp`

Here where clause constructed by `sqlexp` tag is used within the `ics:catalogmanager.selectrows` tag. This query selects all rows with `id=1`.
```jsp
<ics:clearerrno/>

<ics:sqlexp column="id" output="whereList" string="1" table="ExampleTable" verb="=" /> 

<ics:getvar name="whereList"/>

<ics:if condition='<%ics.GetErrno() != 0 %>'>
  <ics:then>
    Error occurred while constructing where clause
  </ics:then>
</ics:if>

<ics:clearerrno/>

<ics:catalogmanager>
  <ics:argument name="ftcmd" value="selectrow(s)"/>
  <ics:argument name="tablename" value="ExampleTable"/>
  <ics:argument name="selwhere" value='<%=ics.GetVar("whereList")%>'/>
  <ics:argument name="selwhat" value="id"/>
</ics:catalogmanager>

<ics:if condition='<%ics.GetErrno() != 0 %>'>
  <ics:then>
    Error occured while selecting rows
  </ics:then>
  <ics:else>
    <ics:getvar name="cshttp"/>
  </ics:else>
</ics:if>
```