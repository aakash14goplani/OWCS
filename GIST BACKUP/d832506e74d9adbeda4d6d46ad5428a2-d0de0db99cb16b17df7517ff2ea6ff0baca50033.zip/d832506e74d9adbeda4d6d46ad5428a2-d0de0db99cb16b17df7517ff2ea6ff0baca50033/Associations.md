### GENERAL STEPS TO FOLLOW:   

1. Load the asset (using `asset:load` tag)
2. Get the association (using `asset:children` tag)
3. Fetch attributes (by looping through list using `ics:listloop` tag)   

### Retrieving NAMED ASSOCIATIONS   

```jsp
<asset:load name="HomePage" type="Page" objectid='<%=ics.GetVar("cid")%>' site='<%=ics.GetVar("site")%>'/>
<asset:children name="HomePage" list="LatestNewQuery" objectype="Query" code="NameOfAssociation"/>
<ics:listloop listname="LatestNewQuery"> 
     <ics:listget listname="LatestNewQuery" fieldname="description"/>
</ics:listloop>
```   

* `code="NameOfAssociation"` - This is required to retrieve NAMED association.    

### Retrieving UNNAMED ASSOCIATIONS (Collections, Query and Asset associated):   

```jsp
<asset:load name="NewsCollection" type="Collection" objectid='<%=ics.GetVar("id")%>'/>
<asset:get name="NewsCollection" field="name"/><br/>
<asset:children name="NewsCollection" code="-" order="nrank" objecttype="Article" list="articleList"/>
<ics:listloop listname="articleList">
     <ics:listget listname="articleList" fieldname="description"/><br/>
</ics:listloop>
```

* Notice: for unnamed associations, we use "-" in `code` parameter (code="-") while using `asset:children` tag.
* `order="nrank"` - This can be used to retrieve list sorted by rank started at number 1. Use `nrank desc` for descending order.
* If you only want to retrieve associated assets, don't use `asset:load`. You can directly load association by providing assetid and asset type info to `asset:children`   

### References   

[Fatwiredev Blog](https://fatwiredev.blogspot.in/2013/07/example-3-rendering-associations.html)   