# For Reference Only- Do not include in site

---------------------------------------------------------------------------------------------------------------------

# Mixing HTML and Code

It is hard to believe that in 2012 we still we have problems of mixing html and code. Those problems  are supposed to have been solved since many years, but unfortunately they are still around.

In an ideal world, a web designer is also able to code. In a world even better, a web designer is also able to write jsp templates and knows fatwire tags.

In the real world, web designers, while often knowledgeable of  javascript, have usually no clue of JSP nor of specific Fatwire coding, so they produce only a mockup made of client-side HTML, CSS and Javascript. They leave to  "server side" developers the task of using that HTML/CSS/Javascript to create a content manageable website.

The problem with Fatwire/WCS is that to render the mockup code, you have to add Fatwire coding to it. So , because WCS is still a JSP based system,  you have to add  logic to extract the content model and put it in place in the HTML mockup. That would be fine if... it were to be done  only once.

But in reality, HTML code undergoes a number of iterations. Web designer will update the mockup and return it to server side developers. Those developers will  have to use the new HTML to update their templates code, that is now an heavily modified version, with added a lot logic in Java and JSP tags.

This is a big problem, because it is not easy. The usual process is figuring out what changed in the mockup  from the latest version used to build templates,  then go through the code to apply those modifications. Hoping that nothing will break.

When the HTML is heavily modified, starting from scratch is not unusual. In short, the process of updating templates when the HTML mockup changes is a real pain in the ass.

What is really needed.
The principle of separating presentation code (HTML) from logic is almost as old as the web itself. There are millions of solutions arounds for this, yet those solutions did not yet reach WCS in his core. We strongly need to implement for real this separations.

Furthermore, since HTML mockups are going to change ofter, we should be able to leave the mockup in his original form, in order to be easily updatable. Rendering logic should be applicable directly to HTML in his original form, without modifications.

 

-------------------------------------------------------------------------------------------------------------------------------

# JSP are evil

I am close to release a new open source project that  tries to fix  many of the common problems in Fatwire and WCS development.

But before the release, I want to  discuss those problems, since fixing them  is the main motivations underlying my development effort.

Actually, many of the features of the framework I am doing cannot be understood unless you know which real world problems they try to solve.

This is not a rant.  I also have a solution to those problems and it will follow in the next few weeks. 

JSP are evil
The biggest issue in Fatwire/WCS in my view is that you are stuck with JSP (or worse, with the obsolete, very limited and almost undocumented "Fatwire XML").

JSP are designed only to be a quick way of rendering a dynamic HTML page using Java code. Something that is 95% html and only a little bit of code. They are no way  meant in no way to be a complete tool for doing generic Java coding.

They provide the flexibility of immediate availability (since they are recompiled and reloaded on the fly), and they provide the "markup first" approach that is useful when you need to render a lot of HTML and only a small part need to be coded and rendered dynamically.

Indeed this JSP  flexibility comes with a lot of limitation, while the coding in Fatwire development tend to be pretty complex, so complex that you end up writing big JSP so full of code that  may you have difficulties finding the HTML.

Here some of the limitations of JSP. First and before all, because a JSP is  a single method of a single class, you generally are not supposed to define methods and classes. You actually can define classes and methods, using the "<%!" syntax.

Hovewer, since it is not the way  JSP are supposed to be used, you cannot reuse any defined  method in another JSP . This is even worse when you also define a class. You can create classes inside a JSP but you cannot reuse that class in another JSP.

The only way of having code shared between different JSP is to create a separate jar with all the code and deploy in the application server Coding such a jar is relatively awkward, because you have to build it, deploy and restart the application server for every change. So usually this is done rarely.

For this reason, building libraries of code is not normally done in Java (as it should). Instead, the common practice is to create a library of "elements" called by JSP.

The problem is that a CSElement is not really meant to be a library doing complex things, it is meant as a medium to generate repeatable rendering of common elements.

The semantics of calling  CSElements, and using them as a library is, frankly, disgusting. There is no way return value from a CSElement , so you normally use a global environment and  side effects (altering the value of a variable value in a shared environment).

The JSP "language" does not offer any enforcement to using a CSElement as a library call, so everything is left to convention. You need to document clearly which variables are changed to see what is returned. This practice is error prone, hard to read and even harder to maintain.

Also it happen often that a CSElement "pollutes" the calling enviroment, so you need to use pushvar and popvar to preserve the environment. And this makes the whole procedure even more disgusting, unreadable and produces really bad code, where a lot of complexity is there just to move around variables, protect them and read side effects.

Last but not least, the invoking CSElements is really verbose and typing an invocation method is often so long that you copy and paste code. Long code doing little is also very hard to read.

How to solve JSP problems
1. What really is needed is a way to code in full, plain, clean Java, not in JSP. Classes offers all the power needed to build complex programs, and a JSP are a simplified AND limited form of Java classes. Using Java will immediately give you the ability to write methods and classes, keeping them totally reusable.

2. However you need to retain the ability of seeing immediately the result of a change because restarting the application server at each change is usually not really practical:  it is so slow that developers to avoid it will prefer to push tons of code in the JSP. A solution could be "JRebel" but since it is expensive for some teams (most notably indian teams) buying it can be a problem. So that solution should be cheap.

3. Coding in Java you will also want to avoid ton of out.println("...") filled of "\" to escape quotes just to generate HTML. Probably you may not not the "HTML first" approach of JSP  and you may prefer the "code first" of Java, but you still want an easy way of generating HTML.

4. Last but not least, JSP offers some well defined tag libraries for rendering the content model. Since the equivalent Fatwire Java API (the Asset API) is not even close to the quality of tag libraries, you need some  efficient way of invoking tag directly from Java code.

We have not finished, yet.
Actually we have just started, a lot more will come. So please wait, there are more problems to  discuss in the next posts. And the solution will follow, it is a promise. So stay tuned.


-------------------------------------------------------------------------------------------------------------------------------


# The new WCS User Interface

The new  Oracle-branded WecCenter Sites v11g is not a revolutionary product: it is still recognizable as the old, good ContentServer (formerly Fatwire, Divine and OpenMarket) we already know.  Nonetheless, in this new incarnation it looks like a big jump forward.

This release is probably defined more from what has been removed than from what has been added. Most of  the work done  on WCS looks to be a great effort to simplify, make uniform and consistent,  overall improve the user experience of the product. The first and more evident feature gone is the dash interface (but not its functionalities). It is also gone the insite interface,  but again,  insite editing is now even more powerful.

There is no more the dualism of 3 competing user interface (dash, advanced and insite), where you can do more or less the same thing in different incarnations. Instead, there is now one unified UI. It acts like the old Advanced interface when it comes to manage "advanced" content assets (mostly used by developers and webmasters) . The UI also acts like the dash interface to browse and edit content, but seamlessly integrates  insite editing to preview and edit content at the same time.

Let's do a walkthrough with screenshots to  understand better.

The Administrative interface
Let's start from the administrative (the old avanced) interface. It is now probably  going to be the less used but we start from it because it is familiar to the vast majority of current users.

On the top of the screen there is now a toolbar allowing to select the interface (now there are 2, the administrative and the contributor). If we select the administrative interface, as below:



 

It is now possible to create and search assets, but, important new, ONLY administrative assets: templates, cselements, attributes, definitioins and so on. It is no more possible create and edit content assets from this interface.

Creating an asset is still done in the old way. For example clicking on a start menu link to create a new template:



 

then the usual form is shown:



 

nothing new under the sun regarding the administrative assets (except a css restyling). The interesting parts comes now.

 The Contributor interface
When we select the new Contributor Interface things start to became new (and interesting):



Creating a new element now requires you select it from the menu. The new  action  now appears in a pull down menu:



 

Content can be edited now in a form, so in a sense it is still possible to do form oriented content editing. See below and please note the toolbar of saving, approving , previewing and deleting.

 


However, the interesting part is the switch to enable a visually oriented content editing. Just click on the switch and the form becames an (editable) preview.

Here the content editing is pretty rich. You can drag and drop an image to insert it  in an area of the page, click on a text field to do inline editing, click on a date area to display a date picker and so on.

Definitely, now the content editing integrates the 2 different interfaces (dash and insite) but it has became much easier to understand. Overall the user experience is way simpler and straightforward. Furthermore, a lot of duplications are removed, while keeping and even improving the features already available.
Definitely a sign of product maturation worth to be now the Oracle CMS. Because the software has been developed before the acquisition, it is worth to say: excellent job, Fatwire!