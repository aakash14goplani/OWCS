Content Server Arcitecture has the following levels of components. All these combinedly working, brings a high performance site, as desired by the customer.

 ![CS Architecture](https://github.com/aakash14goplani/OWCS/blob/master/images/cs_architecture.png)

1. **Database:**   
Like every other architecture, in this CS-Architeture, the Database is the one which sits on the bottom of all the components.The Database can be of our own choice. This may include Oracle Database, MS SQL, DB2, etc. We can choose an Database of our choice, and perform the installation. The installation guides will have enough information for providing the right databases, and their installation, etc.

2. **Application Server:**   
The application server sits above the database, and it acts as the main component for running the Content Server. The Content Server Context (CS) is deployed in this application. Hence, all the requests from the components above this level, like Engage, Analytics, etc will be passed to the CS Context through this Application Server. This application server could be of our own choice, like Apache Tomcat, JBoss. etc. But, I’ve seen Apache Tomcat with most of the installations.

3. **Content Server:**   
As mentioned above, the Content Server Context will be typically deployed in the application server. But, the actually installation of Content Server Software will be done in some other directory of our choice.

   The Content Server context provides access to the Java servlets that compose Content Server. What language we code : XML or JSP, we code in the Content Server context. These XML and JSP tags provide an easy-to use interface to Content Server’s Java objects, so that even web designers with no Java knowledge can create Content Server web pages.

   This Content Server will have cache storage, and this cache is used to store the pages, content, blobs, etc., which are frequently requested, as well as recently requested by the end users. In this way, the need for requesting the DB for each and every query coming from end user, will be drastically reduced, and hence, improving the overall performance.

4. **CS-Direct (or) XCELERATE:**   
This CS-Direct module of the Content Server sits on the top of Content Server. The concept of Basic Asset Model is introduced by the CS-Direct module of the content server. The code name for this CS-Direct is XCELERATE. You can see the name XCELERATE in many places, like naming conventions, directory names, etc.

   But, the Basic Asset Model has many disadvantages, which are later revisited and solved by the Flex Asset Model.

5. **CS-Direct Advantage (or) GATOR:**   
This CS-Direct Advantage module of the Content Server is an extension to the CS-Direct. It adds additional functionalities to the existing data model. It sits on the top of CS-Direct.

   The concept of Basic Asset Model has some limitations. Hence, to overcome those limitations, the CS-Direct Advantage module of the content server is introduced.
The CS-Direct Advantage introduces us with the Flex Asset Model. As this data model is an extension of the existing Basic Asset Model, they might have named it as Flex Asset Model (My assumption is FLEXIBLE Asset Model).

   The code name for this CS-Direct is GATOR. You can see the name GATOR in many places, like naming conventions, directory names, etc.

6. **Fatwire Engage:**   
In this e-commerce world, every customer is valuable and very important. So, there is a need to keep the visitor (customer) ENGAGED to the site, so that he revisits the site frequently, and gives a good business. This will increase the overall business profits.

   So, to keep them engaged to the site (business), we can use the ENGAGE software of Fatwire. This is an optional software that can be installed, so that the end user will be kept informed about the recent attractions of his interest.

   It is an application that enables your marketing team to divide your site visitors into segments and then target those segments with personalized messages, or promotional, marketing, and informational messages.

7. **Fatwire Analytics:**   
Again, Analytics is an optional product. It is a Content Server plug-in that monitors and analyzes website traffic. It helps you to track visitors interactions with content from the time visitors start browsing your site, up to the time they leave your site.

8. **Satellite Server:**   
Satellite Server can be divided into two components. Co-Resident Satellite Server, and Remote Satellite Server. By having two such servers, the caching will be hugely improved, and thus improving the site performance, and the overall turnaround time.

   The Remote Satellite Server is a caching application that speeds the performance of your delivery system by serving cached images and Content Server pages from remote servers. Remote servers over here refers to different locations, like America, Asia, Australian location servers.

   Satellite Server reduces the load on the Content Server delivery system and to deliver pages more quickly.

   The Remote Satellite Server is offered as a stand-alone product to help you optimize system performance according to the load on the system.

   In most of the cases, the Remote Satellite Server will be installed in the same server where the web server resides.

### References

[kksays](https://kksays.wordpress.com/2013/02/20/content-server-architecture-of-fatwire-oracle-webcenter-sites-11g/)