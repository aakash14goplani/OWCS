In general Oracle Webcenter Sites configuration, the satellite server caches the output of pages for better performance and to reduce unnecessary load on the server. What if something wrong is happened while loading page or executing some business logic in the code? Yes it will also be cached into the server. There is a nice way to disable cache at runtime to prevent error pages from caching.

The method `DisableCache()` of ics object disables caching on both the EvalServer and the Sites servlets for the current page evaluation. This does not affect any other thread and does not affect export.
`ics.DisableCache();`

### DISABLE CACHE AT RUNTIME
Put some if condition in your code to check for any errors by calling `getErrno()` method and make condition on returned error code. If the error code is not equals to 0 then that means something wrong is happened. Then you can call `DisableCache()` method like below
```java
int error_code = ics.GetErrno();
if (error_code != 0){
   ics.DisableCache();
}
```
When the `ics.DisableCache()` method is executed, the current page will not be cached.

### DISABLE CHILD PAGES CACHE
If current page is calling some other child pages? you can specify like to include or exclude child pages from caching. That can be done by the `ics:disablecache` tag. It takes a parameter called recursion. Value must be set to true or false. If the value is true, all the page evolutions in the thread will not be cached unless the page is cached before executing `ics:disablecache` tag. If the value is false, only the current page will not be cached and the child pages will be cached.

`<ics:disablecache recursion="true"/>`