# Creating new Category with Page asset   

Page asset provides Category for categorization purpose. In this article i will explain “how to create new Category for page assets”.

* Goto Admin > Asset Types > Page > Categories
* Here we will find all association with page asset (see Figure 1)

### To create a new association, click on “Add New Category button”

And fill the form

**Description**: Information about this page category. Make it small and informative.
**Category Code**: This code will be used get the value. This is a 4 char value. Please do not put blank space.

Click “Add New Category” Button

### References
[mkbansal](https://mkbansal.wordpress.com/2010/08/07/fatwire-how-to-create-new-category-with-page-asset/)