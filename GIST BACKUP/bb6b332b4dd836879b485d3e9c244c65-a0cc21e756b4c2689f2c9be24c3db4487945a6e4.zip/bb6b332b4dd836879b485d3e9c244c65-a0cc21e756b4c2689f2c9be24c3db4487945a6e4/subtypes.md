# Asset SubTypes

For example, let's assume you have a lot of Page, but those Pages should be  rendered in different way, if they are placed in different location of the siteplan. So which implementation strategy are you going to use?

Different solutions to this problem can be involving complex logic on the siteplan or extra parameters. If you use the position in the siteplan, it can break easily, while extra parameters are a pain in the ass when it comes to caching. Actually, the correct solution is to use subtypes. More in the detail:

* create a subtype for the different page renderings,
* select the subtype when you create a page
* use the subtype to dispatch to the correct rendering code.
* Create a subtype and assign it
* Go into the Admin panel, select Page and open it: you will see the subtype node; this will give you the opportunity to add a new subtype:
* Now, when you create or edit a page, you can now see a pull down allowing to choose your subtype:

### Recognize the subtype in the code

Now you can forget about passing spurious parameters or complex siteplan logic. When it comes to to render a page, read the subtype with `asset:getsubtype`, the call a different template according to the subtype. For example (look at the bold code):

```jsp
<asset:getsubtype type='Page' objectid='<%= ics.GetVar("cid") %>' output='subtype'/>
<render:calltemplate tid='<%= ics.GetVar("tid") %>' site='<%= ics.GetVar("site") %>' c='<%=ics.GetVar("c") %>' cid='<%=ics.GetVar("cid") %>' slotname='Body' tname='<%=ics.GetVar("subtype")+"/Body"%>' /> 
```

This is a typical case for a "Body" template; if you have defined  Home and  Body subtypes, the code will dispatch to an "Home/Body" template and a "Content/Body" template according to the subtype of the page