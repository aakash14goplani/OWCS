# Content Server request processing

We will discuss how Content Server processes code, mostly to show how it differs from other web programming engine like PHP or plain JSP.

### Invoking ContentServer

You invoke ContentServer with the URL: `http://www.yoursite.com/cs/ContentServer`
Here `http://www.yousite.com/cs/` can change according your domain name and where you have installed it, but the `ContentServer` servlet must be always invoked, and you have also to specify some parameters. The most important parameter is `pagename`.   


As a general rule, you can assume `ContentServer?pagename=Element` invokes some code, written either in `XML` or in `JSP`. The specific code may require more parameters to process but the parameter `pagename` is the one you require to invoke the code.   


But before going into more details, you have to know how the code is stored inside WCS.   

First, let's introduce some terminology: within WCS code is called "Element". An element is either a pieces of JSP os XML code. Code is stored in a file inside the file system, but cannot be accessed directly pointing to it in the filesystem, as you do in PHP and JSP.


Indeed,  there are some "metadata" associated to each element, and those metadata are stored in the database. So basically you have to read the database, and the database will tell you how to process the code.


There are 2 database tables involved: `ElementCatalog` and `SiteCatalog`. But before explaining those tables, I need to digress explaining how files in the filesystem are related to database tables.

A database table for `ContentServer` is nothing really special, it is similar to any other table except there are a few conventions to be followed.

1. The first one is that every table managed by Content Server has at least the following 3 fields: "id", "name", and "description", and must be know to content server by registering it in the `SystemInfo` table (a special table used to index all the other tables in the system). `ContentServer` consistently create records with a `name`, assign then an `id` that is uniquely generated, require a `name` that is mandatory and offer the opportunity to store a `description` of the record.

2. Another important convention is that a table can have files attached. But instead of storing them as `blob` (whose usage is pretty inconsistent between different databases) files are actually stored in the file system, and only a pointer to the file is stored in the database table. The general convention is: when a field starts with "url" (or is just url) then its content is actually the relative path on the filesystem where is stored the file.   


You may ask: relative to what? Well, as said the special table `SystemInfo` stores some informations for each table. In our case, it stores the base path for files attached to each table. So basically it works this way: when you need to attach a file to a database table, 
* you need a field with a name starting with "url"
* then define in the `SystemInfo` table, a folder where files for that table will be stored
* store in the url field the relative path name for the file
* store the actual file in the file system, using as a file name the top level folder defined in step 1, plus the value stored in the field as in step 3

### The `ElementCatalog` and the `SiteCatalog` tables

So you now may wonder: what has this digression has to do with the ContentServer code processing? It is simple. The code to be executed is stored in a file attached to the table `ElementCatalog` as just described.


You can refer to each element with its name, but the name is used to locate a record in the `ElementCatalog` table. `ElementCatalog` stores informations like last modification time, and other stuff. Then, the actual file containing the code, is an attachment to the `ElementCatalog` table.


Please note that using the `ElementCatalog`, you can invoke that code from another element using internal calls like the `ics:callelement` call;  but you cannot invoke the element from the servlet url with just its name in the `ElementCatalog`. This is both for protection and for caching.   


But it is of course still possible invoking code from the ContentServer servlet, as explained before, using the `ContentServer?pagename=Element`. Hovewer, the Element heade does not refer to an entry in the `ElementCatalog` table, but instead to an entry in the `SiteCatalog` table. In the `SiteCatalog` table there is a field linking to the actual entry in the `ElementCatalog` table, which in turn points to the actual code.


`SiteCatalog` actually has an additional purpose: caching elements. When you invoke something from the URL, the `SiteCatalog` is looked up but it does not necessarily call the underlying Element it points if it has already a cached copy available. Also `SiteCatalog` allows  to create different entries for the same element, adding parameters for each of them, and eventually caching the output of the same element in a different ways.

### How a request is actually processed

1. the user follows a link with an url containing `ContentServer?pagename=Element`, eventually with other parameters
the whole combination of parameters is looked into the cache, and a suitable entry is available and (and is not expired), it is returned as a result, and the processing ends here.

2. if the requested Element has not a valid cache entry, it is looked into the `SiteCatalog` table and the field rootelement is used to locate the actual element in the ElementCatalog table

3. the `ElementCatalog` table is used in turn to locate the actual code; field url points the the code, concatenating its value with the top folder for this table (as specified in the `SystemInfo` table)

4. Now the actual code is located on disk and it is exectued; in general an element does not produce a whole web page but only a small snippet. The code can in turn invoke other elements.

5. Once the element has completed its work, the processed value is stored in the cache using informations from the `SiteCatalog` table
Finally the result of the call is returned to the end user.

Please note again this is not yet the whole story. An url assembler can be invoked before ContentServer, actually hiding the `pagename=Element` parameter, an apache server can be in front of `ContentServer`, and a remote `Satellite` server can be used in front of the Apache+ContentServer combo to add another layer of caching.