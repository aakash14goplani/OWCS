**DYNAMIC PUBLISHING**, also known as **MIRROR TO SERVER PUBLISHING** method, is one of the important Publishing methodologies of Fatwire. It is built with the Content Server Mirror API to copy approved assets from the Content Server database on one system to the Content Server database on another system.

### HOW IT WORKS:

The following image explains how the Mirror to Server publishing works in simple.

 ![image](https://github.com/aakash14goplani/OWCS/blob/master/images/dyn_pub_1.jpg)

To be more precise,

1. When the Dynamic Publishing is done, the Local content server (on which the main database, file structure, etc are there) mirrors,i.e, copies the entire file structure to the remote server (the machine which hosts the site).

2. The user requests a page.

3. The request will be received by the server (i.e, the mirrored remote CS Server).

4. The CS dynamically generates the pagelets and pages, and delivers it to the webserver.

5. The webserver then delivers it to the end user who has requested the page.

### CREATION OF DYNAMIC PUBLISH DESTINATION:

The following steps are involved in the creation of a **DYNAMIC PUBLISHING DESTINATION:**

1. Login to the Advanced user interface.
2. Go to the admin tab of the tree.
3. Expand **PUBLISHING** -> **DESTINATIONS**.
4. Click on **ADD NEW**. The following screen appears:

![image](https://github.com/aakash14goplani/OWCS/blob/master/images/dyn_pub_2.jpg)

5. In the **DELIVERY TYPE** drop down, select **MIRROR TO SERVER: Copy database rows to remote dynamic server**.
6. Enter a name for the publishing destination in **NAME** field
7. In the **DESTINATION ADDRESS** field, enter the name of the server, its port, followed by `/cs/`. For example, if `http://samplenode.com:9080/cs/Xcelerate/LoginPage.html` is the page which you use for logging into the advanced UI (URL of Remote Server), then the Destination address would look like this `http://samplenodecom:9080/cs/`
8. Enter the user name in **REMOTE USER** field.
9. Enter the password in **REMOTE PASSWORD** field.
10. Select the roles which approve the assets for publishing to this location.
11. Select the roles which can publish to this destination.
12. Select the sites for which this destination will be available.
13. Click on **ADD NEW DESTINATION** button in the bottom.

In this way, the Dynamic Publishing destination can be created.

Once the dynamic destination has been created, we need to check whether the destination is working properly or not. This can be known by observing the GREEN BULB image seen as shown in the image below. If a RED BULB image is shown, then there is some problem in connecting to the destination, like network issues, remote server might be down, licensing issues of the remote server for fatwire, VPN connectivity issues, etc. If any of the above issues arise, you need to consult the Fatwire / System Administrator of your company.

![image](https://github.com/aakash14goplani/OWCS/blob/master/images/dyn_pub_3.jpg)

### References 

* [kksays1](https://kksays.wordpress.com/2012/01/19/dynamic-publishing-in-fatwire/)
* [kksays1](https://kksays.wordpress.com/2012/01/20/dynamic-publishing/)