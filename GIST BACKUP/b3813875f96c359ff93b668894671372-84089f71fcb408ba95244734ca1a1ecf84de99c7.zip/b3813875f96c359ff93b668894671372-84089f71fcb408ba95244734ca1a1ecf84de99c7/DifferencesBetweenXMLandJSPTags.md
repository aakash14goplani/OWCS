# Handling Differences Between XML and JSP Tags in WebCenter Sites

In WebCenter Sites there is a common issue of using JSP tags that function differently than their XML counterparts, even though the tags share documentation.  
This can become a major issue when a developer is required to use JSP, for example when using a custom Java class in the element code.


* To counter this issue there is a function in the `ics` class called `RunTag`.  
* This function will run any tag as an XML tag and create all the necessary objects inside the JSP.  
* First the developer needs to identify all of the XML attributes the tag will need. Keep in mind that some of these attributes will have different names.  
* Then the developer needs to create an instance of `FTValList` (found at `COM.FutureTense.Interfaces.FTValList`).  
* The `FTValList` will allow the developer to create a `name/value` map.  
* In this case, the developer will want to create the map using the pattern attribute name/attribute value.  
* Once the `FTValList` has been created, the developer can run the `RunTag` function.


Here is an example for running the `RunTag` function on the `proprety:get` tag.

```jsp
FTValList attrs = new FTTValList();
attrs.setValString("PARAM", "xcelerate.batchpass");
attrs.setValString("INIFILE", "futuretense_xcel.ini");
attrs.setValString("VARNAME", "batchPassword");
String tagReturns = ics.RunTag("PROPERTY.GET", attrs);
```

The example code is retrieving the property `xcelerate.batchpass`. I chose this specific example because this is one of the places where JSP and XML differ. The JSP version of the `PROPERTY.GET` tag will not unhash the password, whereas the XML version will.


You may notice that the tag returns a string. This string will contain any output the tag itself might generate.  


Most tags in the system do not generate any output, so most of the time this string will be null. However, if the tag does output anything, that data will be available in the string.


All in all, it is important to remember to check the Java API section of the tag reference. WebCenter Sites tags have a great deal of functionality, the RunTag method is just one example. There are plenty of other methods in the Java API (more specifically the COM.FutureTense.Interfaces package included on each JSP) that will allow for even more control and functionality within any template that is written.   


### References
[teaminformatics](https://www.teaminformatics.com/blog/2013/09/12/handling-differences-between-xml-and-jsp-tags-in-webcenter-sites/) 