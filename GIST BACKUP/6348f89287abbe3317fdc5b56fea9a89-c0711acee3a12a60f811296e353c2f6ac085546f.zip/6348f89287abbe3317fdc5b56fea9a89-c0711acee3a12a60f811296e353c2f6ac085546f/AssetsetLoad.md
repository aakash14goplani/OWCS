`assetset` is used to load flex assets.   

### GENERAL STEPS TO FOLLOW:   

1. Load the flex asset (using `assetset:setasset` tag)
2. Use `assetset:getmultiplevalues` or `assetset:getattributevalues` to retrieve information after the flex asset is loaded.
3. Fetch attributes (looping through list using `ics:listloop` tag) In the following cases it is assumed that we know `c` and `cid`.   

### CASE 1:   
Retrieving flex attributes using `assetset:getattributevalues` tag

```jsp
<assetset:setasset name="flexAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar(" cid")%>' />	
<assetset:getattributevalues name="flexAsset" typename="Attribute_A" attribute="title" listvarname="titleList"/>
<assetset:getattributevalues name="flexAsset" typename="Attribute_A" attribute="body_text" listvarname="bodyTextList"/>
<ics:listloop listname="titleList">
  	<ics:listget listname="titleList" fieldname="value" />
</ics:listloop>
<ics:listloop listname="bodyTextList">
  	<ics:listget listname="bodyTextList" fieldname="value" />
</ics:listloop>
Error Single Value : <ics:geterrno />
```   

### CASE 2:
Retrieving flex attributes using `assetset:getmultiplevalues` tag   

```jsp
<assetset:setasset name="flexAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid ")%>' />	
<assetset:getmultiplevalues name="flexAsset" prefix="assetset"> 
  <assetset:sortlistentry attributetypename="Attribute_A" attributename="title" /> 
  <assetset:sortlistentry attributetypename="Attribute_A" attributename="body_text" /> 
</assetset:getmultiplevalues>   	
<ics:listloop listname="assetset:title"> 
  	<ics:listget listname="assetset:title" fieldname="value" /> 
</ics:listloop>   
<ics:listloop listname="assetset:body_text"> 
  	<ics:listget listname="assetset:body_text" fieldname="value" /> 
</ics:listloop>   
Error Multiple Value : <ics:geterrno /> 
```   

## XML Version   

```xml
<ASSETSET.SETASSET NAME="assetsetname" TYPE="assettype" ID="assetid" /> 
<ASSETSET.GETATTRIBUTEVALUES NAME="assetsetname" ATTRIBUTE="attribname" TYPENAME="ATTRIBUTE_A" LISTVARNAME="varname" /> 
<LOOP LIST="LIST_NAME"> 
  	<ICS.LISTGET LISTNAME="LIST_NAME" FIELDNAME="value" /> 
</LOOP>   

<ASSETSET.GETMULTIPLEVALUES NAME="assetset name" PREFIX="prefix" > 
   <ASSETSET.SORTLISTENTRY attributetypename="attribute type" attributename="attribute_name" />
</ASSETSET.GETMULTIPLEVALUES>
<LOOP LIST="PREFIX:attribute_name">
  <ICS.LISTGET LISTNAME="PREFIX:attribute_name" FIELDNAME="value" />
</LOOP>
```   

[JSP Documentation for assetset](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/assetset-setasset.html)   
[XML Documentation for assetset](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/XML/ASSETSET.SETASSET.html)