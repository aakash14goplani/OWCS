```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="asset" uri="futuretense_cs/asset.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ page import="java.text.SimpleDateFormat, java.util.regex.*, java.util.*, COM.FutureTense.Interfaces.*"
%><%
 /******************************************************************************************************************************
   *    Element Name        :  Practice/Automation/CreateNestedAssets 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (06/17/2018) 
   *    Description         :  This element reads the nested asset id & type and then makes a call to RemoveMetaData element
   *						   to fetch only details which will be written to CSV file and can be downloaded later. It replaces 
   *						   all "," with 4 underscores "____" to avoid problems while creating CSV file
   *    Input Parameters    :  c, cid
   *    Output              :  nested Asset Data in CSV format within ICS variable: csvString
 *****************************************************************************************************************************/
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if><% 
	
	try {
		String assetId = ics.GetVar("cid"), assetType = ics.GetVar("c");	
		ics.ClearErrno();
		
		%><ics:logmsg msg='<%="Calling RemoveMetaData with " + assetType + " : " + assetId + " from CreateNestedAssets" %>' severity="INFO" />
		<ics:callelement element="Practice/Automation/RemoveMetaData">
			<ics:argument name="cid" value="<%=assetId %>"/>
			<ics:argument name="c" value="<%=assetType %>" />
		</ics:callelement>
		<asset:getsubtype objectid="<%=assetId %>" type="<%=assetType %>" output="assetDefinition" />
		<ics:logmsg msg='<%="Calling DetermineAssetDatatypeAndValue with " + assetType + " : " + ics.GetVar("assetDefinition") + " from CreateNestedAssets" %>' severity="INFO" />
		<ics:callelement element="Practice/Automation/DetermineAssetDatatypeAndValue">
			<ics:argument name="assetDefinition" value='<%=ics.GetVar("assetDefinition") %>'/>
			<ics:argument name="assetType" value="<%=assetType %>" />
		</ics:callelement><%
			
		Map<?,?> attributeMap = (Map<?,?>)ics.getAttribute("actualData");
		String key = "", value = "", tempKey = "";
		StringBuffer sb = new StringBuffer();
		
		Map<String, String> valueMap = new HashMap<String, String>(); 
		valueMap = (Map<String, String>)ics.getAttribute("valueMap");
		Map<String, String> dataTypeMap = new HashMap<String, String>();
		dataTypeMap = (Map<String, String>)ics.getAttribute("dataTypeMap");
		
		for(Map.Entry<?,?> entry : attributeMap.entrySet()) {
			key = entry.getKey().toString();
			value = entry.getValue().toString();
			
			if(Utilities.goodString(dataTypeMap.get(key)) && dataTypeMap.get(key).equals("asset")) {
				value = value.replaceAll(",", "____");
				for(String singleAsset : value.split("____")) {
    				String singleAssetType = singleAsset.split(":")[0];
    				String singleAssetId = singleAsset.split(":")[1];
    				if( Utilities.goodString(singleAssetId) && Utilities.goodString(singleAssetType) ) {
    					sb.append("_NESTED_ASSET_CONTENT_START_");sb.append(",");
    					if( Utilities.goodString(valueMap.get(key)) && ( valueMap.get(key).equals("MULTI") || valueMap.get(key).equals("MULTI_ORDERED") ) ) {
    						sb.append(key + ":_IS_MULTIPLE_");sb.append("\n");
    					} else {
    						sb.append(key);sb.append("\n");
    					}
    					
	    				//if(!Utilities.goodString(ics.GetVar("skipAssetFields"))) {	
	    					%><ics:logmsg msg='<%="Calling CreateNestedAssets with " + singleAssetType + " : " + singleAssetId + " from CreateNestedAssets" %>' severity="INFO" />
							<ics:callelement element="Practice/Automation/CreateNestedAssets">
				    			<ics:argument name="cid" value='<%=singleAssetId %>'/>
				    			<ics:argument name="c" value='<%=singleAssetType %>' />
				    			<%-- <ics:argument name="skipAssetFields" value="true" /> --%>
				    		</ics:callelement><%
	    				//}
			    		//ics.RemoveVar("skipAssetFields");
	    				
			    		if(Utilities.goodString(ics.GetVar("csvString"))) {
			    			StringBuffer innerBuffer = new StringBuffer(ics.GetVar("csvString"));
			    			sb.append(innerBuffer);
			    		}
			    		sb.append("_NESTED_ASSET_CONTENT_END_");sb.append("\n");
	    			}
	    			ics.RemoveVar("csvString");
	    		}
			}
			
			if( Utilities.goodString(valueMap.get(key)) && ( valueMap.get(key).equals("MULTI") || valueMap.get(key).equals("MULTI_ORDERED") ) ) {
				if(tempKey.length() < 1) {
					tempKey = key;
				}
				if( Utilities.goodString(dataTypeMap.get(key)) ) {
					if(dataTypeMap.get(key).equals("date")) {
						tempKey = tempKey + ":_IS_DATE_";
					} else if(dataTypeMap.get(key).equals("blob") || dataTypeMap.get(key).equals("asset")) {
						/* ignore blob contents, ignore assets as they are already covered */
						key = "";
						value = "";
						tempKey = "";
					}
				}
				tempKey = tempKey + ":_IS_MULTIPLE_";
				value = value.replaceAll(",", "____");
			
			} else if( Utilities.goodString(valueMap.get(key)) && ( valueMap.get(key).equals("SINGLE") || valueMap.get(key).equals("SINGLEUNIQUE") ) ) {
				
				if( Utilities.goodString(dataTypeMap.get(key))) {
					if(tempKey.length() < 1) {
						tempKey = key;
					}
					value = value.replaceAll(",", "____");
					/* process single values */
					if(dataTypeMap.get(key).equals("date")) {
						tempKey = tempKey + ":_IS_DATE_";
					} else if(dataTypeMap.get(key).equals("blob") || dataTypeMap.get(key).equals("asset")) {
						/* ignore blob contents, ignore assets as they are already covered */
						key = "";
						value = "";
						tempKey = "";
					}
				}
			} else {
				/* handle logic for associations */
				if(tempKey.length() < 1) {
					tempKey = key;
				}
				tempKey = tempKey + ":_IS_ASSOC_";
				value = value.replaceAll(",", "____");
			}
			
			if(Utilities.goodString(tempKey) && Utilities.goodString(value)) {
				%><ics:logmsg msg='<%=tempKey %>' severity="INFO" /><%
				sb.append(tempKey);sb.append(",");
				sb.append(value);sb.append("\n");	
			}
			
			key = "";
			value = "";
			tempKey = "";
		}
		ics.SetVar("csvString", sb.toString());
		
		ics.RemoveVar("assetDefinition");
		ics.RemoveVar("c");
		ics.RemoveVar("cid");
		ics.removeAttribute("actualData");
		ics.removeAttribute("valueMap");
		ics.removeAttribute("dataTypeMap");
		attributeMap.clear();
		valueMap.clear();
		dataTypeMap.clear();
		
	} catch(Exception e) {
		out.println("<div class=\"error\">Exception Occured in CreateNestedAssets element: " + e.getMessage() + "</div><br/>");
	}
%></cs:ftcs>
```