### Unshare Assets from one site

To unshare asset you have to follow same process as you did in share asset, just one change - you have to mention only source publication id.   

```jsp
<asset:share name="publishAsset" publist='<%=source_pubid %>' /><% 
```

### Unshare assets from all sites   

```jsp
<asset:load name="assetObjName" type="<%=assetType %>" objectid="<%=assetId %>" />
<asset:sites name="assetObjName" list="siteNameList" />
<ics:listloop listname="siteNameList">
    <ics:listget listname="siteNameList" fieldname="id" output="site_id" />
    <asset:removesite name="assetObjName" pubid='<%=ics.GetVar("site_id") %>' />
</ics:listloop>
```