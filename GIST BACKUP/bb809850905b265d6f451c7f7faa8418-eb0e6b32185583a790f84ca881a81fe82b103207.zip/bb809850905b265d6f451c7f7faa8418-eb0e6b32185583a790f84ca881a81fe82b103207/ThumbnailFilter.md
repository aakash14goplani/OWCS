Out of the 4 flex filters provided by Oracle WebCenter Sites, one of the most important and useful filter is **THUMBNAIL CREATOR**.

The Purpose of this filter is to create THUMBNAILS from the images which we upload.

We will now see how to create thumbnails using this filter.

**CREATE A FLEX FAMILY:**

The Flex filter is a part of the Flex Family. So, in order to create any filter, we need to create the Flex Family.

After creation of the Flex family, enable the flex family members for your site.

**CREATE THE FOLLOWING FLEX ATTRIBUTES:**

1. **ImageFile** – (BLOB)
2. **ThumbnailFile** – (BLOB)
3. **ImageHeight** – (STRING)
4. **ImageWidth** – (STRING)
5. **ThumbnailWidth** – (STRING)
6. **ThumbnailHeight** – (STRING)

**CREATE NEW FLEX FILTER:**

1. Click on **New Sample Filter**.

2. Enter the Name, Description. Select **THUMBNAILCREATOR** option in the **FILTER** dropdown. Then Click on **Get Arguments** button.

3. In the **ARGUMENTS** Section, make sure that you specify values for all the options in the **NAME** drop down list. After adding all the values, the list should consist the following `key – value` pairs.

```
Output attribute for Thumb Height = ThumbnailHeight
Output attribute for Thumb Width = ThumbnailWidth
Output attribute name = ThumbnailFile
Input attribute name = ImageFile
Output attribute for Main Width = ImageWidth
Output attribute for Main Height = ImageHeight
Enter maximum pixel size = 100
```

**NOTE:** The Maximum pixel size is the size of the Thumbnail.

4. Click on **Save**.

**ADDING THE FLEX FILTER TO THE CONTENT DEFINITION:**

1. Add the filter to either new content definitions or existing content definitions.

2. Add the Flex Attribute **IMAGEFILE**, which was created by us above.

**FINALLY, TEST THE FILTER:**

Now, its time to test the filter which we have created. Create a new asset of type `SAMPLE_C`, and select the above content definition.

1. Give a name to the asset, and upload an image.

2. Save it.

3. Click on the INSPECT button. You can see the result screen which has the image file, thumbnail file, image height, image width, thumbnail height, thumbnail width.

We haven’t added the the attributes ThumbnailFile, ImageHeight, ImageWidth, ThumbnailWidth, ThumbnailHeight in our content definition. But still, they appeared in the element inspection screen.

So, the point to note here is that these 5 attributes are used internally by the filter class to store the dimensions (width and height) of the image and thumbnails, and to display them.

### References

[kksays](https://kksays.wordpress.com/2012/10/31/thumbnail-creator-flex-filter-in-oracle-webcenter-sites-fatwire/)