In WebCenter Sites templates, `context` is a system variable maintained internally. Its value is retrieved by using the `ics:getvar` JSP tag or the `ics.GetVar()` method.   

For example:
```jsp
<ics:getvar name=context/>
ics.GetVar(context)
```   

The value of context is determined by default. It is initially set to an empty string. Then, for every template called using `render:calltemplate` or `insite:calltemplate`, the value of `context` changes in the called template following this logic:   
```
if parent_context is empty
  context = <c>:<cid>:<tname>
otherwise
  context = <parent_context>;<c>:<cid>:<tname>
```   

### Defining the Scope of the Slot   

When defining a slot, it is possible for template developers to decide the scope of the slot. Typically, whether any presentation change made in this slot should be `local` or `global`.   

**local**: visible only on the currently edited web page     

**global** spanning across multiple web pages in a site (possibly, ALL web pages in a site)   

### Initializing the Context Value

The behavior observed in the previous section may be the intended behavior, but in some cases, editorial users will need to be able to make local presentation changes, that is, changes visible only on the current web page being edited.

To do this, the context variable has to be set to a value which will uniquely identify a given web page. In our case, it is enough to initialize context with, for example, the template name, and the identifier and type of the rendered asset:

```jsp
<ics:setvar
  name="context"
  value='<%=ics.GetVar("c")
  + ":" + ics.GetVar("cid")
  + ":HelloArticleLayout"%>' />
```   

Other parameters can be added to initialize the context, depending on the intended result. We can add the line above to the our template and verify that presentation changes are local to each article page.

### Context Override

Both the `render:calltemplate` tag and the `insite:calltemplate` tag have an optional context attribute, which can be used to override the current context.

### Context and Caching

Context is only useful when presentation editing capabilities are enabled on your site.

If that is not the case, context can be removed from every template's cache criteria (avoiding the creation of unnecessary duplicates in the page cache).


### References

[Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_siteassets.htm#WBCSD1955)