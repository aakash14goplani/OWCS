After completing your development and testing of your website in development system, the website is moved to the management system and then to production. In the whole process all the site data is exported and imported to another system in either Publishing Tool or Command Line Tool or from Eclipse. Below are the commands to export and import assets and asset types in webcenter sites.

### PREREQUISITES

1. Make sure the **csdt-client.jar** is in the classpath of system variable.
2. The user which is going to be used in the command to connected to server should be a **RestAdmin** group member.

### EXPORT COMMAND
Open command prompt and type the below command and run. The below command exports all data of **MyWebStore site** from devserver system into a local folder in envision folder **(Sites\11.1.1.8.0\export\envision\SiteData)**.

`java com.fatwire.csdt.client.main.CSDT  http://devserver:9080/cs username=publisher password=welcome1 resources=@ALL_ASSETS:*;@ALL_NONASSETS:* fromSite=MyWebStore datastore=SiteData cmd=export`

### IMPORT COMMAND
Move the exported data folder(D:\SiteNewData) to a folder in prodserver. Below command imports all data from the folder in prodserver.

`java com.fatwire.csdt.client.main.CSDT  http://prodserver:9080/cs username=publisher password=welcome1 resources=@ALL_ASSETS:*;@ALL_NONASSETS:* toSites=MyWebStore datastore=SiteNewData cmd=import`

### RESOURCES
Below is the list of resources can be export and import
```
@SITE: Specify the desired sites
@ROLE: Specify the desired roles
@ASSET_TYPE: Specify the desired asset types
@TREETAB: Specify the desired tree tabs
@STARTMENU: Specify the desired start menu items
@ELEMENTCATALOG: Specify the desired ElementCatalog entries
@SITECATALOG: Specify the desired site catalog entries
@ALL_NONASSETS: Use this short-hand notation to select all non-asset resources
@ALL_ASSETS: Use this short-hand notation to select all available assets
asset type: Specify assets of a certain type.
```

### EXPORT AND IMPORT FROM ECLIPSE
If are not comfortable with the commands. You can do this by taking help of eclipse workspace. If you have configured the eclipse with sources server and imported all the desired assets into eclipse workspace. Below are the steps

1. In the source server(devserver), take a copy of the workspace folder which has all the asset in the eclipse workspace. Generally it should be cs_workspace. This folder has src folder and it has -metadata, jsp sub folders.
2. Configure the eclipse with prod server.
3. Move the cs_workspace folder to the newly configured workspace id in the 2nd step.
4. Open eclipse and open Webcenter Sites perspective.
5. Refresh the Site Tree in the panel.
6. Click on Sync button. Then click on Sync to Webcenter Sites tab. Select all the desired items of @SITE type.
7. Click on Sync the Selection button.
8. The selection process should follow an order. Once all the asset of a type are completed then go for another type.
Repeat the 6 and 7 steps by select the asset of a type with below order list.
```
@SITE: Specify the desired sites
@ROLE: Specify the desired roles
@ASSET_TYPE: Specify the desired asset types
@TREETAB: Specify the desired tree tabs
@STARTMENU: Specify the desired start menu items
@ELEMENTCATALOG: Specify the desired ElementCatalog entries
@SITECATALOG: Specify the desired site catalog entries
@ALL_NONASSETS: Use this short-hand notation to select all non-asset resources
@ALL_ASSETS: Use this short-hand notation to select all available assets
asset type: Specify assets of a certain type.
```

**Note:** You can skip any asset type if you dont have any assets of the type.