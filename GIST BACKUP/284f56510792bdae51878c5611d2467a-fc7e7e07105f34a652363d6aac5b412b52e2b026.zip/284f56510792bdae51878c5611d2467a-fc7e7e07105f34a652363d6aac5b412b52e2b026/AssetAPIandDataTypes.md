### General Configuration

```java
Session sessionFactory = SessionFactory.getSession();
AssetDataManager assetDataManager = (AssetDataManager)sessionFactory.getManager(AssetDataManager.class.getName());			
MutableAssetData mutableAssetData = null;

mutableAssetData = assetDataManager.newAssetData(assetType, flexDefinition); //flex
mutableAssetData = assetDataManager.newAssetData(assetType, ""); //basic
```

### Data Type: Asset (Multiple)

```java
List<AssetId> assetIdList = new ArrayList<AssetId>();
assetIdList.add(new AssetIdImpl(asset_type, Long.valueOf(asset_id_1)));
assetIdList.add(new AssetIdImpl(asset_type_2, Long.valueOf(asset_id_2)));
assetIdList.add(new AssetIdImpl(asset_type, Long.valueOf(asset_id_3)));
assetIdList.add(new AssetIdImpl(asset_type_4, Long.valueOf(asset_id_4)));
mutableAssetData.getAttributeData(attributeName).setData(assetIdList);
```

### Data Type: Asset (Single)

```java
AssetId assetIdInstance = new AssetIdImpl(ics.getAttribute(asset_type, Long.valueOf(asset_id_1));
mutableAssetData.getAttributeData(attributeName).setData(assetIdInstance);
```

### Data Type: Date (Multiple)

```java
List<Date> dateList = new ArrayList<Date>();
dateList.add(date_1);
dateList.add(date_2);
dateList.add(date_3);
mutableAssetData.getAttributeData(attributeName).setData(dateList);
```

### Data Type: Date (Single)

```java
Date singleDate = new SimpleDateFormat("EEE MMM dd hh:mm:ss 'UTC' yyyy").parse(date);
mutableAssetData.getAttributeData(attributeName).setData(singleDate);
```

### Data Type: String, Money, Float, INT, Text (Multiple)

```java
/* all datatypes String, Money, Float, INT, Text are internally stored as string */
String new_attribute_value[] = attributeValue.split(","); //multiple attributes in array e.g. c1:cid1,c2:cid2,...
mutableAssetData.getAttributeData(attributeName).setData(Arrays.asList(new_attribute_value));
```

### Data Type: String, Money, Float, INT, Text (Single)

```java
/* all datatypes String, Money, Float, INT, Text are internally stored as string */
mutableAssetData.getAttributeData(attributeName).setData(attributeValue);
```

### Data Type: BLOB (Multiple)

```java
List<BlobObject> blobList = new ArrayList<BlobObject>();
blobList.add(new BlobObjectImpl("filename1.txt", null, "body1".getBytes()));
blobList.add(new BlobObjectImpl("filename2.txt", null, "body2".getBytes()));
mutableAssetData.getAttributeData("urlbody").setData(blobList);
```

### Data Type: BLOB (Single)

```java
BlobObject b = new BlobObjectImpl("filename.txt", null, "body".getBytes());
mutableAssetData.getAttributeData("urlbody" ).setData(b);
```

### Associations (Same for Single/Multiple)

```java
List<AssetId> associationList = new ArrayList<AssetId>();
associationList.add(new AssetIdImpl(asset_type, Long.valueOf(asset_id))); // if sindle
associationList.add(new AssetIdImpl(asset_type_2, Long.valueOf(asset_id_2))); // keep on repeating for multiple
mutableAssetData.setAssociation(attributeName, associationList);
```

### WebReference (Single) 

**More details at [function1 blog post](https://www.function1.com/2016/09/how-to-programmatically-create-vanity-urls)**

### WebReference (Multiple)

```java
Iterable<AssetData> assetdataItr = assetDataManager.read(Arrays.asList(new AssetIdImpl( assetType, assetId )));
List<AssetData> updateAssets = new ArrayList<AssetData>();
List<WebReference> webReferenceList = new ArrayList<WebReference>();
String templateName = ics.GetVar("templateName"); //refer LoadAssetInfo and GetAssetInfo 
String webReferenceString = ics.GetVar("webReferenceString"); //refer LoadAssetInfo and GetAssetInfo

/*
webReferenceString format [AssetURL= page_1WebRoot= site_name,AssetURL= page_2WebRoot= site_name,AssetURL= page_3WebRoot= site_name]
*/

if( webReferenceString.contains("AssetURL=") && webReferenceString.contains("WebRoot=") ) {
  webReferenceString = webReferenceString.substring(1, webReferenceString.length() - 1);
  for(String component : webReferenceString.split(",")) {
    assetURL = component.substring((component.indexOf("AssetURL=") + "AssetURL=".length()), component.indexOf("WebRoot=")).trim();
    webRoot = component.substring(component.indexOf("WebRoot=") + "WebRoot=".length()).trim();
    webReferenceList.add(new WebReferenceImpl(webRoot, assetURL, new java.lang.Integer(200), templateName));
  }

  for(AssetData a : assetdataItr) {
      updateAssets.add(a);
      if(webReferenceList != null && webReferenceList.size() > 0) {
        a.getAttributeData("Webreference").setData(webReferenceList);
      }
  }
  if(ics.GetErrno() == 0) {
      assetDataManager.update(updateAssets);
  }
}
```