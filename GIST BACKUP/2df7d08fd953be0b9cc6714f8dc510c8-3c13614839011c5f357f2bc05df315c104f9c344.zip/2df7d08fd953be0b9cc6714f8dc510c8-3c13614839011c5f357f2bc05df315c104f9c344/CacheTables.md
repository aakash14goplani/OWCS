The cache manager keeps track of the information about the PAGES that need to be cached, and the ASSETS that are referred by these CACHED PAGES, the CacheManager makes use of a few DataBase tables. They are as follows:

1. **SystemPageCache Table:**  When ever a new page is to be added to the cache, a new ROW is created in this table, by the CacheManager. Hence, ONE ROW FOR ONE PAGE. When the page expires, its corresponding row is removed from the table. Hence, depending on the pages in the cache, this table expands / contracts accordingly.

2. **SystemItemCache Table:**   We know that the page refers to other assets like images, pagelets, blobs, etc. For storing the information about those items which are referred by the CACHED PAGES, this table is used. Here also, the formula is same. ONE ROW FOR ONE ASSET. Depending on the assets referred by the cached pages, this table also expands / contracts accordingly.

For example, if a Page (Cached Page) is created from a page Asset that has associations to four article assets, there would be five rows for that cached page (One row for PAGE ASSET, and Four rows for Article assets), in the SystemItemCache table.

As and when the pages expire, or when the assets referred by these pages are modified, the CacheManager Adds / Removes the Pages / Assets to the tables specified above.

To view the content of these tables, just open the CS-EXPLORER, enter your log-in details. Expand the TABLES directory. You will be able to see the above stated tables, and their contents.

### References

[kksays](https://kksays.wordpress.com/2013/02/15/cache-management-tables-in-fatwire-oracle-webcenter-sites/)