### Find all available variables on a page   

FatWire offer a simple method in the `ics` library `GetVars()` which returns an enumeration of all the variables in all scopes accessible at that instance.   

```jsp
<%
	Enumeration em = ics.GetVars();
	while (em.hasMoreElements()) {
		String key = (String)em.nextElement();
		out.println(" key is " + key + " value " + ics.GetVar(key));
	}							
%> 
```