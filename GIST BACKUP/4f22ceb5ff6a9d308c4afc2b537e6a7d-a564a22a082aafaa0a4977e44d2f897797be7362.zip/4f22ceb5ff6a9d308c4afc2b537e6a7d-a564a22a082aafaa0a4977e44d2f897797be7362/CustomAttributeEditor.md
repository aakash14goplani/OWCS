Fatwire ships with a lot of Attribute Editors, like TextArea, TextField, etc. But sometimes, you may require to create some custom attribute editors.

Example:

When the author enters some unwanted value in the attribute field, you may want to display some message, or an alert to the user. In such a case, the system attribute editors will not be helpful. You need to create a custom attribute editor. This is just a weird example. But there might be some serious situations, where you require the usage of custom attribute editors.

To create a custom attribute editor, you need to CREATE two things :

1. The main ELEMENT (CSElement) which defines the behavior of the Attribute Editor.
2. The Attribute Editor XML file, which we generally create in the Administrator UI.

### Creation of the CSELEMENT:

Points to be Noted:

1. The name of the ELEMENT (CS-Element) must be the same name, as which we use in the attribute editor code. For example, the following `TEXTAREA` tag has a default `TEXTAREA.xml`
```xml
<PRESENTATIONOBJECT NAME=”TextAreaTest”>
<TEXTAREA>        …….     This TEXTAREA refers to the TEXTAREA.XML Element
</TEXTAREA>
</….>
```

2. The new ELEMENT must be placed under the following path :

**OpenMarket/Gator/AttributeTypes/[ELEMENT-NAME]**

For the sake of simplicity, I would like to Create a custom attribute editor called **My_TextField_Editor** with the features of TextArea attribute editor, along with my custom changes. Hence, I need copy the features of `TEXTAREA` attribute editor, and want to add some other features.

So, create a new CS-Element with **OpenMarket/Gator/AttributeTypes/My_TextField_Editor**. (Include your own features along with the TEXTAREA element).

### Creation of the Attribute Editor:

Now, that the element is created, we need to create the Attribute Editor.

Create an Attribute Editor with the same name of the ELEMENT, i.e, **My_TextField_Editor** (in this case).

```xml
<<<<<Code for Attribute Editor goes here…>>>>
<PRESENTATIONOBJECT NAME=”Sample”> <My_TextField_Editor>
</My_TextField_Editor> </PRESENTATIONOBJECT>
<<<<<Code for Attribute Editor goes here…>>>>
```
 
That’s it.

Your new CUSTOM ATTRIBUTE EDITOR is created.

Now, To check the attribute editor, create an attribute, include it in a content definition, and then try to create the content. In the content creation screen, the design of the custom attribute editor appears.

### References

[kksays](https://kksays.wordpress.com/2013/02/01/creating-a-custom-attribute-editor-in-fatwire-oracle-webcenter-sites/)