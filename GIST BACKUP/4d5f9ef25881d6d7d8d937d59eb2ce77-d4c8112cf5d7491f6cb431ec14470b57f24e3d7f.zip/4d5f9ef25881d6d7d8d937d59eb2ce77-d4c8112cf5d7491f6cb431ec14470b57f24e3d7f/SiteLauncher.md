In the real world implementation, there may be more than one web-site that a company maintains.

For example, lets assume that we have client called “X”. This client has engaged with the Oracle WebCenter Sites developers team to get a Content Management Site created, say `http://www.MySiteOne.com`. The client has later come up with a requirement to create another site called `http://www.MySiteTwo.com` using Oracle WebCenter Sites / Fatwire.

To create a new site from scratch, we need to create all the stuff like attribute editors, asset types, templates, elements, etc.

Oracle WebCenter Sites / Fatwire comes with a utility that can be used in such a situation, which will replicate the structure of an existing site (please mind that the first site is also created using Fatwire), and creates a  new site automatically with all the above said stuff such as attribute editors, asset types, templates, elements, etc.

This utility tool provided by Oracle WebCenter Sites is called as SITE LAUNCHER UTILITY.

### Site Launcher Overview

To minimize your effort in creating new sites, WebCenter Sites provides a site-replication utility called **Site Launcher**. This utility is designed not for backing up CM sites, but for spinning them off.

Some important points to be noted about the Site Launcher utility.

* Site Launcher replicates source sites directly on their native WebCenter Sites system, reusing the existing database schema. The sites are replicated quickly and easily, without the need for coding.
* Site replication can be carried out only by the general administrator.
* We can either copy or share the assets (templates, asset types, attributes, etc) between both the sites.
* While COPY of assets will create a new set of assets into the site, SHARING will share the same asset between both the sites
* In the new site, we can remove the existing assets, or add new assets according to the requirements
* New asset types, templates, elements etc can be created in the new site.
* New users can be created for the newly created site.
* Site Launcher can be used to replicate almost any CM site: small, large, functional,incomplete, independent of other sites, and overlapping other sites by the sharing of components.

### References

[kksays](https://kksays.wordpress.com/2013/10/09/site-launcher-in-oracle-webcenter-sites-fatwire/)