# Database Manager for JumpStart

If you use Oracle or SQLServer, you can always access the database with a SQL Interface: just use the client provided with your database.

A database client is useful for many tasks: I usually manage the cache, look for the fields I have to use in code, do mass changes to assets accessing directly to the database.

Actually, Jump Start Kit ships with HSQLDB as a database. It is a java only database running embedded in tomcat. In fact, it HAS an SQL client, already included in his jar. But there was no way to activate it... until now. Here is the trick.

The simplest way I found is just to add the file dbman.jsp file under the `App_Server/apache-tomcat-6.0.18/webapps/cs`. The code of this script is simply:

```jsp
<%
String s = "jdbc:hsqldb:file:"+getServletContext().getRealPath("/")+"../../default/data/hypersonic/csDB";
org.hsqldb.util.DatabaseManagerSwing.main(new String[]{ "--url",s });
%>
```

This code tries to be independent of the actual installation folder of the database, but I have tested so far only in my installation.

Now you can call `http://localhost:8080/cs/dbman.jsp` and you will have access to the following window:



Please note this works only with the JumpStartKit running in your local machine because it opens a new GUI window, not a web interface.