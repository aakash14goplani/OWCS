# Fundamental concepts of WCS.

Let's discuss some of the important layers in the WCS:


### Content Server

The first layers is Content Server in the proper sense. Although until recently the official name of the whole content management product was "Fatwire Content Server", in the original naming Content Server is only the first layer. Content Server is basically an XML based web programming language, similar (as a concept - not in the specific details) to ColdFusion, a web programming language that was "hot" at the time of the initial development of the product (around 1995).


Content Server was further extended adding to the XML based programming language (that is still there) a more powerful and more standard JSP based programming language. Both the XML and the JSP share the same underlying libraries, so everything that can be done in XML can be also implemented in JSP.


ContentServer however is mostly just an execution environment, with some features like security and caching, but it has no concept of assets, nor a proper user interface (except a very limited one used  mostly to configure security). You can think to it like a sort of  JSP engine, more powerful than just the JSP engine you can find in a standard application server, but definitely not an application.


It is the underlying engine used by the other components.

### Xcelerate

When you use WCS, you normally expect to log into it and manage some content. Built on top of ContentServer, there is the Xcelerate application, that has a web user interface. Xcelerate is different from ContentServer since the former is built with the latter. Xcelerate also features a rich user interface, allowing to create and edit content.


Xcelerate implements the more important concepts of WCS: the Asset. There are some predefined assets like the Page and the Template, and more assets can be created. Xcelerate actually implements only the concept of Basic Asset, giving you the ability to create more basic asset definition  using the Asset Maker. In the original design, Xcelerate is an engine good for developing even complex web sites but with having a content model that is pretty stable and not expected to be changed often.


### Gator

A further extension of Xcelerate is Gator, that basically implements the concept of Flex Asset. Flex Asset were originally designed to easily implement e-commerce web sites. A typical problem of e-commerce is that the content model can be very complex and changed often, sometimes daily, so the Basic Assets were not enough flexible for this purpose.


Flex Assets fulfill the flexibility this requirement, providing the ability to change the content model easily,  keeping the existing content safe, and allowing an easy update of the site, as simple as the publishing.


Publishing, normally used to just update the content, cannot be used to update the content model when using only basic assets. But you can update the content model using Flex Assets, and then just publish them to update the site.


Gator also implements the ability to customize the administrative user interface introducing also the concept of Attribute and Attribute Editor.

### Engage

Another layer is Engage (once called "Marketing Studio") that further extends the feature set of the system, providing the ability to store attributes of the user (Visitor Attributes), build rules based on them (Segments) and generate content dynamically (using the so-called Recommendations and Promotion).