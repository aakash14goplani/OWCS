**Login to WEM Admin using folloeing credentials : username : `fwadmin` and password : `xceladmin`.**

### General Steps to create User

1. Click on **Users** tab.
2. Click on **Add User**
3. Enter all the details (do assign ACL as per requirements and don't forget to assign user with proper groups, especially _RestAdmin_ if you planning to sync eclipse with OWCS)
4. Click on **Save and Close**

### General Steps to create Site

1. Click on **Site** tab.
2. Click on **Add Site**
3. Enter all details and click on **Save and Close**

### Assign User to Site

1. Under **Site** tab, hover on the site for which you want to enable user and select **Manage Site Users**
2. Click on **Assign Users**
3. Select the user that you would like to assign to your site and click on **Continue**
4. Assign the required roles and click on **Save and Close**

### Assign Apps to Site

1. Under **Site** tab, hover on the site for which you want to enable user and select **Manage Site Apps**
2. Click on **Assign Apps**
3. Select the app that you would like to assign to your site and click on **Continue**
4. Assign the required roles and click on **Save and Close**

### References

[Javier Ductor Blogspot](http://javierductor.blogspot.in/2016/01/creating-new-site-in-webcenter-sites.html)