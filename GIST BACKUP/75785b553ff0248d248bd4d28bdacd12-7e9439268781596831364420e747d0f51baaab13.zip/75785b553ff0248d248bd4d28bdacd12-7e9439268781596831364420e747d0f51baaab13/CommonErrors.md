# Common errors and their Prevention

1. Error: `ics:listloop` tag failure

**Root Cause**: This error occur if asset type `c` and/or asset Id `cid` passed to tag `<assetset:setasset/>` or `<asset:load/>` is **NULL**.
```
<ics:listloop listname=”myList”>
…
</ics:listloop>
```
**Solution**: Always apply null check before iterating a list.
```
<ics:if condition='<%=null != ics.GetList(“myList”) && ics.GetList( “myList” ).hasData() %>’>
  <ics:then>
    <ics:listloop listname=myList”>
      …
    </ics:listloop>
  </ics:then>
</ics:if>
```

2. Error: Invalid type specified: Page

**Root Cause**: This error occurred, If type passed to `<assetset:setasset/>` tag is a basic asset eg. Page. As Page asset is basic type asset. And this tag is meant to load Flex Asset.
This code will give “**Invalid type specified: Page**” error:
```
<ics:setvar name=”c” value=”Page“/>
<ics:setvar name=”cid” value=”123456789″/>
<assetset:setasset name=”asset” type='<%=ics.GetVar(“c”)%>’ id='<%=ics.GetVar(“cid”)%>’ />
```
**Solution:** Check asset type and use <asset:load> tag for basic assets.
```
<ics:setvar name=”c” value=”Page“/>
<ics:setvar name=”cid” value=”123456789″/>
<ics:if condition='<%=“Page”.equals(ics.GetVar(“c”)) %>’>
  <ics:then>
    <asset:load name=”AsscAsset” type='<%=ics.GetVar(“c”)%>’ objectid='<%=ics.GetVar(“cid”)%>’/>
      …
  </ics:then>
  <ics:else>
    <assetset:setasset name=”AsscAsset” type='<%=ics.GetVar(“c”)%>’ id='<%=ics.GetVar(“cid”)%>’ />
      …
  </ics:else>
</ics:if>
```

3. Error: Need a ‘ID’ field & Need a ‘Type’ field

**Root Cause**: This error occur if we try to iterate through an uninitialized list.
**Solution**: We should put NULL check on c and/or cid in such a situation where there is possibility for NULL value.
```
<ics:if condition='<%=ics.GetVar(“c”) != null && ics.GetVar(“cid”) != null %>’>
  <ics:then>
    <assetset:setasset name=”myAsset” type='<%=ics.GetVar(“c”)%>’ id='<%=ics.GetVar(“cid”)%>’/>
      …
  </ics:then>
</ics:if>
```

4. Error: `ics:setvar` missing or empty argument value

**Root Cause:** This error occur if we try to set null as value in `<ics:setvar />` tag.
**Solution:** Set some Default value for variable at the top of the page or Write code in a manner so that no chance to _NullPointer_, _NumberFormat_ exception.

5. Error: no object named `<ObjectName>`

**Root Cause**: This error occurred when asset loaded is _NULL_ and we are trying to get data from the object.
```
<asset:load name=”TestObject” type='<%=ics.GetVar(“c”) %>’ objectid='<%=ics.GetVar(“cid”) %>’ />
<asset:get name=”TestObject” field=”id” output=”asset:cid”/>
```
**Solution:** Put _NULL_ check on object before getting data out of it.
```
<asset:load name=”TestObject” type='<%=ics.GetVar(“c”)%>’ objectid='<%=ics.GetVar(“cid”) %>’ />
<ics:if condition='<%=ics.GetObj(“TestObject”) != null %>’>
  <ics:then>
    <asset:get name=”TestObject” field=”id” output=”asset:cid”/>
  </ics:then>
</ics:if>
```

6. Error: Error -101 in tag ics:selectto with table Template_Composition

**Root Cause**: If there is no record found for SQL for tag `<ics:selectto/>`, then it returns (-101) Error code.
**Solution:** I will suggest to use SQL query (using `<ics:sql />` tag) instead of <ics:selectto/>. Also Its always good to use SQL query (with join in 3-4 tables) instead of `<asset:load>` tags. Its a trade off and you are the best person to decide which one to use. 

7. Overlooking the caching behaviour of `render:calltemplate`


**Root Cause**:
* The behaviour of render:calltemplate is: retrieve a cached element if it is available, or execute the code to generate the html, then cache its output. In general, in 99% of the cases, calltemplate should NOT be executed: it should instead return a cached element. This behaviour has a deep impact on the way template code must be written.

* If you write your code incorrectly, the template cannot be cached. As a consequence, performances will be very bad, because retrieving content from the database is very expensive. This is the whole reason because there is a caching in place: avoiding to retrieve content from the database every time.

**Solution:**
What render:calltemplate really does
Probably the name of the tag itself is misleading: many developers thinks that calltemplate will actually always CALL a template every time. It actually does not always happen.

Calltemplate takes all the parameters it was called with, order them in alphabetical order and build a string like `c=xxx,cid=yyy,p=zzz,site=xxx,...` (note the alphabetical order to make sure that you do not have `cid=yyy,c=xxx` different from `c=xxx,cid=yyy` when you have the same `xxx` and `yyy`))

This string is used as a key for the cache, then the cache is looked for. If a cached element is found, the cached output is returned. Otherwise, the referred template is invoked and the code executed. In general executing a template can be very expensive, performance wise. Getting attributes from the database may require a lot of queries, many of them involving a join (another expensive operation if you have large tables).

To get high performances, in general you should try to get zero calls to the database in 99% of the calls.

Each template has a list of parameters that will be used as "cache criteria". When you call the template, the list of parameters is checked against this cache criteria. If you call a template with a parameter that is not listed as a cache criteria a warning in the log is generated.

Please note that instead the `render:callelement` has a different behaviour: it is always invoked and it is usually used to invoke standardized html generation logic.

You do not have restrictions on the arguments you pass to a callelement, because its output will not generate a separate cached element: instead its output will cached as part of the calling template. Of course if it is database intensive then it will have bad performances.

What you cannot do in a cached template
Given this behaviour, there is a number of coding practice that are forbidden

First and before all, side effects. You cannot set a variable in the environment (something like ics.SetVar("flag", "something") and use it as an implicit parameter for a called template. Something that instead you usually have to do to use a callelement to retrieve informations. Side effects are actually the only way to get return values from an utility element.

Because the template can be cached, all the parameter must be explicitly stated, otherwise you may get the wrong template. The implicit paramente will not work unless the template is uncached (and this is not good for performances).

Another mistake is using a parameter that can change too often. For example, you may pass an uniquely generated id to a template.

Even if this id is correctly added to the cache criteria, the problem here is that a different id will create a new cached element every time the template is invoked. If you have a site with millions of users, you will end up generating a new cached element for each request!

The result here is a that the cache can became very large. I have seen sites with id passedin absolute freedom growing the cache at the rate of one thousand elements per minute!!!

This mistake will affect performance, but even worse  publication. Because publication involves invalidating the cache,  with a cache out of control, invalidating may take hours…

### References

[mkbansal](https://mkbansal.wordpress.com/2010/07/07/fatwire-common-errors-and-their-prevention/#Error1)   
[sciabarra](http://www.sciabarra.com/fatwire/category/tips-and-trick/)