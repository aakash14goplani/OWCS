You will face a problem when you try to configure eclipse with oracle webcenter sites for remote connections. The webcenter sites eclipse plugin wont create the **WEB-INF** folder with libraries properly for remote connections. So that you will see some syntax errors and a red icon on project folder name in Project Explorer. You can see that in the below screenshot.

 ![webcenter sites eclipse project issue](https://github.com/aakash14goplani/OWCS/blob/master/images/webcenter-sites-eclipse-project-issue2.png)

### REASON

This is an official issue that the eclipse can not get the required webcenter sites libraries from the remote server into local server. So the lib folder will be empty in WEB-INF folder and the built process may be failed.

### SOLUTION FOR WEBCENTER SITES PROJECT ISSUE WITH ECLIPSE

If you have configured the eclipse in remote server and working fine then you can manually copy the WEB-INF folder form remote server to your local project folder.

1. Copy the **WEB-INF** folder and right click on eclipse projet folder and Paste webcenter sites eclipse paste **web-inf folder**

2. Click on **Yes to All** webcenter sites eclipse paste **web-inf folder 2**

It will overwrite all the files and folder in **WEB-INF** folder. Then after that the errors will be gone magically. If they are not, restart the eclipse.
webcenter-sites-eclipse-project-is gone

This is also clearly specified in the oracle documentation. This is for them who missed this point.

Note: If you can’t get any WEB-INF folder from your remote server. Put your comment at below i will provide you the files.