We use the term “Admin” / “Administrator” frequently. But, there are different types of Administrators defined by the Content Server in Fatwire. We will now see the different types of Administrators in Fatwire:

1. **General Administrator:**  He is the normal Administrator. He is responsible for managing all systems in the Content Server environment and has full and unrestricted access to each system’s interfaces. He is also responsible for the creation of other users, creation of ACLs for them, and managing them.

2. **Site Administrator:** He is the admin for a particular Site / Sites. He has access only to the site he is granted, and this user is generally created and manged by the General Administrator.

3. **Workflow Administrator:** He is the one, who creates workflow processes. He creates the workflow processes, and the rest of the users participate in the workflow.


This is an overview of Administrators in Fatwire. Basing on the requirements, the above said roles will be created.

### References

[kksays](https://kksays.wordpress.com/2012/02/13/types-of-administrators-in-fatwire/)