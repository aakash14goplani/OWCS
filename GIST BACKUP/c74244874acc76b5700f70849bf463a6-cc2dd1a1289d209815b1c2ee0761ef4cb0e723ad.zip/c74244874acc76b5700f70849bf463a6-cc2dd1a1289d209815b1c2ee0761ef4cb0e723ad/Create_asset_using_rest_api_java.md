Make sure you have following jars in your class path
```
cas-client-core-3.1.9.jar 
commons-logging-1.1.3.jar
hk2-api-2.3.0-b05.jar
hk2-locator-2.3.0-b05.jar
hk2-utils-2.3.0-b05.jar
javax.inject-2.3.0-b05.jar
javax-servlet-api-3.0.1.jar
javax-ws-rs-api-2.0.jar
jersey-client-2.9.jar
jersey-common-2.9.jar
jersey-guava-2.9.jar
jettison-1.0.1.jar
sites-rest-api.jar
sites-sso-api.jar
sites-sso-cas-impl.jar
spring-beans-4.3.0.RELEASE.jar
spring-context-4.3.0.RELEASE.jar
spring-core-4.3.0.RELEASE.jar
spring-expression-4.3.0.RELEASE.jar
```

### Sample Code using Jersey (Java)

```java
<%@ taglib prefix="asset" uri="futuretense_cs/asset.tld"
%><%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ page import="com.fatwire.rest.beans.*,
    com.fatwire.rest.beans.Attribute.Data,
    com.fatwire.wem.sso.*,
    com.sun.jersey.api.client.*,
    com.sun.jersey.api.client.WebResource.Builder,
    java.io.*,
    java.net.*,
    javax.ws.rs.core.MediaType,
    org.apache.commons.io.*,
    org.apache.commons.lang.*"
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if><% 
	
	// Step 1: Initiate Jersey client
  	Client client = Client.create();

	// Step 2: Create a WebResource with the base URL
	WebResource webResource = client.resource("http://localhost:9080/cs/REST");

	// Step 3: Authenticate over SSO-CAS to acquire a ticket specific to a
	// service or a multi-ticket over multiple services.
	SSOSession ssoSession = null;
	String multiticket = null;
	try {
		ssoSession = SSO.getSSOSession("my-ssoconfig.xml");
		/*you can use default session too: ssoSession = SSO.getSSOSession();*/
		multiticket = ssoSession.getMultiTicket("fwadmin", "xceladmin");
		/* If the multiticket is not correctly passed in the GET request for the REST resource, then Sites will not have a valid ticket and will deny the request. */
	} catch (SSOException e) {
		e.printStackTrace();
	}
	
	// Step 4: Provide the ticket into the REST request
	webResource = webResource.queryParam("multiticket", multiticket);

	String flexAssetSiteName = "ABC";
	String flexAssetTypeName = "tWidget_C";
	String flexAssetId = "0"; //0 for new assets

	// Step 5: Specify the REST Resource URL into the WebResource
	// For creating assets of type {typename} in the CS site {sitename},
	// this is: {base_url}/sites/{sitename}/types/{typename}/assets/0
	webResource = webResource.path("sites").path(flexAssetSiteName).path("types").path(flexAssetTypeName).path("assets").path(flexAssetId);

	// Step 6: Create a Builder and set the desired response type
	// Supported response types are:
	// MediaType.APPLICATION_XML, or,
	// MediaType.APPLICATION_JSON
	Builder builder = webResource.accept(MediaType.APPLICATION_XML);

	//Create AssetBean to send in PUT request to REST resource to create asset
	AssetBean attributeBean = new AssetBean();
	attributeBean.getPublists().add("ABC");
	attributeBean.setName( "Attribute_REST_API");
	attributeBean.setSubtype("FORM_CONTENT");

	//Set type: asset, blob, date, float, int, money string, text
	Attribute attr = new Attribute();
	Data data = new Data();
	attr.setName("insert_title");
	data.setStringValue("string");
	attr.setData(data);
	attributeBean.getAttributes().add(attr);

	//Set valuestyle S=single, N=single (unique), M=multiple, O=multiple (ordered)
	attr = new Attribute();
	data = new Data();
	attr.setName("valuestyle");
	data.setStringValue("S");
	attr.setData(data);
	attributeBean.getAttributes().add(attr);

	//Set editing L=Local, R=Remote
	attr = new Attribute();
	data = new Data();
	attr.setName("editing");
	data.setStringValue("L");
	attr.setData(data);
	attributeBean.getAttributes().add(attr);

	//Set storage L=Local, R=Remote
	attr = new Attribute();
	data = new Data();
	attr.setName("storage");
	data.setStringValue("L");
	attr.setData(data);
	attributeBean.getAttributes().add(attr);
	
	builder = builder.header("X-CSRF-Token", multiticket);
	AssetBean resultAsset = builder.put(AssetBean.class,attributeBean);
	
	if(ics.GetErrno() == 0)
		out.println("Asset Created Successfully!");
	else
		out.println("Asset Creation Failed!");
	
%></cs:ftcs>
```

* **my-ssoconfig.xml** file to be placed under `/WEB-INF/classes`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:context="http://www.springframework.org/schema/context" xsi:schemaLocation="
http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-2.5.xsd
http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-2.5.xsd">
	<bean id="ssoprovider" class="com.fatwire.wem.sso.cas.CASProvider">
		<property name="config" ref="ssoconfig" />
	</bean>
	<bean id="ssoconfig" class="com.fatwire.wem.sso.cas.conf.CASConfig">
		<property name="casUrl" value="http://localhost:9080/cas" />
	</bean>
</beans>
```