WebCenter Sites provides several options for logging error messages and debugging source code. WebCenter Sites can log its activity in a log file, which in a new installation, is named sites.log, located in the logs folder.

The webcenter sites log4jthe WebCenter Sites Admin interface provides the **Configure log4j** tool in the System Tools node, on the Admin tab. Using **Configure log4j**, you can view current loggers directly from the Admin interface. You can also dynamically add new loggers and change logger levels. logging levels can be set to a greater severity (such as INFO or DEBUG), which provides a large amount of information. The different logging levels in webcenter sites are TRACE, DEBUG, INFO, WARN, ERROR, FATAL & OFF.

1. **TRACE:** It is a more detailed logging level than DEBUG for Content Server logging.

2. **DEBUG:** It is a detailed logging level for Content Server logging. It will capture details on the process execution of Content Server.

3. **FATAL:** It is a logging level that will just log FATAL messages; it will log less information than the ERROR or INFO levels.

4. **ERROR:** It is a “light” logging level, just ERROR messages will be logged when you use this logging level.

5. **INFO:** It is the default logging level for Content Server logging. Just operations marked as INFO will be logged if this logging level is enabled.

It will reduce significantly the information logged in the log. JSP compilation warnings wont be logged with these logging levels.

Because enabling any of these logging levels can affect performance, you should not enable these options unless you are either troubleshooting with a particular problem or support requires you to change it. This logger will write several information in the logs. If all the loggers are set to this logging level, your application can decrease the performance in terms of slowness.