Following are some of the important properties related to PAGE CACHING in `FUTURETENSE.INI` file.

#### 1. cs.nocache
This forcibly disables the adding and serving of pages from cache. Legal values are true and false.

#### 2. cs.pgCacheTimeout
This is the default lifetime of a cached page, specified in minutes. Specify 0 (zero) to never time pages out from the cache.

Sites that use intelligent page  cache invalidation through CacheManager, including CS Direct sites written using CS Direct 4.0 coding practices and later, will be able to rely on automatic cache invalidation so timeout is not relevant.

Only advanced users should modify the value of this property.  Setting it to a value greater than zero when Satellite Server is used can result in pages that cannot be ever be explicitly removed from the Satellite Server cache.

#### 3. cc.SystemPageCacheCSz
This is the maximum number of pages that will be cached in memory.  Pages will still be cached to the database but for better performance pages should be cached to memory too.  This property allows you to specify how many pages will live in memory.  Default value is 10,000, reduce if memory is at a premium.  Performance may suffer.

#### 4. cc.SystemPageCacheTimeout
This is the default lifetime of a cached page in memory.  Cached pages will live in the database until they are set to expire but for performance reasons pages are also cached in memory.  This specifies the timeout (minutes) of the memory cache.  If memory is at a premium you may shrink this value but it is set to 24 hours (1440 minutes) by default.

#### 5. cs.alwaysusedisk
This specifies the default behavior for page entries in the site catalog that have no specific cache override property. If set to yes, then pages served from the Content Server will be cached unless explicitly specified otherwise in cacheinfo. Though the name indicates that pages are cached to disk, they are in fact cached to the database using url-columns.

Legal values are yes and no.

#### 6. cs.freezeCache
This controls whether Content Server expires cached pages on a schedule.  Specify yes to prevent the creation of an event to periodically clear the page cache.  No pages whose expiry date has passed will ever be served regardless of this property value because their expiration is checked immediately prior to serving.

Legal values are yes and no.

#### 7. cs.manage.expired.blob.inventory
This property specifies whether or not blob dependencies will be flushed from the inventory (SystemItemCache table) when the blob times out from cache.

If set to true, then blob inventory items will not be cleared from the inventory table.  This improves the reliability of CacheManager such that blobs can be flushed from SatelliteServer when the blobs have expired from ContentServer.  The cost is increased use of space in the database.  If set to false, then  when a blob expires from the cache, the corresponding inventory entries will also be removed from the database.  If the cache is being actively managed, the blobs should not ever expire from the cache.

The default value is false.

### References

[kksays](https://kksays.wordpress.com/2012/11/27/page-caching-properties-in-fatwire-oracle-webcenter-sites/)