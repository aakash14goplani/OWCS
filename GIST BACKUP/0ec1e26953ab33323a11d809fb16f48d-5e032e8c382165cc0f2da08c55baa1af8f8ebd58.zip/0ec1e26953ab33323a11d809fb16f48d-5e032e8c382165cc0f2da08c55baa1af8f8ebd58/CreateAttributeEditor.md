### General steps to follow

1. Create an xml file to define your attribute editor. Syntax of file should be:
   ```xml
   <?XML VERSION="1.0"?>
   <!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 
   <PRESENTATIONOBJECT NAME="fileName">
      ...
      ...
      ...
   </PRESENTATIONOBJECT>
   ```   
   
2. Under **Admin** tab, click on **New -> Attribute Editor** (Attribute Editor must be enabled in start menu first)   

3. Enter the **Name** of the file (Name of the file should match with the name you have assigned to the file created in step 1.)   

4. **Browse** your XML file(created in step 1.) or you can write your code in **XML** text area   

5. Select the **Attribute Type**   

6. Click on **Save**   

7. Now you can select your Attribute Editor from the dropdown option while creating attributes for flex families.   

### Sample code for Attribute Editors

1. TEXTAREA
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 

<PRESENTATIONOBJECT NAME="TextAreaTest">
  <TEXTAREA XSIZE="40" YSIZE="5" WRAPSTYLE="OFF" DEPTYPE="EXISTS">
  </TEXTAREA>
</PRESENTATIONOBJECT>
```


2. CKEDITOR
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd">

<PRESENTATIONOBJECT NAME="personalizeCKEditor">
  <CKEDITOR WIDTH="400px" HEIGHT="200px">
  </CKEDITOR>
</PRESENTATIONOBJECT>
```


3. PULLDOWN
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 

<PRESENTATIONOBJECT NAME="personalizePulldown">
<PULLDOWN>
  <ITEM>SELECT COLOR</ITEM>
  <ITEM>Red</ITEM>
  <ITEM>Green</ITEM>
  <ITEM>Blue</ITEM>
</PULLDOWN>
</PRESENTATIONOBJECT>
```


4. RADIOBUTTONS
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 

<PRESENTATIONOBJECT NAME="RadioButtonTest">
  <RADIOBUTTONS LAYOUT="VERTICAL">
    <ITEM>Male</ITEM><!--to retrieve value from db use QUERYASSETNAME-->
    <ITEM>Female</ITEM>
  </RADIOBUTTONS>
</PRESENTATIONOBJECT>
```


5. TEXTFIELD
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 

<PRESENTATIONOBJECT NAME="TextFieldTest">
  <TEXTFIELD XSIZE="60" MAXCHARS="80">
  </TEXTFIELD>
</PRESENTATIONOBJECT>
```


6. CHECKBOXES
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 
<PRESENTATIONOBJECT NAME="PersonalizeCheckBox">
	<CHECKBOXES LAYOUT="VERTICAL"><!--default is HORIZONTAL-->
		<ITEM>OUTDOOR GAMES</ITEM><!--to retrieve value from db use QUERYASSETNAME-->
		<ITEM>INDOOR GAMES</ITEM>
	</CHECKBOXES>
</PRESENTATIONOBJECT>
```


7. PICKASSET
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd">
<PRESENTATIONOBJECT NAME="personalizePickAsset">
  <PICKASSET>
  </PICKASSET>
</PRESENTATIONOBJECT>
```


8. UPLOADER
```xml
<?XML VERSION="1.0"?>
<!DOCTYPE PRESENTATIONOBJECT SYSTEM "presentationobject.dtd"> 

<PRESENTATIONOBJECT NAME="UPLOADERTest">
  <UPLOADER MAXFILESIZE="1024MB" FILETYPES="*.*" MINWIDTH="200px" MAXWIDTH="700px" MINHEIGHT="200px" MAXHEIGHT="700px" MAXVALUES="5">
  </UPLOADER>
</PRESENTATIONOBJECT>
```


### References

[Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/data_attributeeditors.htm#WBCSD2289)