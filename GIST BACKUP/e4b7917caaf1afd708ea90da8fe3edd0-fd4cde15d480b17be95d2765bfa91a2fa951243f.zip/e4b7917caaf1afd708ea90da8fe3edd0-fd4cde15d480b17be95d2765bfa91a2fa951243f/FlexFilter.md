A FLEX FILTER is a utility, that performs operations on the flex assets, for which that filter is assigned. The filter will be called only after the particular asset (for which this filter is assigned)  is saved. Flex filter classes implement the functionality of flex filter assets.

How many types of filters are there in total?

Oracle WebCenter Sites / Fatwire Content Server ships with FOUR Flex Filters by default. We also have the provision to create our custom filters. This can be done by creating new jar files, and registering them in the database. Following are the different types of Flex Filters available.

1. **Doc-Type Filter** – Used to get the MIME Type / File Types.

2. **Thumbnail Creator** – Used to convert an image into a thumbnail.

3. **Field Copier** – Used to copy the contents of a system-defined attributes like name, template, etc (Totally 18 system attributes are there) into a user-defined attribute, to be used within the code.

4. **Document Transformation** – Converts a document from one file type into another.

### References

 * [kksays](https://kksays.wordpress.com/2012/10/22/flex-filters-in-oracle-webcenter-sites-fatwire/)   
 * [function1](https://www.function1.com/2015/04/creating-a-custom-flex-filter-in-webcenter-sites)