Aim is to create assets that have some fields pre-filled with particular values. This can be done while creating/configuring Start Menu items

1. Go to Admin tab
2. List all Start Menu (I am updating already created menu, you can create a new one)
3. Set **Type:** to **New**
4. Set **Asset Type** and **Flex Definition** targeting particular asset
5. **Default Values:** This is the field that will help us to achieve our target. Expand the dropdown, there you will have list of fields that can have pre-filled value when asset will be created.

![configure asset](https://github.com/aakash14goplani/OWCS/blob/master/images/start_up_new_1.png)

6. Select a particular field and then value against that field
7. Click on Save

![final asset](https://github.com/aakash14goplani/OWCS/blob/master/images/start_up_new_2.png)