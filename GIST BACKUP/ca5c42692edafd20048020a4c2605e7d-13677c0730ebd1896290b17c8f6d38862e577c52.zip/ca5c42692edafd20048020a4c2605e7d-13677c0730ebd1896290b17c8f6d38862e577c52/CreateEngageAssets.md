# Visitor Attributes

1. In **Contributor UI**, click **New -> New Visitor Attribute**. (visitor attribute must be enabled for the site)
2. Enter the **Name** of Visitor attribute. (for e.g. age)
3. Enter **Descrition** of the asset. (for e.g. Enter Age)
4. Enter **Category** which will be useful when we categorize visitor data according to segments.
5. Click on **Detail** tab
6. Enter **Type** (for e.g. string)
7. Select **Null allowed** value from the dropdown
8. Add **Constraint type** if required
9. Click on **Save**


# Segments

1. In **Contributor UI**, click **New -> New Segment**. (Segment asset must be enabled for the site)
2. Enter the **Name** of Segment. (for e.g. male segment)
3. Enter **Descrition** of the asset. (for e.g. Male Segment)
4. Click on **Detail** tab
5. Click on the `eye` icon, list of categories will appear. Select the required visitor attribute from category (step 4. of visitor attribute)
6. You can select any operations that you want to apply on your segments
7. Click on **Save**


# Recommendation

1. In **Contributor UI**, click **New -> New Recommendation**. (Recommendation asset must be enabled for the site)
2. Enter the **Name** of Recommendation. (for e.g. Personalize_Recommendation)
3. Enter **Descrition** of the asset. (for e.g. Personalize Recommendation) 
4. In **Mode** select `Recommendation`
5. Click on **Detail** tab
6. In **Segment Dropzone** drag & drop the required segments which would be applicable if the recommendation is triggered
7. Within Segments in **Asset Dropzone** drag & drop the required assets which would be shown to end user if they fall in the respective segments
8. We also have option for **If No Segments Apply**, if in case user does not falls under any segment criteria, the default assets that would be dropped in _If No Segments Apply_ will be shown to end user
9. Click on **Save**


### References

* [Visitor attributes](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_visitorassets.htm#WBCSD2344)
* [Recommendation](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_recommendations.htm#WBCSD2339)
