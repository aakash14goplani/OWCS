#### What is RENDERING?

Content Server page is a set components that have been assembled into a viewable, final output. Creating that output is called RENDERING.

#### What is PUBLISHING?

Making either that output or the content that is to be rendered available to the visitors of your online site is called PUBLISHING.

Once we are done with the development of the Site with all the required assets such as Templates, articles, pages, Flex/Basic assets, we need to PUBLISH them to the production system, i.e., When the content on the management system is ready, you publish it to the delivery (Production) system. After intensive testing – both performance and load, you open your site to the public.

Following are the various Publishing Methods available in Fatwire:

1. **Export to Disk (Static Publishing)** – Export web files to disk (File system).

2. **Mirror to Server (Dynamic Publishing)** – Copy database rows to remote dynamic server.

3. **Export to XML** – Export an XML file for each asset.

4. **Real Time** – Copy assets to remote dynamic server.

### References

[kksays](https://kksays.wordpress.com/2011/12/12/publishing-in-fatwire/)