We will now see the implementation of **FieldCopier Flex Filter** in Oracle WebCenter Sites / Fatwire.

**Purpose:** The purpose of this filter is to get information from the system attributes such as NAME, FLEX DEFINITION, CREATED DATE, etc. There are totally 18 system attributes, out of which, a few are inaccessible through code. Under such circumstances, we will use this FieldCopier filter to gather the values from the system attributes, and place the values in our custom attributes.

We will try to copy the name and content definition attributes (system attributes) to our custom attributes in the following implementation.

### CREATE FLEX ATTRIBUTES:

Create the below two flex attributes.

1. **Name-FieldCopier** – (String)
2. **ContentDefinition-FieldCopier** – (String)

### CREATE FLEX FILTER:

Now, create the flex filter for field copier:

1. Click on new Flex Filter.

2. Give a name.

3. In the FILTER drop down, select the FIELDCOPIER option. Then Click on the GET ARGUMENTS button.

4. In the ARGUMENTS section, you will see a drop down box. In that dropdown, select the following options.
   * **name** – In the value text box, enter  Name-FieldCopier – Click on ADD button.
   * **FlexDefinition** – In the value text box, enter  ContentDefinition-FieldCopier – Click on ADD button

5. Save.

### ADDING THE FLEX FILTER TO THE CONTENT DEFINITION:

1. Add the filter to either new content definitions or existing content definitions.

FINALLY, TEST THE FILTER:

Now, its time to test the filter which we have created. Create a new asset of type `SAMPLE_C`, and select the above content definition.

Give a name to the asset. Click on Save. Then, click on Inspect button.

The two attributes which we have created, Name-FieldCopier, ContentDefinition-FieldCopier are appended to the assets meta-data.

### References

[kksays](https://kksays.wordpress.com/2012/10/31/field-copier-flex-filter-in-oracle-webcenter-sites-fatwire/)