Though BASIC ASSETS are not meant to be changed after creation, sometimes, we may require to UPDATE the existing BASIC ASSETS that we have created earlier in FATWIRE CONTENT SERVER. This may be due to the requirement for changing the naming conventions, update existing attributes of the asset type, remove existing attributes, add new attributes to the asset type, etc.

This updating of the basic asset should be done with care, so that, the existing assets will not be affected. If you need to update the basic assets, you need to follow the below guidelines:

1. Open the **CONTENT SERVER EXPLORER**, and open the **ASSETTYPE** table. This table contains the **ASSETTYPEs** that are created in the Fatwire Content Server (Both System and User defined).
2. Open the appropriate **ASSET DESCRIPTOR FILE (ADF)**, by double-clicking on the file in the **URLDESCRIPTOR** field of the table.
3. Update the **ADF**. Save it. Save the Content Server Explorer’s Table. You can do a **SAVE ALL**.
4. Run any scripts, that need to update the database (if required). In most of the cases, there is no need (Atleast, in my case).
5. Register the Assets from the Fatwire’s Advanced Interface (ADMIN -> ASSET TYPES -> APPROPRIATE ASSET ).

### References

[kksays](https://kksays.wordpress.com/2012/02/09/update-a-basic-asset-in-fatwire/)