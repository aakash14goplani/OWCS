## Selecting a Different Layout for the Entire Web Page

Editorial users can assign a layout template to assets by either:   
* directly modifying the value of the template field in Form Mode of the Contributor interface.   
* selecting the Change Layout functionality from either the toolbar or menu bar.   

Selecting a layout template for an asset will make this template the default choice when working with an asset in Web Mode of the Contributor interface, or when previewing the asset.   

In order to enable content contributors to control the page layout used to render a given asset on a live site, the value of the template field should be looked up and used to calculate asset hyperlinks, as in the following example:   

```jsp
<asset:list
  type='<%=ics.GetVar("c")%>'
  list="asset"
  field1="id"
  value1='<%=ics.GetVar("cid")%>' />

<ics:listget
  listname="asset"
  fieldname="template"
  output="template" />

<render:gettemplateurl
  outstr="pageURL"
  tname='<%=ics.GetVar("template")%>'
  args="c,cid" />
```   

## Selecting a Different Layout for a Page Fragment   

```html
<div id="container">
  <div class="content">
    <render:calltemplate tname="HelloDetail" args="c,cid" />
  </div> 
  <div class="side-bar">
    <render:calltemplate tname="HelloArticle" args="c,cid" />
  </div>
</div>
```   

Here the page fragment within `div class="content"` is rendered by _HelloDetail_ template and the page fragment within `div class="side-bar"` is rendered by _HelloArticle_ template   

**Note:**
The syntax used in the code sample:

```jsp
<render:calltemplate tname="HelloDetail" args="c,cid" />
```
is a shortcut for (and is strictly equivalent to):

```jsp
<render:calltemplate 
  tname="HelloDetail" 
  c='<%=ics.GetVar("c")%>' 
  cid='<%=ics.GetVar("cid")%>' />
```   

### References   

[Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_siteassets.htm#WBCSD1946)