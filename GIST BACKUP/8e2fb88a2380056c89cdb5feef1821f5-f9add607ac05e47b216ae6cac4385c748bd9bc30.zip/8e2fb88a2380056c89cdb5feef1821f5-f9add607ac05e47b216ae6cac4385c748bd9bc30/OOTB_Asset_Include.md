The Aim is to design an element to be used with custom file link i.e. Out of the Box Asset Include Button for CKEditor

1. Create Template
2. **For Asset Type**: Required asset type for which custom link/button is required. For sake of example I will go with Image File Asset.
3. **Applies to subtypes:** Any (preferably)
4. **Legal Arguments:** This is very important point. you need to provide arguments which you want while uploading an image (per my example). Here I want to enter alt text and image alignment value when Image is to be embedded in CKEditor.
   + Enter the Argument name. e.g. "Alignment" and then enter corresponding values.
   = **Element Usgae:** Set this to "Usage Unspecified"
   
![OOTB 11](https://github.com/aakash14goplani/OWCS/blob/master/images/OOTB_button_1.png)   
![OOTB 12](https://github.com/aakash14goplani/OWCS/blob/master/images/OOTB_button_2.png)   
![OOTB 13](https://github.com/aakash14goplani/OWCS/blob/master/images/OOTB_button_3.png)   

5. You should now see "Asset Include" button enabled in CKEditor   
![OOTB 14](https://github.com/aakash14goplani/OWCS/blob/master/images/OOTB_button_4.png)   

6. Drag & Drop Image asset, Template options will pop-up, select your target template and then you should see the options that we configured. 
![OOTB 15](https://github.com/aakash14goplani/OWCS/blob/master/images/OOTB_button_5.png)   