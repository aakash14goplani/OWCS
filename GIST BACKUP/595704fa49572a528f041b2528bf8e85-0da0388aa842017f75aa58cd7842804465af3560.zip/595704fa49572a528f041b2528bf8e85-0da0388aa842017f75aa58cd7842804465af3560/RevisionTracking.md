Being the content management professionals we already know about the revision tracking process, as it is one of the fundamentals of CMS. The actions that include are CHECK-IN, CHECK-OUT, CANCEL CHECKOUT, VERSIONING.

Oracle WebCenter Sites / Fatwire doesn’t enable this Revision Tracking feature by default. We will now see how to enable the mechanism in OWS / Fatwire.

### ENABLE REVISION TRACKING:

1. Log in to your site’s **Admin Interface**.

2. Click on the **Admin** Tab.

3. Expand **ASSET TYPES**, and go down to the asset for which you would like to enable the revision tracking feature. (ex: `Sample_C`, `Sample_A` etc)

4. Expand the asset, and there you would find a link **REVISION TRACKING**.

5. Expand the **REVISION TRACKING** link as well. There you would find an option: **Track**

6. Double click on Track.

7. In the workspace, it will display the number of revisions to be stored. Enter the number of revisions to be stored, and click on the button. A message saying **Revision Tracking succeeded for —your asset—** will be displayed.

8. That’s it. Revision Tracking is enabled for your asset.

When you inspect your asset, you can see the CHECK-IN, CHECK-OUT, SEE VERSIONS action items along with other default action items, as follows:

### DISABLE REVISION TRACKING:

If you want to disable revision tracking (In case if you have enabled revision tracking through above steps), proceed till Step-4

5. Then, expand the **REVISION TRACKING** link as well. There you would find two options.
* **Set Revisions**
* **Untrack**

6. Double click on **UNTRACK**.

7. In the workspace, it will display a confirmation message. Click on the button. A message saying **Untrack succeeded for —your asset—** will be displayed.

8. That’s it. Revision Tracking is disabled.

### References

[kksays](https://kksays.wordpress.com/2012/11/01/revision-tracking-in-oracle-webcenter-sites-fatwire/)