### What happens if we don’t enable caching for a website / page:

1. When ever a visitor of a site hits on the url, say `http://www.example.com`, the call will go to the web server, and from the web server to the content server, and then from content server to the database. And the response will travel in the reverse direction. Finally the output is rendered. All this process will take a long time (as compared to that of cached site).
2. The overall site loading time will be high.
3. Page loading time is obviously high.
4. As the number of calls to content server and the database are high, the performance of the overall system will be affected.
5. Finally, the business will be affected.

### What happens if we enable caching for  a website / page:

1. When the user hits the url, the page will be directly served from the cache, instead of making several calls to the content server and database.
2. The performance of entire website is good, as the page load time is short.
3. The overall target of the business can be easily achieved.

### What happens if we don’t follow proper caching techniques:

1. The updated content (whenever updated by the content authors) will not reflect the production site properly.
2. Outdated content will be served by the server.
3. As a result, the visitor of the site receives false and outdated information.

This is the importance of caching. So, proper Caching techniques should be followed in order to achieve the target of creating a good site.

### References

[kksays](https://kksays.wordpress.com/2012/12/05/prominence-of-caching-in-fatwire-oracle-webcenter-sites/)