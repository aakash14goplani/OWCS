While building a website (Either by a WCM or normal html, etc), there will be certain images or other assets which seldom change, like Company Logo, etc. Say for example, CompanyLogo.png.

As we know, the images (even pdfs, etc) are nothing but blobs in Fatwire / Oracle WebCenter Sites.

The performance of the over all site can be improved by changing the way of serving these NEVER-EXPIRING BLOBS. The never expiring images / blobs which we discussed above in the first paragraph, need not be called from Satellite Server Cache / Content Server Cache. If we use an alternative method, the performance can be improved, as the number of calls have been reduced.

Follow the below mechanism for serving the NEVER-EXPIRING BLOBS in Fatwire / Oracle WebCenter Sites.

1. Copy those Never-Expiring Blobs to your Satellite Server hosts. Place them under the doc root for your web server.

2. In the code, instead of the satellite:blob tags, use <img src=”…”> tag to access the blob placed on your Satellite Server.

**NOTE:** While using this mechanism for serving never-expiring blobs, make sure that you place those blobs (ex: images) in all the Satellite Server host locations. If the blob is not present in any of the location, the Satellite Server cannot warn you that one of the Satellite Server hosts does not contain the same blob, that is contained in other hosts.

### References

[kksays](https://kksays.wordpress.com/2012/11/27/never-expiring-blobs-in-fatwire-oracle-webcenter-sites/)