All the Fatwire / Oracle WebCenter Sites developers are familiar with coding the templates through either Admin interface, or using a text editor such as notepad, etc.  But, Oracle WebCenter Sites provides us with a plugin called DEVELOPER TOOLS (In Fatwire, it was called as CONTENT SERVER DEVELOPER TOOLS plugin), which enables us to work with an Integrated Development Environment like Eclipse. What all we need to do is to use this plugin, and make our work easy by working with Eclipse IDE.

The Developer Tools kit enables developers to work in a distributed environment using tools such as the Eclipse IDE and version control system integration. The developer interacts with Developer Tools (and WebCenter Sites), primarily through Eclipse, which upon integration provides a  set of WebCenter Sites-specific tools for managing assets and other resources.

The Developer Tools kit enables synchronization of resource development in Eclipse with resource development in WebCenter Sites, and resources of WebCenter with resources of Eclipse.

 ![Eclipse Plug-in](https://github.com/aakash14goplani/OWCS/blob/master/images/eclipse_1.png)
 
### USES OF ECLIPSE IDE Integration

There are pretty good usages of integrating the plugin with Eclipse, and coding through Eclipse. Following are the uses through Eclipse integration:

* Create, edit, and delete Templates, CSElements, and SiteEntries.
* Develop JSPs with Eclipse features such as tag completion, syntax highlighting, debugging, etc.
* Export and import assets, asset types, flex families, sites, roles, tree tabs, and start menu items
* View the output, i.e, Previewing of WebCenter Sites pages within the Eclipse IDE using the preview browser
* View the WebCenter Sites log file in the error console. 

### Integrating Developer Tools with Eclipse

We need the following the components for integrating Oracle WebCenter Sites Devloper Tools with Eclipse:
1. Latest Eclipse (Can be downloaded from [here](http://www.eclipse.org/downloads/))
2. CSDT plugin (Developer tools plugin)

By following the below steps, we can integrate the Developer tools provided by Oracle WebCenter Sites with Eclipse.

1. Download and Install WebCenter Sites JDK.
2. Download the latest version of Eclipse, and install it.
3. In the WebCenter Sites distribution package, there is a filde called csdt.zip. Unzip it.package. Open the csdt-eclipse folder and save the com.fatwire.csdt.eclipsecsdt_1.0.0.jar file to the plugins folder under your Eclipse installation
4. Start your local instance of WebCenter Sites (JDK).
5. Start Eclipse (eclipse.exe) and configure its settings according to your preferences.
6. In the Eclipse menu bar, select Window > Open Perspective > Other … > Oracle WebCenter Sites.
7. The configuration screen is displayed. In the configuration screen, fill in the following fields with the information for your WebCenter Sites instance
8. In the “Sites Installation Directory” field, click Browse to select the directory containing the futuretense.ini file for the WebCenter Sites instance.
9. In the “Username” field, enter the user name of a general administrator. This user must be a member of the RestAdmin group.
10. In the “Password” field, enter the password for the user name you entered.
11. In the “Project name” field, enter a name for the project on which you will be working.
12. In the “Sites Log File” field, enter the location of your log file (for example, C:/ WCS/logs/sites.log).
13. The Configuration screen looks as below:
 ![Config Screen](https://github.com/aakash14goplani/OWCS/blob/master/images/eclipse_2.png)
14. Click OK.
 

Configuration is now Complete. Now, the **Oracle WebCenter Sites perspective** opens. The Oracle WebCenter Sites perspective looks as shown in the below image:

 ![Eclipse IDE](https://github.com/aakash14goplani/OWCS/blob/master/images/eclipse_3.png)


### References

[kksays](https://kksays.wordpress.com/2013/10/10/oracle-webcenter-sites-developer-tools/)   
[kksays](https://kksays.wordpress.com/2013/10/10/oracle-webcenter-sites-fatwire-integrating-developer-tools-with-eclipse/)