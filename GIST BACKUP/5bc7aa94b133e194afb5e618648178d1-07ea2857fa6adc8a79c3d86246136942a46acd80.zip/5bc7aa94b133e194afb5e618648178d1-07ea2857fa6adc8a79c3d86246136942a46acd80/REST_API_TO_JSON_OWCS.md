Send the request with Accept header set to `application/json`.

You can test this with FireFox by adding `application/json` near the front of the **`network.http.accept.default`** as follows:

1. Open the URL `about:config`.

2. Click **"I'll be careful, I promise!"**

3. Search for `network.http.accept.default`.

4. Double-click the property and add `application/json` to value as shown: `text/html,application/json,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" (assuming the default is "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"). It needs to be added before application/xml, otherwise XML will be the first choice. This makes the browser send the REST request with Accept header set to "text/html,application/json,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8`.

5. Make a REST request in the browser. E.g. `http://{host}:{port}/{context}/REST/sites/<site_name>/types/<asset_type>/assets/<asset_id>`

AJAX Example

```javascript
$.ajax({
   type: "GET",
   contentType: "application/json",
   processData: false,
   headers: {'Accept': 'application/json','X-CSRF-Token': ticket},
   url: "http://localhost:9080/cs/REST/sites/<site_name>/types/<asset_type>/assets/<asset_id>?multiticket=" + ticket,
   success: function(data) {
      console.log("Asset Created Successfully!" , data);
   },
   error: function(XMLHttpRequest, textStatus, errorThrown) {
      console.log("Status: " + textStatus + ", Error: " + errorThrown);
   }
});
```

SAMPLE RESPONSE

```json
{
  "schemaLocation": "http://www.fatwire.com/schema/rest/1.0 http://localhost:9080/cs/schema/rest-api.xsd",
  "id": "Widget_C:1493110139418",
  "name": "Attribute Editors_2",
  "createdby": "AakashG",
  "createddate": "2017-04-25T15:36:14.384Z",
  "description": "",
  "publist": [
    "ABC",
    "PQR"
  ],
  "status": "ED",
  "subtype": "AttributeEditors",
  "updatedby": "AakashG",
  "updateddate": "2017-04-25T15:36:34.756Z",
  "attribute": [
    {
      "name": "template",
      "data": {
        "stringValue": "DEMO_Template"
      }
    },
    {
      "name": "id",
      "data": {
        "longValue": 1493110139418
      }
    },
    {
      "name": "radioButton",
      "data": {
        "stringValue": "MALE"
      }
    },
    {
      "name": "checkbox",
      "data": {
        "stringList": [
          "OUTDOOR GAMES",
          "INDOOR GAMES"
        ]
      }
    },
    {
      "name": "dropdown",
      "data": {
        "stringValue": "Red"
      }
    },
    {
      "name": "ckeditor",
      "data": {
        "stringValue": "<h1>\r\n\tHello</h1>\r\n<div>\r\n\t<img src=\"https://www.google.com/logos/doodles/2017/37th-anniversary-of-komodo-national-park-6197054943526912.3-res.png\" /></div>\r\n"
      }
    },
    {
      "name": "pickAsset",
      "data": {
        "stringList": [
          "Media_C:1374098704202"
        ]
      }
    }
  ],
  "associations": {
    "href": "http://localhost:9080/cs/REST/sites/ABC/types/Widget_C/assets/1493110139418/associations"
  }
}
```