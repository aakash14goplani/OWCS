Oracle Webcenter Sites provides a provision to call CSElements or Templates from another CSElement or Template by using the `render:callelement` tag. The regular behavior of calling element is to aggregate the content in caller element with the content from called element after the execution. The called element wont return the server code, instead returns the HTML code finally to the called element.

But in some situations where we need to do something depends on the result after executing the called element. To achieve the goal we need to understand the scope of the variables in caller & called elements. By default the variables in caller elements are not available in called elements. And vice versa.

Some variables can be passed to the called element by the `render:argument` tag.
```jsp
<render:callelement elementname="called_element" args="c,cid">
    <render:argument name="variable_name1" value="variable_value1"/>
    <render:argument name="variable_name2" value="variable_value2"/>
</render:callelement>
```
only the `variable_name1` & `variable_name2` are available in called element.

### SCOPE OF THE VARIABLES FROM CALLED ELEMENT IN CALLER ELEMENT
In order to access the variables in called element from caller element, we need to set the scope while calling elements.

The scope attribute of the `render:callelement` tag controls the manner in which variables in the calling element are available to the called element, and vice versa. Legal values are local, stacked, global. The default value is local.

With the stacked scope element, some variables will be copied to the caller after execution of the called element. No variables of the caller will be visible to the called element. Argument tags will create new variables in the called element, and the final values of these variables after execution of the called element will be copied to the caller, overwriting any pre-existing values that may have existed.

In the below snippet the PageBody template (caller element) is calling getPageData (called element) by passing three variables. The `getPageData` element executes some code and set some value in returnVariable variable.

As the returnVariable variable is available in the PageBody template, If the returnVariable has some data then the template will display the data otherwise it shows some error message like…Oops no content found. Please try again.

Example
```jsp
<render:callelement elementname="getPageData" args="c,cid" scope="stacked">
    <render:argument name="variable_name1" value="variable_value1"/>
    <render:argument name="variable_name2" value="variable_value2"/>
    <render:argument name="returnVariable" value=""/>
</render:callelement>

if returnVariable has Data?
   display data...
else 
   display an error message...
```