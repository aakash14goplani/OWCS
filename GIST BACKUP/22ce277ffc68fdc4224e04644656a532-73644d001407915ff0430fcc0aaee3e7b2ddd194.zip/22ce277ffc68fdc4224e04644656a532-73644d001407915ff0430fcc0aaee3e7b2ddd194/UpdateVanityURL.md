```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ page import="com.fatwire.system.*, java.util.*, com.fatwire.assetapi.data.*, COM.FutureTense.Interfaces.*, com.openmarket.xcelerate.asset.AssetIdImpl"
%><%
 /******************************************************************************************************************************
   *    Element Name        :  Practice/Automation/UpdateVanityURL 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (21/06/2018) 
   *    Description         :  Element that updates vanity URL for given asset 
   *    Input Parameters    :  c, cid, template, Webreference value in string format
   *    Output              :  Creates Vanity URL
 *****************************************************************************************************************************/
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if><% 
	
	try { 
		String assetIdInstance = ics.GetVar("assetIdInstance");
		String templateName = ics.GetVar("templateName");
		String webReferenceString = ics.GetVar("webReferenceString");           
		String webRoot = "", assetURL = "";
		
		if( Utilities.goodString(assetIdInstance) && Utilities.goodString(templateName)) {
			String assetType = assetIdInstance.split(":")[0];
			Long assetId = Long.parseLong(assetIdInstance.split(":")[1]);
			
			Session ses = SessionFactory.getSession();
			AssetDataManager mgr = (AssetDataManager) ses.getManager( AssetDataManager.class.getName() );
			AssetId id = new AssetIdImpl( assetType, assetId );
			
			Iterable<AssetData> assetdataItr = mgr.read(Arrays.asList(id));
			List<AssetData> updateAssets = new ArrayList<AssetData>();
			
			List<WebReference> webReferenceList = new ArrayList<WebReference>();
			webReferenceList.clear();
			
			if( webReferenceString.contains("AssetURL=") && webReferenceString.contains("WebRoot=") ) {
				webReferenceString = webReferenceString.substring(1, webReferenceString.length() - 1);
				for(String component : webReferenceString.split("____")) {
					assetURL = component.substring((component.indexOf("AssetURL=") + "AssetURL=".length()), component.indexOf("WebRoot=")).trim();
					webRoot = component.substring(component.indexOf("WebRoot=") + "WebRoot=".length()).trim();
					%><ics:logmsg msg='<%="Adding to webreference list: " + webRoot + " : " + assetURL + " : " + new java.lang.Integer(200) + " : " + templateName %>' severity="INFO"/><%
					webReferenceList.add(new WebReferenceImpl(webRoot, assetURL, new java.lang.Integer(200), templateName));
				}
			
				for(AssetData a : assetdataItr) {
		            updateAssets.add(a);
		            if(webReferenceList != null && webReferenceList.size() > 0) {
		            	a.getAttributeData("Webreference").setData(webReferenceList);
		            }
		        }
		        
		        ics.ClearErrno();
		        mgr.update(updateAssets);
			} else {
				out.println("<div class=\"error\">Empty Webreference string passed in UpdateVanituURL element: " + webReferenceString + "</div><br/>");
			}
			
	        if(ics.GetErrno() == 0) {
	        	out.println("Vanity URL created successfully" + "<br>");
	        }
	        else {
	        	out.println("Error creating Vanity URL: " + ics.GetErrno() + "<br>");
	        }
		} else {
			out.println("<div class=\"error\">AssetIdInstance: " + assetIdInstance + " or Template: " + templateName + " not passed to UpdateVanityURL element</div><br/>");
		}
	} catch (Exception e) {
		out.println("<div class=\"error\">Exception Occured in UpdateVanituURL element: " + e.getMessage() + "</div><br/>");
	}
%></cs:ftcs>
```