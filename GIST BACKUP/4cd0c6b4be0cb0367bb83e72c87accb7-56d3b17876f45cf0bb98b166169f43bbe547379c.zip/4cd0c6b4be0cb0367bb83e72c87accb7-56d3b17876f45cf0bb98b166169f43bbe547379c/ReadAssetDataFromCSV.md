```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ taglib prefix="user" uri="futuretense_cs/user.tld"
%><%@ page import="com.openmarket.xcelerate.asset.AssetIdImpl, java.text.SimpleDateFormat, COM.FutureTense.Interfaces.*, java.io.*, com.fatwire.system.*, com.fatwire.assetapi.data.*, java.util.*"
%><%
 /******************************************************************************************************************************
   *    Element Name        :  Practice/Automation/ReadAssetDataFromCSV 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (20/06/2018) 
   *    Description         :  Element that reads asset data from CSV file and creates assets in target environment 
   *    Input Parameters    :  CSV file
   *    Output              :  Assets in Target environment
 *****************************************************************************************************************************/
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if>
	<html>
		<head>
			<title>Read CSV File</title>
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
			<style type="text/css">
				.error {
					color: red;
					font-weight: bold;
				}
			</style>
		</head>
		<body>
			<div class="container-fluid">
				<div class="row">
					<div class="col-xs-12 col-md-12">
						<form enctype="multipart/form-data">
							<fieldset>
								<legend>Upload CSV File</legend>
								<div class="form-group">
									<label for="FileName">File:</label>
									<input type="file" name="file" id="file" required/>
								</div>
							    <input type="hidden" name="readData" value="true" />
							    <input type="hidden" name="pagename" value="Practice/Automation/ReadAssetDataFromCSV" />
							    <button type="submit" class="btn btn-light">Submit</button>
							</fieldset>
						</form>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12 col-md-12">
						<h1 align="center">Progress Log</h1>
					</div><hr/>
					<div class="col-xs-12 col-md-12"><%
		
						if( Utilities.goodString(ics.GetVar("readData")) ) {
							String csvFile = "C:\\Users\\ADMIN\\Downloads\\" + ics.GetVar("file");
					        String csvReadLine = "";
					        String cvsDelimiter = ",";
					        BufferedReader br = new BufferedReader(new FileReader(csvFile));
					        
					        Session sessionFactory = SessionFactory.getSession();
							AssetDataManager assetDataManager = (AssetDataManager)sessionFactory.getManager(AssetDataManager.class.getName());			
							MutableAssetData mutableAssetData = null; 
					        int lineNumber=1;	
					        String assetType = "", nestedAssetAttributeName = "", returnValue = "", assetId = "", flexDefinition = "", attributeName = "", attributeValue = "", template="", assetName = "", webReferenceString = "", webReferenceTemplate = "";
					        boolean continueProcessing = false, processingNestedAssetData = false, isAssetMultiple = false;
					        
					        Map<String, String> nestedAssetData = new HashMap<String, String>();
							nestedAssetData.clear();
											
					        double readCSVContentsTimeStart = System.nanoTime();
					        
						    try {
						        while ((csvReadLine = br.readLine()) != null) {
									String[] csvContent = csvReadLine.split(cvsDelimiter);
									ics.ClearErrno();
								    
								    for(int columnNumber=0; columnNumber < csvContent.length; columnNumber++) {
								    	
								    	if("_NEW_ASSET_CONTENT_".equals(csvContent[columnNumber])) {
								    		/* write asset data for all the parse except last one */
								    		if(null != mutableAssetData) {
								    			%><ics:logmsg msg='<%="Inserting last asset data at line: " + lineNumber %>' severity="INFO"/><%
								    			//assetDataManager.insert(Arrays.<AssetData>asList(mutableAssetData));
								    			if(ics.GetErrno() == 0) {
													//out.println("<hr>90 Asset replicated successfully. <br/> Asset Id in 9080: " + assetId + "<br/> Asset Id in 9081: " + mutableAssetData.getAssetId() + "<hr><br/>");
												} else {
													out.println("<div class=\"error\">Error Occured: " + ics.GetErrno() + "</div>");
												}
								    		} else {
								    			mutableAssetData = null; 
								    		}
								    		lineNumber = 1;
								    		assetType = ""; assetId = ""; flexDefinition = ""; attributeName = ""; assetName = "";
								    		attributeValue = ""; template=""; webReferenceString = ""; webReferenceTemplate = "";
								    		returnValue = ""; nestedAssetAttributeName = "";
								    		nestedAssetData.clear();
								    	}
								    	
								    	if(lineNumber == 2) {
								    		if(columnNumber == 0) {
									    		/* read assetType and assetId at line 2, column 0. Need assetType for creating instance 
									    			of MutableassetData, and assetId for displaying logs ie ID in 9080: and ID in 9180 */
									    		assetType = csvContent[columnNumber].split(":")[0];
									    		assetId = csvContent[columnNumber].split(":")[1];
									    		%><ics:logmsg msg='<%=assetType + ":" + assetId + "[" + columnNumber + "]" + " ~ " %>' severity="INFO"/><%
									    	} else {
									    		// read flex definition at line 2, column 1 
									    		if(Utilities.goodString(csvContent[columnNumber])) {
									    			flexDefinition = csvContent[columnNumber];
									    		}
									    		%><ics:logmsg msg='<%=flexDefinition + "[" + columnNumber + "]" + " " %>' severity="INFO"/><%
									    	}
								    	} else {
								    		if(columnNumber == 0) {
								    			// read line i column 0 i.e. asset_attribute_name
								    			attributeName = csvContent[columnNumber]; 
								    			%><ics:logmsg msg='<%=attributeName + "[" + columnNumber + "]" + " ~ " %>' severity="INFO"/><%
								    		} else {
								    			// read line i column 1  i.e. asset_attribute_value
								    			attributeValue = csvContent[columnNumber];
								    			if(attributeName.contains("template") && "".equals(template)) {
								    				template = attributeValue;
								    			}
								    			if(attributeName.contains("name") && "".equals(assetName)) {
								    				assetName = attributeValue;
								    				
								    				/* check if asset exists then return current id instance else create new one */
													%><ics:callelement element="Practice/Automation/CheckIfAssetExists">
														<ics:argument name="assetName" value="<%=assetName %>"/>
														<ics:argument name="c" value="<%=assetType %>" />
													</ics:callelement><%
													
													String targetAssetIdInstance = "null";//ics.GetVar("assetExists");
													if(Utilities.goodString(targetAssetIdInstance) && !"null".equals(targetAssetIdInstance)) {
														/* asset exists, reuse it */
														returnValue = assetType + ":" + targetAssetIdInstance;
														out.println("<div class=\"error\">Asset already exists: " + returnValue +". Please avoid creating duplicate assets</div><br>");
														break;
													
													} else if(Utilities.goodString(targetAssetIdInstance) && "null".equals(targetAssetIdInstance)) {
														/* asset does not exists, create new one */
														continueProcessing = true;
													}
								    			}
								    			%><ics:logmsg msg='<%=attributeValue + "[" + columnNumber + "]" + " " %>' severity="INFO"/><%
								    		}
								    	}
								    	
								    } // for-loop ends
								    %><ics:logmsg msg='<%="at line: " + lineNumber %>' severity="INFO"/><%
								   	
								   	/* if asset exists exit while loop */
								   	if(!continueProcessing && Utilities.goodString(returnValue)) {
								   		%><ics:logmsg msg='<%="Breaking while loop on params: !(" + continueProcessing + "), " + returnValue + ", " + assetName %>' severity="INFO"/><%
								   		break;
								   	}
								   	
									if(lineNumber == 2) {
								    	%><ics:logmsg msg='<%="Instantiating instance of Mutable Asset Data at line:" + lineNumber %>' severity="INFO"/><%
								    	/* Flex asset = flex_definiton_defined, Basic Asset = "" */
								    	if( Utilities.goodString(assetType) && ( Utilities.goodString(flexDefinition) || "".equals(flexDefinition) ) ) {
								    		//mutableAssetData = assetDataManager.newAssetData(assetType, flexDefinition);
								    	}
								    } else if(lineNumber > 2) {
								    	
								    	if(Utilities.goodString(attributeName)) {
								    	
								    		if("_NESTED_ASSET_CONTENT_START_".equals(attributeName)) {
								    			if(nestedAssetAttributeName.contains(":_IS_MULTIPLE_")) {
								    				nestedAssetAttributeName = attributeValue.split(":")[0];
								    				isAssetMultiple = true;
								    			} else {
								    				nestedAssetAttributeName = attributeValue;
								    				isAssetMultiple = false;
								    			}
								    			processingNestedAssetData = true;
								    			%><ics:logmsg msg='<%="Start Logic for Assets: " + attributeName + " at line: " + lineNumber %>' severity="INFO"/><%
								    		}
								    		if("_NESTED_ASSET_CONTENT_END_".equals(attributeName)) {
								    			processingNestedAssetData = false;
								    			nestedAssetAttributeName = "";
								    			%><ics:logmsg msg='<%="Stop Logic for Assets at line: " + lineNumber %>' severity="INFO"/><%
								    		}
								    		
								    		if(processingNestedAssetData) {
								    			/* collect values in the map and pass it to ReadNestedAssetData */
								    			%><ics:logmsg msg='<%="Process Nested Asset Data Logic " + processingNestedAssetData + " at line: " + lineNumber %>' severity="INFO"/><%
								    			if(!"_NESTED_ASSET_CONTENT_START_".equals(attributeName)) {
								    				out.println("nested: " + attributeName + "at line: " + lineNumber + "<br>");
								    				nestedAssetData.put(attributeName, attributeValue);
								    			}
								    			
								    		} else {
								    			/* stop processing remaining logic till _NESTED_ASSET_CONTENT_END_ flag is encountered */
								    			%><ics:logmsg msg='<%="Process Nested Asset Data Logic " + processingNestedAssetData + " at line: " + lineNumber %>' severity="INFO"/><%
								    			if(nestedAssetData.size() > 0) {
								    				// call ReadNestedAssetData element
								    				ics.setAttribute("assetMap", nestedAssetData);
								    				%><ics:callelement element="Practice/Automation/ReadNestedAssetData" /><%
								    				nestedAssetData.clear();
								    				ics.removeAttribute("assetMap");
								    			}
								    			//out.println("rest: " + attributeName + "<br>");
								    			
									    		if( attributeName.contains(":_IS_ASSET_") ) {
									    			if( attributeName.contains(":_IS_MULTIPLE_") ) {
										    			attributeName = attributeName.split(":")[0];
										    			// multiple assets
														%><ics:logmsg msg='<%="Logic for Multiple Assets: " + attributeName + " : " + attributeValue + " at line: " + lineNumber %>' severity="INFO"/><%
										    			
										    			List<AssetId> assetIdList = new ArrayList<AssetId>();
										    			for(String singleAsset : attributeValue.split("____")) {
										    				String singleAssetType = singleAsset.split(":")[0];
										    				String singleAssetId = singleAsset.split(":")[1];
										    				
										    				if( Utilities.goodString(singleAssetId) && Utilities.goodString(singleAssetType) ) {
										    					
										    					%><%-- <ics:logmsg msg='<%="Calling CreateNestedAssets with: " + singleAssetType + " ~ " + singleAssetId %>' severity="INFO"/>
																<ics:callelement element="Practice/Automation/CreateNestedAssets">
													    			<ics:argument name="cid" value='<%=singleAssetId %>'/>
													    			<ics:argument name="c" value='<%=singleAssetType %>' />
													    		</ics:callelement>
													    		<ics:logmsg msg='<%="Value returned from CreateNestedAssets: " + ics.getAttribute("nestedAssetIdInstance") %>' severity="INFO"/> --%><%
													    		
													    		if(null != ics.getAttribute("nestedAssetIdInstance") && !"_ERROR_".equals(ics.getAttribute("nestedAssetIdInstance"))) {
													    			assetIdList.add( new AssetIdImpl(ics.getAttribute("nestedAssetIdInstance").toString().split(":")[0], Long.valueOf(ics.getAttribute("nestedAssetIdInstance").toString().split(":")[1])) );
													    		}
													    		if(assetIdList.size() > 0) {
														    		%><ics:logmsg msg='<%="Writing asset content: " + attributeName + " : " + Arrays.toString((assetIdList.toArray())) + " : " + ics.getAttribute("nestedAssetIdInstance").toString().split(":")[0] + "~" + ics.getAttribute("nestedAssetIdInstance").toString().split(":")[1] + " at line: " + lineNumber %>' severity="INFO"/><%
														    		//mutableAssetData.getAttributeData(attributeName).setData(assetIdList);
													    			%><ics:logmsg msg='<%="Wrote asset content: " + attributeName + " : " + Arrays.toString((assetIdList.toArray())) %>' severity="INFO"/><%
													    		}
										    				}
										    			}
									    			} else {
										    			//single asset
										    			attributeName = attributeName.split(":")[0];
										    			%><ics:logmsg msg='<%="Logic for Single Asset: " + attributeName + " : " + attributeValue + " at line: " + lineNumber %>' severity="INFO"/><%
										    			
											    		%><%-- <ics:callelement element="Practice/Automation/CreateNestedAssets">
											    			<ics:argument name="cid" value='<%=attributeValue.split(":")[1] %>'/>
											    			<ics:argument name="c" value='<%=attributeValue.split(":")[0] %>' />
											    		</ics:callelement>
											    		<ics:logmsg msg='<%="Value returned from CreateNestedAssets: " + ics.getAttribute("nestedAssetIdInstance") %>' severity="INFO"/> --%><%
											    		
											    		if(null != ics.getAttribute("nestedAssetIdInstance") && !"_ERROR_".equals(ics.getAttribute("nestedAssetIdInstance"))) {
											    			AssetId assetIdInstance = new AssetIdImpl(ics.getAttribute("nestedAssetIdInstance").toString().split(":")[0], Long.valueOf(ics.getAttribute("nestedAssetIdInstance").toString().split(":")[1]));
												    		%><ics:logmsg msg='<%="Writing new single asset: " + attributeName + " : " + assetIdInstance + " : " + ics.getAttribute("nestedAssetIdInstance").toString().split(":")[0] + "~" + ics.getAttribute("nestedAssetIdInstance").toString().split(":")[1] + " at line: " + lineNumber %>' severity="INFO"/><%
												    		//mutableAssetData.getAttributeData(attributeName).setData(assetIdInstance);
												    		%><ics:logmsg msg='<%="Wrote new single asset: " + attributeName + " : " + assetIdInstance.getId() + ":" + assetIdInstance.getType() %>' severity="INFO"/><%
											    		}
										    			
										    		}
									    		
									    		} else if( attributeName.contains(":_IS_DATE_") ) {
									    			
									    			if( attributeName.contains(":_IS_MULTIPLE_") ) {
										    			attributeName = attributeName.split(":")[0];
									    				// multiple dates
										    			String multipleDate = attributeValue;
										    			%><ics:logmsg msg='<%="Reading multiple dates: " + attributeValue %>' severity="INFO"/><%
										    			if(multipleDate.contains("____")) {
										    				multipleDate = multipleDate.substring(1, multipleDate.length() - 1);
														}
														%><ics:logmsg msg='<%="Multiple date after manipulation: " + multipleDate %>' severity="INFO"/><%
														if(multipleDate.length() > 2) {
															List<Date> dateList = new ArrayList<Date>();
															dateList.clear();
															for(String singleDate : multipleDate.split("____")) {
																dateList.add(new SimpleDateFormat("EEE MMM dd hh:mm:ss 'UTC' yyyy").parse(singleDate.trim()));
																%><ics:logmsg msg='<%="Adding to Multiple date list: " + Arrays.toString(dateList.toArray()) %>' severity="INFO"/><%
															}
															%><ics:logmsg msg='<%="Writing multiple date: " + attributeName + " = " + Arrays.toString(dateList.toArray()) + " at line: " + lineNumber %>' severity="INFO"/><%
															//mutableAssetData.getAttributeData(attributeName).setData(dateList);
															%><ics:logmsg msg='<%="Wrote multiple date: " + attributeName + " = " + Arrays.toString(dateList.toArray()) + " at line: " + lineNumber %>' severity="INFO"/><%
														}
									    			} else {
									    				// single date
														attributeName = attributeName.split(":")[0];
														%><ics:logmsg msg='<%="Reading single date: " + attributeValue %>' severity="INFO"/><%
														Date singleDate = new SimpleDateFormat("EEE MMM dd hh:mm:ss 'UTC' yyyy").parse(attributeValue);
														%><ics:logmsg msg='<%="Writing single date: " + attributeName + " : " + singleDate + " at line: " + lineNumber %>' severity="INFO"/><%
														//mutableAssetData.getAttributeData(attributeName).setData(singleDate);
														%><ics:logmsg msg='<%="Wrote single date: " + attributeName + " : " + singleDate + " at line: " + lineNumber %>' severity="INFO"/><%	
									    			}
									    		
									    		} else if(attributeName.contains(":_IS_MULTIPLE_") ) {
									    			
													if( attributeName.contains("Webreference") ) {
											    		/* logic for webreference */
											    		%><ics:logmsg msg='<%="Logic for Webreference" %>' severity="INFO"/><%
											    		webReferenceString = attributeValue;
											            webReferenceTemplate = template;
											    	
										    		} else {
														// normal multiple values
										    			attributeName = attributeName.split(":")[0];
										    			if( attributeValue.contains("[") && attributeValue.contains("]") ) {
										    				attributeValue = attributeValue.substring(1, attributeValue.length() - 1);
										    			}
										    			String new_attribute_value[] = attributeValue.split("____");
										    			%><ics:logmsg msg='<%="Writing normal multiple values " + attributeName + " : " +  Arrays.toString(new_attribute_value) + " at line: " + lineNumber %>' severity="INFO"/><%
										    			//mutableAssetData.getAttributeData(attributeName).setData(Arrays.asList(new_attribute_value));
										    			%><ics:logmsg msg='<%="Wrote normal multiple values " + attributeName + " : " + Arrays.toString(new_attribute_value) + " at line: " + lineNumber %>' severity="INFO"/><%
										    		}
									    		
												} else if(attributeName.contains(":_IS_ASSOC_") ) {
													// associations
									    			attributeName = attributeName.split(":")[0];
									    			List<AssetId> associationList = new ArrayList<AssetId>();
													for(String associationAsset : attributeValue.split("____")) {
														associationList.add(new AssetIdImpl(associationAsset.split(":")[0], Long.valueOf(associationAsset.split(":")[1])));
													}
													%><ics:logmsg msg='<%="Writing Associations: " + attributeName + " = " + Arrays.toString(associationList.toArray()) + " at line: " + lineNumber %>' severity="INFO"/><%
													//mutableAssetData.setAssociation(attributeName, associationList);
													%><ics:logmsg msg='<%="Wrote Associations: " + attributeName + " = " + Arrays.toString(associationList.toArray()) + " at line: " + lineNumber %>' severity="INFO"/><%
												
												}else {
									    			//normal single values
									    			if(attributeValue.contains("[") && attributeValue.contains("]")) {
														attributeValue = attributeValue.substring(1, attributeValue.length() - 1);
									    			}
									    			if( attributeValue.indexOf("\"") == 0 && attributeValue.lastIndexOf("\"") == (attributeValue.length() - 1) ) {
									    				attributeValue = attributeValue.substring(1, attributeValue.length() - 1);
									    	            %><ics:logmsg msg='<%="Processed attributeValue after removing quotes: " + attributeValue + " at line: " + lineNumber %>' severity="INFO"/><%
									    	        }
									    			%><ics:logmsg msg='<%="Writing normal single values " + attributeName + " : " + attributeValue + " at line: " + lineNumber %>' severity="INFO"/><%
									    			//mutableAssetData.getAttributeData(attributeName).setData(attributeValue);
									    			%><ics:logmsg msg='<%="Wrote normal single values " + attributeName + " : " + attributeValue + " at line: " + lineNumber %>' severity="INFO"/><%
									    		}
									    	}
								    	} 
								    }
								    lineNumber++;
								} // while-loop ends
								
								ics.ClearErrno();
								/* write asset data for last parse */
								if(continueProcessing) {
									//assetDataManager.insert(Arrays.<AssetData>asList(mutableAssetData));
								}
								double readCSVContentsTimeStop = System.nanoTime();
								double totalTimeToReadCSVContents = (readCSVContentsTimeStop - readCSVContentsTimeStart) / 1000000;
								
								if(ics.GetErrno() == 0 && continueProcessing) {
									//out.println("<hr>Asset replicated successfully <br/> Asset Id in 9080: " + assetId + "<br/> Asset Id in 9081: " + mutableAssetData.getAssetId() + "<hr><br/>");
									double startTimeToUpdateVanityURL = System.nanoTime();
									if( webReferenceString.contains("AssetURL=") && webReferenceString.contains("WebRoot=") ) {
										
										%><ics:callelement element="Practice/Automation/UpdateVanityURL">
											<ics:argument name="webReferenceString" value="<%=webReferenceString %>"/>
											<ics:argument name="assetIdInstance" value="<%=mutableAssetData.getAssetId().toString() %>"/>
											<ics:argument name="templateName" value="<%=webReferenceTemplate %>"/>
										</ics:callelement><%
										
									}
									double stopTimeToUpdateVanityURL = System.nanoTime();
									double totalTimeToUpdateVanityURL = (stopTimeToUpdateVanityURL - startTimeToUpdateVanityURL) / 1000000;
									totalTimeToReadCSVContents += totalTimeToUpdateVanityURL;
									
								} else {
									out.println("<div class=\"error\">Error Occured: " + ics.GetErrno() + " OR Asset already exists in system: "+ returnValue + "</div>");
								}
								
								if(totalTimeToReadCSVContents < 1000)
									out.println("<hr><b>Content for CSV file Processed in : " + totalTimeToReadCSVContents + " milliseconds</b>");
								else
									out.println("<hr><b>Content for CSV file Processed in : " + (totalTimeToReadCSVContents / 1000) + " seconds</b>");
									
							} catch (Exception e) {
								out.println("<div class=\"error\">Exception Occured in ReadAssetDataFromCSV element: " + e.getMessage() + "</div><br/>");
							}
						}
						
					%></div>
				</div>
			</div>
		</body>
	</html>
</cs:ftcs>
```