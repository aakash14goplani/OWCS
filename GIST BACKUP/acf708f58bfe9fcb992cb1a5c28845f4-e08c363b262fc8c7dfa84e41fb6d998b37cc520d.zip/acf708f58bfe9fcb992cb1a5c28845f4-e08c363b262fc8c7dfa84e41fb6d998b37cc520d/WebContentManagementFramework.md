# WebCenter Sites as a Web Content Management Framework

![webmanagement-experience](https://github.com/aakash14goplani/OWCS/blob/master/images/webmanagement-experience.png)   

### The Content Server

The Sites Content Management System is the core of the product and was built from the ground up specifically to meet the wide demands of web content management. It’s a different animal from WebCenter Content in that it’s not designed for Enterprise Content/Document Management. This isn’t a shortcoming though as Sites’ unlimited asset modeling infrastructure creates the flexibility required to easily encompass the vast array of web content that can be thrown at it. More than just metadata, the asset modeling in Sites allows you to tag, reference, and interconnect your content more completely than ever before. With the addition of TEAM’s Sites Connector your WebCenter Content repository can communicate and share content with Sites making disparate repositories far more unified.

### Community

We can help you produce the most beautiful, most informative, most useful site the Internet has ever known but today’s standards on the web must include participation. Visitors want to see what you’re sharing but they also want to react as well. Establishing community around your product or information is one key to building brand trust and eliciting visitor return and Community for Sites provides a suite of functionality that overlays your whole Sites presence.  More than just commenting, Community provides reviews, ratings, polls, moderation capabilities and social network integration.

### Analytics

Oracle has recognized that your online presence metrics are not something that should be left to the whims of a third party or hammered at by a tool that wasn’t built to understand your web content management strategy. Analytics for Sites stands side-by-side with your implementation and delivers solid metrics not just based on the usual categories but also meshes with your targeting campaigns and edge caching strategy as well.

### Targeting

Knowing which content to show to which visitors and being able to make that a reality is a marketer’s nirvana. Accomplishing this is now very possible with Targeting for Sites. Combined with the power of real-time analytics, Targeting gives you the opportunity to segment visitors based on metrics appropriate to your business and to deliver relevant, informative content based on those segments. From simple suggestions based on browsing patterns to complex socioeconomic modeling based on analytics and geolocation, Targeting for Sites can help you deliver the right content to the right eyes.

### Satellite Server

How do you enable state-of-the-art distributed caching and publishing to drive faster content delivery to your visitors without paying a fortune? Sites has that covered. By deploying Satellite Server nodes on low-cost hardware, pages can be cached, assembled and even personalized for each visitor. This means no matter where they are in the world, you can take steps to improve visitors’ experience with your site.

Now realize that all these components are managed in a unified Web Experience Management interface and begin thinking on how we might arrange, utilize and manipulate different aspects of these components to build a comprehensive solution to your online presence needs. From rapid deployment to visitor interaction to targeted delivery to everything combined – the Sites components can clearly be utilized in a way that best fits your needs. That is a true framework. Oracle puts the tools on the table and we work together to forge a solution that’s more comprehensive, scalable, interactive, and unified than was ever possible before.   

### References
[teaminformatics](https://www.teaminformatics.com/blog/2012/08/21/webcenter-sites-as-a-web-content-management-framework/)  