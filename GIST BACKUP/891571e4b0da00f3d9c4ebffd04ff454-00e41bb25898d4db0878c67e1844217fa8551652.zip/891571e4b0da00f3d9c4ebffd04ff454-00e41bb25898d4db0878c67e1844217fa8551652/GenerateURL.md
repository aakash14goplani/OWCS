Oracle WebCenter Sites provides lot of options to generate url to a resource. The URL generation tags are used to construct a link to a WebCenter Sites resource, such as a page or a blob.

1. `render:gettemplateurl`
2. `satellite:link`
3. `satellite:blob`
4. `render:getpageurl`
5. `render:getbloburl`
6. `render:satelliteblob`

### `RENDER:GETTEMPLATEURL`
This tag is the preferred method for generating a URL to an asset (provided that the asset is being rendered through a Template, which is the recommendation). It effectively replaces render:getpageurl in most (but certainly not all) cases.

Instances of this tag must contain information about who the caller is in order to operate correctly. The caller must be either another Template or a CSElement. This tag will not operate correctly without valid information about the caller. (see tid & ttype above).

`render:gettemplateurl` operates in two modes: **explicit mode** and **context mode**.

In **explicit mode**, `c`, `cid`, and `tname` are explicitly specified as attributes to the tag. In essence, the asset identified by `c` and `cid` will be the subject of the URL along with the template named tname. If tname starts with “/” then the **typeless template** corresponding to tname will be used. Otherwise, the template corresponding to the specified tname and asset type (“c”) will be called. Usually, the template name will correspond to a **typeless layout template**, which will dispatch to typed templates to render the actual asset. Explicit mode is the only mode that is currently supported.

**Example**
```jsp
<render:gettemplateurl 
        outstr="aUrl"
        c='<%=ics.GetVar("c")%>' 
        cid='<%=ics.GetVar("cid")%>' 
        tname='<%=ics.GetVar("LayoutVar")%>' 
        wrapperpage='<%=ics.GetVar("WrapperVar")%>' >
    <render:argument name="p" value='<%=ics.GetVar("p")%>'/>
</render:gettemplateurl>
```

### `SATELLITE:LINK`
This example shows how to construct a URL to a page in Sites. This represents the most common usage of this tag.

**Example**
```jsp
<satellite:link pagename="OpenMarket/Samples/NewPortal/JSP/Main">
  <satellite:parameter name="mode" value="article"/>
  <satellite:parameter name="articleid" value='<%=ics.GetList("articlelist",false).getValue("id")%>'/>
</satellite:link>
```

### `SATELLITE:BLOB`
This tag retrieves a blob. `satellite:blob` returns a link tag to render the link in the page. This tag overrides the default caching expiration time defined by the Sites-Satellite expiration property. The `satellite:blob` tag is the preferred method to render images, downloadable documents, and other large objects that are managed by Sites.

**Example**
```jsp
<satellite:blob service="img src" 
                blobtable="MyImageTable" 
                blobkey="id"
                blobwhere="12345"
                blobcol="urlpicture"
                blobheader="image/gif"
                cachecontrol="*:30:0 */*/*">
    <satellite:parameter name='ALT' value='imagelist.alttext'/>
    <satellite:parameter name='BORDER' value='0'/>
</satellite:blob>
```

### `RENDER:GETPAGEURL`
Creates a URL for an asset, processing the arguments passed to it from the calling element into a URL-encoded string and returning it in a variable. A vanity URL will be used if available.

**Example**
```jsp
<render:getpageurl 
        pagename="BurlingtonFinancial/Article/Full"    
        cid='<%=ics.GetVar("asset.id")%>'
        c="Article" 
        outstr="theURL"
        />

<a href='<%=ics.GetVar("theURL")%>'> <ics:getvar name='asset:name'/> </a>
```

### `RENDER.GETBLOBURL`
Creates a BlobServer URL without embedding it in an HTML tag. A vanity URL will be used if available. This tag creates a BlobServer URL.

If rendermode is set to export,the tag creates a static URL; that is, a file name for an HTML file. It creates the URL based on the parameters described in the following section. These are a set of arguments that specify the table the blob is stored in, the name of the column that contains the binary data, the name of the primary key of the table, the value in that column to use to identify the object, and so on.

If rendermode is set to live, the tag creates a dynamic URL according to the current assembler.

Based on this information, `render:getbloburl` creates a URL for the blob asset and returns it to the element that requested it in a variable specified by the outstr parameter. The requesting element can then use the variable in an HTML tag to create the link.

To create BlobServer URL embedded in an HTML tag, use the `render:satelliteblob` tag.

**Example**
```jsp
<render:getbloburl 
        blobtable="ImageFile" 
        blobcol="urlpicture" 
        blobheader='<%=ics.GetVar("asset:mimetype")%>' 
        blobkey="id" 
        blobwhere='<%=ics.GetVar("asset:id")%>' 
        outstr="theURL"/>
```

### `RENDER:SATELLITEBLOB`
Retrieves a blob from a table or from the Sites-Satellite cache. This tag is equivalent of Sites-Satellite `satellite:blob` tag, with the following exception:

rendermode is passed in automatically.
When asset or `c`/`cid` are specified, compositional dependencies are recorded, and the blob will automatically be flushed from cache when the blob is modified.

**Example**
```jsp
<render:satelliteblob 
        blobtable="ImageFile" 
        blobkey="id" 
        blobcol="urlpicture" 
        blobwhere='<%=ics.GetVar("asset:id")%>' 
        blobheader='<%=ics.GetVar("asset:mimetype")%>' 
        service="img src">
    <render:argument name="alt" value='<%=ics.GetVar("asset:alttext")%>'/>
    <render:argument name="hspace" value="5"/>
    <render:argument name="vspace" value="5"/>
</render:satelliteblob>
```