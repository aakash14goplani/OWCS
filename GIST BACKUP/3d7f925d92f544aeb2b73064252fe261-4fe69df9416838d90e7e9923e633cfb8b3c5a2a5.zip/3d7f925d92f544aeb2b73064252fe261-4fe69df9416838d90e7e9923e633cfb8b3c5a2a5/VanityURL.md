### Configuring Vanity URL   

1. Click on Admin tab.
2. Under **Webroots** click on **Add new**
3. Enter unique **Host Name** (for example Practice_Site_HostName)
4. Enter **Root URL** (e.g. http://localhost:9080/cs/practice)
5. Select **Sites** for which this webroot.
6. Click on Admin tab.
7. Click on List all Asset Types
8. Select the particular asset type for which you want to enable vanity url (any particular asset or Page asset)
9. Under that asset type, from dropdown menu, select **URL Pattern**
10. Click on **Add new**
11. Select **Asset** or **Blob** as per requirement (Below is example for asset)
12. Select **Site** from the dropdown for which vanity url should be created
13. Select **Host** from the dropdown which was created in step 6.
14. Select **Subtype** for which this url should be generated.
15. Select **Template** from dropdown
16. Enter **Pattern** (e.g. ${f:spaceToUnderscore(name).toLowerCase()} )
17. Click on **Save**
18. Now in the Contributor UI, create the asset for which vanity URL was enabled
19. In that asset, click on **URL** tab and add URL. (Go to Admin>SystemTools>URL: You will find the URL that has been created. Make sure WebRoot is created)
20. Edit `web.xml` file (JSK path `InstallationFolder\App_Server\apache-tomcat-7.0.42\Sites\webapps\cs\WEB-INF\web.xml`) with the suffix of root url created in step 6.
   ```xml
   <init-param>
      <param-name>SitePrefix</param-name>
      <param-value>fsii,avi,practice</param-value>
   </init-param>
   ```
21. Restart the server.
22. Check the URL generated for asset in browser! 


### Fetch Vanity URL 

Vanity URL can be retrieved using [`render:gettemplateurl`](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/render-gettemplateurl.html), [`render:getbloburl`](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/render-getbloburl.html) or [`render:getpageurl`](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/render-getpageurl.html)  and later (if required) can be normalized using [`satellite:normalizeurl`](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/satellite-normalizeurl.html)


### References   
* [Configuring Vanity URLs - Develoer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29636/config_vanity_url.htm#WBCSA7473)   
* [Fatwiredev Blog](https://fatwiredev.blogspot.in/2014/03/example-6-creating-urls-for-hyperlinks.html)   
* [Programmatically Create Vanity URLs](https://www.function1.com/2016/09/how-to-programmatically-create-vanity-urls)   
* [Chetan Blog](http://chetancl.blogspot.in/2014/07/v-behaviorurldefaultvmlo.html)   
* [kksays Blog](https://kksays.wordpress.com/2014/10/29/1357/)