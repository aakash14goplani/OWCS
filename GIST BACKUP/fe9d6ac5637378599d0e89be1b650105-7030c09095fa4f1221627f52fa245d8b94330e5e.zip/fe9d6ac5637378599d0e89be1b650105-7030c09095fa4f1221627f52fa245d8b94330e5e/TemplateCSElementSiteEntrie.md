Many a times, while programming in FATWIRE, there will be a confusion about the usage of the appropriate tag, when try to call a TEMPLATE, or CSELEMENT, or SITEENTRY assets. This article makes a point to clear that confusion. We will now see which tag to be used appropriately for the above said assets.

1. As a **SITEENTRY** is a pagelet, we need to call it with a tag, that renders pages. `RENDER.SATELLITEPAGE` is the tag that is used to call the SiteEntries from our code.

2. Since a **CSELEMENT** has a piece of code, and itself is an Element, we need to use a tag that renders Elements. `RENDER.CALLELEMENT` is the tag that is used to call the CSElements from our code.

3. Since a **TEMPLATE** is both (Has a Page name, and has Element,i.e, code), it can be called bye both the above said tags. However, Fatwire has given another tag, especially for calling the Templates. `RENDER.CALLTEMPLATE` is the tag that is used to call a Template from our code.

### References

[kksays](https://kksays.wordpress.com/2012/02/09/calling-templates-cselements-and-siteentries-in-fatwire/)