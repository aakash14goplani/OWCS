### Introduction to XMLPOST:

In any Content Management System, the CONTENT forms the main part, i.e., the Content Assets. In general, in most of the scenarios, the content is actually generated through feeds / or some other data sources. We need to import data from such sources, and create content assets into the Content Server Database on the management system.

The Fatwire / Oracle WebCenter Sites Content Server delivers with a utility to perform such imports, hence reducing most of the efforts of the developer to write code for importing the data. That utility is nothing but the XMLPost Utility. To import any data from external sources into the Content Server database, we can use the XMLPost utility. This utility is delivered with the `CS – Direct`.

All we need to do is to invoke the XMLPost Utility from our program, or through command line.

### Components involved in the Process:

Following are the components involved in importing the data:

1. The XMLPost Utility, which ships by default with the Content Server.

2. The Posting Element, which also ships by default.
   * `CS – Direct` provides one posting element:  (For Importing BASIC ASSETS)
      + `RemoteContentPost` (`OpenMarket/Xcelerate/Actions/RemoteContentPost`)
   * `CS – Direct Advantage` provides three posting elements: (For Importing FLEX ASSETS)
      + `addData` (`OpenMarket/Gator/XMLPost/addData`)
      + `modifyData` (`OpenMarket/Gator/XMLPost/modifyData`)
      + `deleteData` (`OpenMarket/Gator/XMLPost/deleteData`)

3.  The Configuration file (`.ini` file), which specifies the information about the source files (in XML format), what assets need to be imported, information about the host, usernames, passwords, etc.

4.   The Source files. These are the well-formed XML files, which contains the data to be imported. This data is to be enclosed within respective tags.

### The Process:

1. First, we create the configuration files (`.ini` files), which has the information about the data that is to be imported.

2. Then we create the source files (XML files), which has the actual data that is to be imported.

3. Place these two files in a directory, and then invoke the XMLPost Utility.

4. Then the XMLPost Utility parses
   * The configuration file, which has been supplied by us.
   * The Source files, and creates name / value pairs.

 ![XMLPost Process](https://github.com/aakash14goplani/OWCS/blob/master/images/XMLPost.png)
 
5. Basing on the type of assets that we are trying to import, the Content Server invokes either of the elements.
   * **Basic Assets**
      + `RemoteContentPost`
   * **Flex Assets**
      + `addData`
      + `modifyData`
      + `deleteData`

6. The `RemoteContentPost` or `addData`/`modifyData`/`deleteData` elements perform the required actions and create the asset.

7. A HMTL will be returned to the XMLPost, to indicate whether the import operation has been succeeded or not. The information is logged into the log files, whose information is specified in the configuration files (the above specified .ini files).

8. If you specify to delete the source files (need to specify the parameter in the configuration file), the source files will be deleted once the import has been done.


### Invoking the XMLPost programmatically in FATWIRE

To import the assets through XMLPost, we need to invoke the XMLPost Utility. We will now see how to invoke XMLPost through a program:

1. To invoke the XMLPost utility programmatically, first we need to create an XMLPost object.

Example: `COM.FutureTense.XML.Post.XMLPost samplePoster = new COM.FutureTense.XML.Post.XMLPost();`

2. Using that object, we need to call the doIt method of the XMLPost.

Syntax: `doIt(String[] args)`

3. The elements of the array are the path values of source file and ini files. Here, the source parameter can point to:
   * A single file, like `-s/sample/Article-add.xml`
   * A directory of XML files, like `-s/sample/source-xml-files/`
   * A list file, like `-s/sample/xmlpostfiles.lst`

The list file provides a list of all the files that you want to import. It is similar to an `.ini` file but with extension of `.lst`.

In total, we need to program as follows. Include other calls to any other elements basing on your requirement.

```jsp
………… Your code here…………..

strSourceFileDir = “-s/sample/Article-add.xml”;
strConfigFile = “-c/sample/Article-add-config.ini”;

String args[]  = {strSourceFileDir,strConfigFile};

COM.FutureTense.XML.Post.XMLPost samplePoster = new COM.FutureTense.XML.Post.XMLPost();
try 
{
    samplePoster.doIt(args);   // here we are supplying the xml and ini file values
} 
catch (Exception e)
{
    ics.LogMsg(” —- your error message here —–“);
}
  ………… Your code here…………..
``` 
  
 ### References
  
 [kksays 1](https://kksays.wordpress.com/2012/12/12/xmlpost-in-fatwire-oracle-webcenter-sites/)   
 [kksays 2](https://kksays.wordpress.com/2012/12/12/invoking-the-xmlpost-programmatically-in-fatwire/)