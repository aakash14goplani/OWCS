# When to use Basic Assets

Nowadays Flex Assets are used in a predominant way to build your Fatwire website.
Basic Assets are however still there, and there are some cases when they should be considered (and use) them.  Here is a couple of examples:

1. **Data Migration:**
   * Basic Assets are more close in their underlying structure to a database table than the Flex Assets. So it is viable to fill them with database queries. It is much more difficult to do so with Flex Assets.
   * For example migrating a large dataset that was not expected to change. It is simpler to create a basic asset and then move data in the generated table than use a flex asset and the Bulk Loader (that is nonetheless available for those tasks, as well).

2. **User Generated Content:**
   * Another case is to store User Generated content: for example, user registration. Instead of building a full feature Flex Asset (using for example the Asset API) it was simpler just to create a plain basic asset and register users creating new instances of that asset.


Is is also faster to create an instance of a Basic Asset than of a Flex Asset, and this can be a winning feature sometimes.