CatalogMover is a tool which is used to export / import the database tables. We can even export the `ElementCatalog` and `SiteCatalog` tables. We can export all the assets like page assets, content assets, etc., and import all of these assets into another system (target system). We can export / import all the database tables as HTML / ZIP files. This tool can be used with Windows machine by the Windows Interface. In the rest of the operating systems, it can be used through the Command Line Interface. The advantage of CatalogMover over CS-Explorer is that this tool can be used in any operating system.

We can do the following activities with CatalogMover.

1. **Export Tables:** Exporting is the process of retrieving table rows and their content from the database and saving them in local HTML files and associated data directories.
2. **Import Tables:** Importing is the process of sending locally stored HTML files and the associated data to the server. You can select a particular HTML file to import, or you can choose to import all HTML files.

To Start the CatalogMover, Execute the following scripts at the MS DOS prompt or in a UNIX shell:

**For Windows:** `CatalogMover.bat`
**For Solaris:** `CatalogMover.sh`

 ![CatalogMover](https://github.com/aakash14goplani/OWCS/blob/master/images/CatalogMover.png)
 
### References

[kksays](https://kksays.wordpress.com/2012/12/04/catalogmover-tool-in-fatwire/)