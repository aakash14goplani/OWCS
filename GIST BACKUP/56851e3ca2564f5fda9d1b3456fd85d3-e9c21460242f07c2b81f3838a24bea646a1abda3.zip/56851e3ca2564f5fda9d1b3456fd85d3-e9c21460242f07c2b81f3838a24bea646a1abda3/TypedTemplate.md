# Typed Templates

A very interesting concept in Fatwire is that templates are "typed". Unfortunately, this is also a concept very easily misunderstood.

The idea is:

* You define a number of content types
* Then you apply a set  of standard templates to that content type (like method of a class in OOP)
* Name of the templates should be standardized
* For example, you can have News, Articles and Blog posts as content types.

The best way is to decide for a number of common way of render the content: for example: Summary, Detail, Link.

So you can expect to have something like this:

```
News/Summary
News/Detail
News/Link
Article/Summary
Article/Detail
Article/Link
Blog/Summary
Blog/Detail
Blog/Link
```

If you follow those conventions, combining templates becames very easy. You can add in a page a Blog or an Article and then replace with a News.

Just call the template as it should (using a `call:template` that specify the `c` and only the Summary - the "relative" way). This way rendering an Article as a summary is the same as rendering a Blog as a summary.

But you start to give different names to template without following any conventions... your code will became a mess. And you won't exploit the "typed template" approach built-in in Fatwire.

### References

[]()