# How Fatwire manage cache?

Fatwire provide 2 level of caching:
1. Content Server Cache (CSCache)
2. Satellite Server Cache (SSCache)

**Note**: I will use CS and SS for Content Server and Satellite Server.

Let’s have a look how fatwire serve a request:   

![CacheManagement](https://github.com/aakash14goplani/OWCS/blob/master/images/cacheManagement.jpg)

1. Every time a user (End user) hit a page (A), the request goes to SS
2. SS check if the requested page/pagelete is available in its cache. If the requested page/pagelate is available in SS cache, then it servers the requested page back to end user (E,F) otherwise SS request CS to provide it the requested page/pagelete (C)
3. CS check if the requested page/pagelete is available in its cache. If the requested page/pagelate is available in CS cache, then it servers the requested page back to SS (D) otherwise CS follow the following steps:
4. CS process the code (Templates/CSElements) to generate the requested page/pagelete.
5. Cache* the page/pagelete on CS
6. Return the output to SS (D)
7. Now, SS cache* the processed page/pagelete and return the complete page back to requested user (E,F)


Its not necessary that we cache every page/pagelete. If a page is cached but it’s internally calling number of uncached Elements (CSElements/Templates) then the cached page save the call for that element instead of html output. So every time a user request for a page, these uncached elements will got evaluated on CS.

### References

[mkbansal](https://mkbansal.wordpress.com/2010/06/08/fatwire-caching-how-fatwire-manage-cache/)