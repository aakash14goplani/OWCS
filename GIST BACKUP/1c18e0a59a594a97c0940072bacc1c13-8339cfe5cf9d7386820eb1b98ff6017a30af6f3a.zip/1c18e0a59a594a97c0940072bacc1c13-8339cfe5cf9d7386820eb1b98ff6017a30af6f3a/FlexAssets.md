# Single flex family or multiple flex families   

A normal flex family relationship is as shown below:   
```
Flex Attributes   
   Flex Parent Definition   
      Flex Child Definition   
         Flex Parent   
            Flex Child   
```

So, we define a set is attributes which forms part of parent and child definitions. These form the templates to organise content through creation of parents and creating content through child assets. Straightforward till now. The flexibility comes as database model allow to add new attributes, modify existing definitions without any database level changes.   


Another aspect of flexibility is that you can use same attributes to define different asset types at each level i.e. parent definition, child definition, parent or child. And again you can mix and match.
To give you a feel, here are few examples:   


**Example 1: Different Child Asset Types**   
```
Flex Attributes   
   Flex Parent Definition 1   
      Flex Child Definition 1   
         Flex Parent 1   
            Flex Child 1   
            Flex Child 2   
            Flex Child 3   
```

**Example 2: Different Parent Definition, Child Definition, Parent and Child Asset Types**   
```
Flex Attributes   
   Flex Parent Definition 1   
      Flex Child Definition 1   
         Flex Parent 1   
            Flex Child 1   
   Flex Parent Definition 2   
      Flex Child Definition 2   
         Flex Parent 2   
            Flex Child 2   
```


**Example 3: Different Child Definition, same Parent, Different Child Asset Types**   
```
Flex Attributes   
   Flex Parent Definition 1   
      Flex Child Definition 1   
         Flex Parent 1   
            Flex Child 1   
      Flex Child Definition 2   
         Flex Parent 1   
            Flex Child 2   
      Flex Child Definition 3   
         Flex Parent 1   
            Flex Child 3   
```

So, its possible to just define one flex family with one set of attributes but different parent and child asset types within the family so that all the benefits of having a separate Asset Type could be achieved. A logically grouping in few families work really well than just one flex family or having family for each asset type identified.   


# Data Structure of a Flex Family

While creating a new Flex family, following are the types defined:

1. **Flex Attributes:** Refers to the attributes defined to support flex parent and child definitions to hold information
2. **Flex Parent Definitions:** Refers to attribute set which are common to all child which sits beneath them
3. **Flex Child Definitions:** Refers to attribute set which stores the actual value of the child
4. **Flex Parent:** Actual Parent asset based on one of the definition defined by parent definitions
5. **Flex Child:** Actual Child asset based on one of the definition defined by child definitions
6. **Flex Filters:** Filters that run on asset save to perform various post edit functionalities


Lets look at the various tables which are created by WCS against each of the above types:
 
1. **Flex Attributes:**

* `<ASSETTYPE>_A`: This is the base table for attributes and stores meta information of attributes including, `AttributeType` i.e. which kind of attribute editor
* `<ASSETTYPE>_A_ARGS`: `_A_Args` is usually when arguments are defined against a type.
* `<ASSETTYPE>_A_DIM`: This records  asset assignment against a locale (Dimension) specially when same asset is used across various locales.
* `<ASSETTYPE>_A_DIMP`: When an asset is assigned a locale for the first time, it gains master, or dimension parent status.
* `<ASSETTYPE>_A_EXTENSION`: Records Attribute setup values like: Content Type, Asset Type, Search Engine properties etc.
* `<ASSETTYPE>_A_PUBLISH`: aybe for future use

2. **Flex Filters:**

* `<ASSETTYPE>_F`: This table stores the meta information of the Flex filter
* `<ASSETTYPE>_F_ARGS`: This table stores the mapping for Arguments for filters. For example, for a Field Copy filter it will store e.g. `ParentAssetId = id` which means `id` will be copied into `ParentAssetId` attribute.
* `<ASSETTYPE>_F_DIM`: This records asset assignment against a locale (Dimension) specially when same asset is used across various locales.
* `<ASSETTYPE>_F_DIMP`: When an asset is assigned a locale for the first time, it gains master, or dimension parent status.
* `<ASSETTYPE>_F_PUBLISH`: Maybe for future use

3. **Flex Parent Definition:**

* `<ASSETTYPE>_PD`: This table stores meta information of the parent definition
* `<ASSETTYPE>_PD_DIM`: This records  asset assignment against a locale (Dimension) specially when same asset is used across various locales.
* `<ASSETTYPE>_PD_DIMP`: When an asset is assigned a locale for the first time, it gains master, or dimension parent status.
* `<ASSETTYPE>_PD_PUBLISH`: Maybe for future use
* `<ASSETTYPE>_PD_TATTR`: This table stores which attributes belongs to which definition, their order, mandatory/optional
* `<ASSETTYPE>_PD_TFILTER`: This table stores Filters mapping for parent definitions
* `<ASSETTYPE>_PD_TGROUP`: This table sotres Parent mappings for a parent definition- whether parent is required, allows multiple parent assications etc.

4. **Flex Definition:**

* `<ASSETTYPE>_CD`: This table stores meta information of the child definition
* `<ASSETTYPE>_CD_DIM`: This records  asset assignment against a locale (Dimension) specially when same asset is used across various locales.
* `<ASSETTYPE>_CD_DIMP`: When an asset is assigned a locale for the first time, it gains master, or dimension parent status.
* `<ASSETTYPE>_CD_PUBLISH`: Maybe for future use
* `<ASSETTYPE>_CD_TATTR`: This table stores which attributes belongs to which definition, their order, mandatory/optional
* `<ASSETTYPE>_CD_TFILTER`: This table stores Filters mapping for parent definitions
* `<ASSETTYPE>_CD_TGROUP`: This table stores Parent mappings for a definition- Required parents, single or multiple parents etc.

5. **Flex Parents:**

* `<ASSETTYPE>_P`: This table stores meta information of the parent assets
* `<ASSETTYPE>_P_AMAP`: This table stores mapping of which attributes belongs to which asset, including inherited from parent/s
* `<ASSETTYPE>_P_DIM`: This records  asset assignment against a locale (Dimension) specially when same asset is used across various locales.
* `<ASSETTYPE>_P_DIMP`: When an asset is assigned a locale for the first time, it gains master, or dimension parent status. This information is stored as part of this table
* `<ASSETTYPE>_P_EXTENSION`: Stores RULESET ID
* `<ASSETTYPE>_P_GROUP`: This table maintains parent hierarchy for the assets defined as parent
* `<ASSETTYPE>_P_MUNGO`: This table stores the actual values of the attributes for each parent asset as a separate row in database
* `<ASSETTYPE>_P_PUBLISH`: Maybe for future use
* `<ASSETTYPE>_P_RMAP`: No idea
* `<ASSETTYPE>_P_ROOT`: This table stores the id of the Root Parent within the Tree/hierarchy

6. **Flex Assets:**

* `<ASSETTYPE>_C`: This table stores meta information of the child assets
* `<ASSETTYPE>_C_AMAP`: This table stores mapping of which attributes belongs to which asset, including inherited from parent/s
* `<ASSETTYPE>_C_DIM`: This records  asset assignment against a locale (Dimension) specially when same asset is used across various locales.
* `<ASSETTYPE>_C_DIMP`: When an asset is assigned a locale for the first time, it gains master, or dimension parent status. This information is stored as part of this table
* `<ASSETTYPE>_C_EXTENSION`: Stores RULESET ID
* `<ASSETTYPE>_C_MUNGO`: This table stores the actual values of the attributes for each child asset as a separate row in database
* `<ASSETTYPE>_C_PUBLISH`: Maybe for future use
* `<ASSETTYPE>_C_RMAP`: No idea 

# Use of Flex Filters and Search states tags   

Flex filters are powerful way of post processing the information of flex assets determined by supplied attribute values or otherwise. They are powerful way of achieving post processing on Flex assets ONLY. Flex filter is called when the asset is saved, provided filter is part of the asset definition. So, if flex filter is added after the content is already created, the assets need to be re-saved in order for flex filters to take effect on those assets.   

Lets start with few quick Filters which are shipped with WCS:   

1. **Doc-Type:** Extracts Mime type of uploaded file type and store as part of an attribute value within asset
2. **Thumbnail Creator:** which converts an uploaded image to thumbnail image
3. **Field Copier:** copies contents of system defined attribute to user defined attribute
4. **Document Transformation filter:** which converts the document uploaded of one type to another type using registered transformation engine   

Since asset load of flex family is costly, its always a good idea to use field copier to copy stuff like Flex Definition, name, id etc. which makes search states straightforward. For example, we have a definition called “Document” and “File” which are arranged within hierarchy like:
```
Politics
        Politics Document 1 – Document Flex Definition
        Politics Document 2 – Document Flex Definition
        Politics File 1 – File Flex Family
Sports
       Sports Document 3 – Document Flex Definition
       Sports Document 4 – Document Flex Definition
       Sports File 2 – File Flex Family
```

So, if we define file copier flex filter to copy flex definition into an attribute called FlexDefinition then to retrieve all documents for sports, we can directly write a search state which specify FlexDefinition as “Document” and Parent as “Sports”. This will give us Sports Document 3 and Sports Document 4.
Flex filters are very powerful, but could hinder the content authoring experience. So use them carefully.   

# Defining parent/child hierarchy for Flex Assets   

While designing asset model, it is important to understand the kind of flexibility required by content authors to arrange content. Is there a need of fixed hierarchy or a flexible hierarchy or a combination of two.  Lets look at what I mean by fixed and flexible hierarchies:   

Fixed Hierarchy example: 
```
Level 1 Parent —> Level 2 Parent —–> Level 3 parent —–> Level 4 parent ——->  Child
News —–> Economics ——-> <Year>  —–> <Month> ———> News Article 1
News —–> Economics ——-> <Year>  —–> <Month> ———> News Article 2
News —–> Movies  ——-> <Year>  —–> <Month> ———> Sports Article 1
News —–> Movies  ——-> <Year>  —–> <Month> ———>Sports Article 2
News —–> Movies  ——-> <Year>  —–> <Month> ———>Sports Article 3
```
As shown above, child assets always goes after level 4 parent. This can be forced within Asset model so child always placed at below Level 4 parent.   
 
Flexible Hierarchy example:
`Level 1 Parent —–> Child`   
or   
`Level 1 Parent ——-> Level 2 Parent ——–> Child`   
and so on …basically any level of Parent-child relationship
```
News —–> Top News Article
News ——> Sports ——–> Cricket ——> <Year> ——> <Month> ——> world cup ——> Article 1
News ——> Sports——> Article 2
News ——> Sports ——–> Cricket——-> Article 3
News ——> Sports ——–> Cricket ——> <Year> ——> <Month>—–> Article 4
```

So, child in this case could be associated with parent at any level. Again, to gain such flexibility, we can define a recurcive parent, lets say Parent, which could be added in the hierarchy to itself.   

Or we can have a mix of fixed and flexible hierarchy which:
* Meets the need of Content Authors
* Makes it easy from coding perspective especially with search states

It is important to note that any attributes defied on parent level are inherited within each child physically i.e. as database row. So, when the amount of data is huge, this could make a difference in storage requirements as well as in retrieving content. Also, its important to extract only common attributes to parent level and keep them bare minimum to achieve efficiency and performance.       


### References

1. [asset-modelling-single-family-or-multiple-families](http://sites.shishank.info/2013/07/15/asset-modelling-single-family-or-multiple-families/#more-168)
2. [data-structure-of-a-flex-family](http://sites.shishank.info/2013/07/10/data-structure-of-a-flex-family-cs-7-6-2/#more-158)   
3. [asset-modelling-use-of-flex-filters-and-search-states-tags](http://sites.shishank.info/2013/07/03/asset-modelling-use-of-flex-filters-and-search-states-tags/#more-151)   
4. [defining-parentchild-hierarchy-for-flex-assets](http://sites.shishank.info/2013/06/24/asset-modelling-defining-parentchild-hierarchy-for-flex-assets/#more-143)   
5. [sites.shishank.info](http://sites.shishank.info/)