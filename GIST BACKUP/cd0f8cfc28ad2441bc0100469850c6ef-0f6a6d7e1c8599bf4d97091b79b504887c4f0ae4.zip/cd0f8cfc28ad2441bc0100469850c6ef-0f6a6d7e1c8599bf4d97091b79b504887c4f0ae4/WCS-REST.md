Using the WebCenter Sites REST API – Part 1   

This tutorial is a two part introduction to the WebCenter Sites REST API.

In this, the first part, we’ll look at building a simple java client for communicating with WebCenter Sites. In the second we’ll use that client to manage users in WCS by storing their details in a spreadsheet.


Getting started

To start with you’ll need the following installed:

A local instance of WCS (this could be a JSK or similar)
Eclipse
Maven
Now you can either clone this project from GitHub or you can follow along with the tutorial and create the project yourself. First lets look at our POM

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>uk.co.manifesto.wcs</groupId>
  <artifactId>data-manager</artifactId>
  <version>0.0.1-SNAPSHOT</version>
  <packaging>jar</packaging>

  <name>data-manager-part1</name>
  <url>http://maven.apache.org</url>

  <properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
  </properties>

  <dependencies>
    <!-- jersey -->
    <dependency>
        <groupId>com.sun.jersey</groupId>
        <artifactId>jersey-client</artifactId>
        <version>1.17.1</version>
    </dependency>
    <!-- sites -->
    <dependency>
        <groupId>com.fatwire.wem.sso.cas</groupId>
        <artifactId>wem-sso-api-cas</artifactId>
        <version>11.1.1.8.0</version>
    </dependency>
    <dependency>
        <groupId>com.fatwire.wem.sso</groupId>
        <artifactId>wem-sso-api</artifactId>
        <version>11.1.1.8.0</version>
    </dependency>   
    <dependency>
        <groupId>com.fatwire.wem.api</groupId>
        <artifactId>rest-api</artifactId>
        <version>11.1.1.8.0</version>
    </dependency>
    <!-- spring -->
    <dependency>
        <groupId>org.springframework</groupId>
        <artifactId>spring-beans</artifactId>
        <version>3.2.4.RELEASE</version>
    </dependency>   
    <!-- guava -->
    <dependency>
        <groupId>com.google.guava</groupId>
        <artifactId>guava</artifactId>
        <version>15.0</version>
    </dependency>   
    <!-- cas -->
    <dependency>
        <groupId>org.jasig.cas</groupId>
        <artifactId>cas-client-core</artifactId>
        <version>3.1.9</version>
    </dependency>           
    <!-- test -->              
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.10</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
  <build> 
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-compiler-plugin</artifactId>
            <version>2.0.2</version>
            <configuration>
                <source>1.6</source>
                <target>1.6</target>
            </configuration>
        </plugin>
    </plugins>
  </build>
</project>
We’ve got some WCS dependencies that won’t be in Maven Central so lets go and add them to our local repository.

The easiest way to do this to navigate to the lib directory of the cs web application on the command line and run the following mvn commands

mvn install:install-file -Dfile=wem-sso-api-cas-11.1.1.8.0.jar -DgroupId=com.fatwire.wem.sso.cas -DartifactId=wem-sso-api-cas -Dversion=11.1.1.8.0 -Dpackaging=jar -DgeneratePom=true

mvn install:install-file -Dfile=wem-sso-api-11.1.1.8.0.jar -DgroupId=com.fatwire.wem.sso -DartifactId=wem-sso-api -Dversion=11.1.1.8.0 -Dpackaging=jar -DgeneratePom=true

mvn install:install-file -Dfile=rest-api-11.1.1.8.0.jar -DgroupId=com.fatwire.wem.api -DartifactId=rest-api -Dversion=11.1.1.8.0 -Dpackaging=jar -DgeneratePom=true
Creating the Client

To start with we’re going to use the Client class that Jersey provides us to do the heavy lifting.

We’re then going to create a method for authenticating with WebCenter Sites.

Finally we’ll create some generic methods wrapping the basic Create, Read, Update and Delete functionality provided by the underlying API.

Let’s start by having a look at the constructor and fields for our RestClient class:

    private Client client;
    private String baseUri;
    private String multiticket;
    private WebResource baseResource;
    private boolean connected = false;
    private final String username;
    private final String password;

public RestClient(String baseUri, String username, String password) throws RestConnectionException {
    this.client = new Client();
    this.baseUri = baseUri;
    this.baseResource = client.resource(baseUri + "REST");
    this.username = username;
    this.password = password;
    authenticate();
}
Passed in to the constructor are the baseUri for the WebCenter Rest API and then a username and password.

This allows us to authentication with the service.

Then we create a Jersey client to use and set our baseResource to the REST endpoint.

Authentication

Let’s have a look at the authenticate method next:

private void authenticate() throws RestConnectionException {
    try {
        SSOSession ssoSession = SSO.getSSOSession(baseUri);
        multiticket = ssoSession.getMultiTicket(username, password);
        baseResource = baseResource.queryParam("multiticket", multiticket);
    } catch (SSOException e) {
        throw new RestConnectionException(e);
    }
} 
There are a couple of ways to authenticate with WebCenter Sites but I think this way is the easiest – it relies on passing the baseUri of our WebCenter Sites instance to the static method getSSOSession of the SSO class.

This then allows to get a multiticket which we add as a query parameter to our baseResource.

It’s worth noting at this point that a multiticket allows us to reuse the query parameter for multiple request, it does however eventually expire and a more complete implementation would need to provide a strategy for catching that exception and re-attempting authentication.

It’s also worth talking briefly about the way we’re using getSSOSession. The javadoc for this class isn’t particularly clear that it is possible to use the method in the way that we do. It says the method

Obtains a new SSO session by loading configuration from a Spring configuration file.

What it doesn’t tell you is that you can find that config for a particular WebCenter Sites instance by passing in the baseUri.

The URI that’s ultimately queried for the information is this

/cs/Satellite?pagename=fatwire/wem/sso/casInfo

and if you have a look at the response you can see it returns an XML document that looks like this

<casproperties>
<authPrefix>cas</authPrefix>
<restServiceUrl>http://localhost:9080/cas</restServiceUrl>
<ticketServerUrl>http://localhost:9080/cas/v1/tickets</ticketServerUrl>
<ticketParamName>ticket</ticketParamName>
<multiticketParamName>multiticket</multiticketParamName>
<usesso>false</usesso>
<providerClass>com.fatwire.wem.sso.cas.CASProvider</providerClass>
<configClass>com.fatwire.wem.sso.cas.conf.CASConfig</configClass>
</casproperties>
If for whatever reason you’re uncomfortable using this method to authenticate you can follow the instructions in the Oracle documentation. They are a little longer winded but perform the same function.

Now that we’ve authenticated we can start talking CRUD.

CRUD

The next step in building our client is to provide methods to Create, Read, Update and Delete resources from WCS.

Lets take a look at our Get (Read) method first

public ClientResponse get(String path)  {
    WebResource getResource = this.baseResource.path(getRelativePath(path));    
    Builder builder = getResource.accept(MediaType.APPLICATION_XML);
    return builder.get(ClientResponse.class);
}
This is a fairly simple method in that it accepts a path either relative to the baseResource (/cs/REST) or an absolute URL.

We use this path to create a WebResource and then use the WebResource.Builder class to create a HTTP GET request to our resource and return the response wrapped in a ClientResponse class.

The ClientResponse class allows us to interrogate the response before we decide what we want to do with it.

For example this code snippets checks to see that a request for users has been successful before trying to serialise it.

    ClientResponse response = client.get("/users");
    if (response.getStatus() == 200) {
        UsersBean users = response.getEntity(UsersBean.class);
    }  
Next let’s look at our Create method and its related helper method getBuilder

public <T> ClientResponse post(T bean, String path) {
    WebResource getResource = this.baseResource.path(getRelativePath(path));
    Builder builder = getBuilder(getResource);
    return builder.post(ClientResponse.class, bean);
}

private Builder getBuilder(WebResource getResource) {
    Builder builder = getResource.accept(MediaType.APPLICATION_XML);
    builder = builder.header("Pragma", "auth-redirect=false");
    builder = builder.header("X-CSRF-Token", multiticket);
    return builder;
}
Again we accept a path identifying the resource that we want to post to, but this time, using Generics, we also accept a javabean for posting to the server.

This Oracle documentation describes the list of the beans available.

There are a couple of things interesting in the getBuilder helper method, the first is the X-CSRF-Token header.

Without adding this token we won’t be able to perform any of the PUT,POST,DELETE methods – you’ll notice that it’s just our multiticket value.

And the second Pragma header lets the underlying service know that we’re making this request outside of a web application so that if authentication fails we don’t want to be redirected to the login page.

Lastly our Update and Delete methods are pretty similar although delete doesn’t return require a java bean in the request body

public ClientResponse delete(String path) {
    WebResource getResource = this.baseResource.path(getRelativePath(path));
    Builder builder = getBuilder(getResource);
    return builder.delete(ClientResponse.class);
}

public <T> ClientResponse put(T bean, String path) {
    WebResource getResource = this.baseResource.path(getRelativePath(path));
    Builder builder = getBuilder(getResource);
    return builder.put(ClientResponse.class, bean);
}
With all this in place our final RestClient class looks like this

package uk.co.manifesto.wcs.datamanager.rest;

import javax.ws.rs.core.MediaType;

import uk.co.manifesto.wcs.datamanager.rest.exception.RestConnectionException;

import com.fatwire.wem.sso.SSO;
import com.fatwire.wem.sso.SSOException;
import com.fatwire.wem.sso.SSOSession;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

public class RestClient {

    private Client client;
    private String baseUri;
    private String multiticket;
    private WebResource baseResource;
    private final String username;
    private final String password;

    public RestClient(String baseUri, String username, String password) throws RestConnectionException {
        this.client = new Client();
        this.baseUri = baseUri;
        this.baseResource = client.resource(baseUri + "REST");
        this.username = username;
        this.password = password;
        authenticate();
    }

    public ClientResponse get(String path)  {
        WebResource getResource = this.baseResource.path(getRelativePath(path));    
        Builder builder = getResource.accept(MediaType.APPLICATION_XML);
        return builder.get(ClientResponse.class);
    }

    public ClientResponse delete(String path) {
        WebResource getResource = this.baseResource.path(getRelativePath(path));
        Builder builder = getBuilder(getResource);
        return builder.delete(ClientResponse.class);
    }

    public <T> ClientResponse put(T bean, String path) {
        WebResource getResource = this.baseResource.path(getRelativePath(path));
        Builder builder = getBuilder(getResource);
        return builder.put(ClientResponse.class, bean);
    }

    public <T> ClientResponse post(T bean, String path) {
        WebResource getResource = this.baseResource.path(getRelativePath(path));
        Builder builder = getBuilder(getResource);
        return builder.post(ClientResponse.class, bean);
    }

    private Builder getBuilder(WebResource getResource) {
        Builder builder = getResource.accept(MediaType.APPLICATION_XML);
        builder = builder.header("Pragma", "auth-redirect=false");
        builder = builder.header("X-CSRF-Token", multiticket);
        return builder;
    }

    private String getRelativePath(String path) {
        if (path.startsWith(baseUri)) {
            path = path.replace(baseUri + "REST", "");
        }
        return path;
    }   

    private void authenticate() throws RestConnectionException {
        try {
            SSOSession ssoSession = SSO.getSSOSession(baseUri);
            multiticket = ssoSession.getMultiTicket(username, password);
            baseResource = baseResource.queryParam("multiticket", multiticket);
        } catch (SSOException e) {
            throw new RestConnectionException(e);
        }
    }
}
Sample Implementation

I’ve also included in the project a sample Runner class that exercises our RestClient.

The main method is shown below

    public static void main(String[] args) throws RestConnectionException {
        RestClient client = new RestClient("http://localhost:9080/cs/", "fwadmin","xceladmin");
        ClientResponse response = client.get("/users");
        if (response.getStatus() == 200) {
            UsersBean users = response.getEntity(UsersBean.class);
            for (User user : users.getUsers()) {
                ClientResponse userResponse = client.get(user.getHref());
                if (userResponse.getStatus() == 200) {
                    UserBean userBean = userResponse.getEntity(UserBean.class);
                    System.out.println(userBean.getName());
                    System.out.println(userBean.getId());
                    List<String> siteNames = new ArrayList<String>();
                    for (UserSite userSite : userBean.getSites()) {
                        siteNames.add(userSite.getSite() + "=>" + Joiner.on(",").join(userSite.getRoles()));
                    }
                    System.out.println(Joiner.on(" || ").join(siteNames));
                    System.out.println(Joiner.on(",").join(userBean.getAcls()));
                }
            }
        }
    }
All this does is get a list of users from WebCenter Sites and output their details.

Have a well earned rest (no pun intended) and I’ll see you in part two.   

https://manifesto.co.uk/using-webcenter-sites-rest-api-part-1/   

-------------------------------------------------------------------   


Using the WebCenter Sites REST API – Part 2   

This is the second part in our introductory tutorial to the WebCenter Sites REST API.

Part one can be found here.

We’ll be carrying on where we left off last time and you can either clone the updated project from GitHub or follow along yourself.


REST-API

Last time we created a generic rest client for talking to the WCS Rest API.

This time we’re going to use it to do something useful. We’re going to use it to maintain our WCS users in a Excel Spreadsheet.

Getting Started

To start we need to add one new dependency to our POM

<!-- poi -->
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi-ooxml</artifactId>
    <version>3.9</version>
</dependency>
POI is an Apache project for reading and writing Microsoft Office documents.

Today we’re going to use it to read a spreadsheet with data about our users.

You can read more about POI here.

We’ve chosen to include the dependency that works with the XLSX file format.

So lets start by looking at the data in our sample spreadsheet (you can find the spreadsheet as part of the GitHub project in src/main/resources)

Name	Password	Acls	Sites[Roles]
pat	test1	TableEditor,Visitor,VisitorAdmin,UserEditor,UserReader,xceladmin,Browser,xceleditor,xcelpublish,PageEditor,ElementEditor,RemoteClient,WSUser,WSEditor,WSAdmin	avisports=>GeneralAdmin,ConnectorAdmin,Reviewer,MobileSitesDeveloper,Writer,SiteAdmin,SitesUser,AdvancedUser,Editor_In_Chief,WorkflowAdmin
jim	test2	TableEditor,Visitor,VisitorAdmin,UserEditor,UserReader,xceladmin,Browser,xceleditor,xcelpublish,PageEditor,ElementEditor,RemoteClient,WSUser,WSEditor,WSAdmin	avisports=>GeneralAdmin,ConnectorAdmin,Reviewer,MobileSitesDeveloper,Writer,SiteAdmin,SitesUser,AdvancedUser,Editor_In_Chief,WorkflowAdmin
curtis	test3	TableEditor,Visitor,VisitorAdmin,UserEditor,UserReader,xceladmin,Browser,xceleditor,xcelpublish,PageEditor,ElementEditor,RemoteClient,WSUser,WSEditor,WSAdmin	avisports=>GeneralAdmin,ConnectorAdmin,Reviewer,MobileSitesDeveloper,Writer,SiteAdmin,SitesUser,AdvancedUser,Editor_In_Chief,WorkflowAdmin
Our table has four columns:

Name – name of the user to create
Password – password of the user to create
Acls – acls of the user to create
Sites[Roles] – a mapping of the sites this user should have access to and the roles they have in that site
Reading Data from Excel

Now we have our sample data we need to try and read and parse it.

Lets have a look at the field where we store our spreadsheet data and the method we’ll use to load it from the filesystem

private Workbook workBook;

private void loadWorkbook(File spreadsheet) {
    try {
        OPCPackage pkg = OPCPackage.open(spreadsheet);
        workBook = new XSSFWorkbook(pkg);
        pkg.close();
    } catch (InvalidFormatException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
The OPCPackage class provides a less memory hungry way of working with spreadsheets in POI than an InputStream although in our case it’s probably arguable that three rows in a spreadsheet doesn’t constitute a particularly big resource drain.

Next we’ll look to parse the data out of the spreadsheet and create some UserBeans from it

private static final int USER_SITES = 3;
private static final int ACLS = 2;
private static final int PASSWORD = 1;
private static final int NAME = 0;

private List<UserBean> getUsersFromWorkbook() {
    List<UserBean> users = new ArrayList<UserBean>();
    Sheet sheet = workBook.getSheetAt(0);
    for (int i = 1; i <= sheet.getLastRowNum(); i++) {
        Row row = sheet.getRow(i);

        String name = row.getCell(NAME).getStringCellValue();
        String password = row.getCell(PASSWORD).getStringCellValue();
        List<String> acls = getAcls(row.getCell(ACLS).getStringCellValue());
        List<UserSite> userSites = getUserSites(row.getCell(USER_SITES).getStringCellValue()); 

        UserBean newUser = buildUser(name, password, acls, userSites);
        users.add(newUser);
    }
    return users;
}
There are a couple of methods here that we should look at in more detail.

The first two are helper methods for deserialising the format that we’ve stored our acls and site->role mappings in the spreadsheet.

The method getUserSites splits the string it receives to find the site and the list of comma delimited roles and then converts that string into a list of strings that describe each role.

The method getAcls simply parses our comma delimited list of acls and returns it as a list.

private List<UserSite> getUserSites(String stringCellValue) {
    List<UserSite> userSitesToReturn = new ArrayList<UserSite>();
    String[] siteRole = stringCellValue.split("=>");
    UserSite userSite = new UserSite();
    userSite.setSite(siteRole[0]);
    userSite.getRoles().addAll(Lists.newArrayList(Splitter.on(',').split(siteRole[1])));
    userSitesToReturn.add(userSite);
    return userSitesToReturn;
}

private List<String> getAcls(String stringCellValue) {
    return Lists.newArrayList(Splitter.on(',').split(stringCellValue));
} 
Creating User Beans

Next we have a simple method for creating our UserBeans – buildUser

private UserBean buildUser(String name, String password, List<String> acls, List<UserSite> siteUsers) {
    UserBean newUser = new UserBean();
    newUser.setName(name);
    newUser.setPassword(password);
    newUser.getAcls().addAll(acls);
    newUser.getSites().addAll(siteUsers);
    return newUser;
}
Updating users in the system

And now that we have our list of users we can use our RestClient to create them in the system.

public void createUsersFromSpreadsheet(File spreadsheet) throws RestConnectionException {
    loadWorkbook(spreadsheet);
    for (UserBean user : getUsersFromWorkbook()) {
        ClientResponse userPut = restClient.put(user, "/users/"+user.getName());
        if (userPut.getStatus() == 200) {
            System.out.println(String.format("The user: %s was successfully added",user.getName()));
        } else if (userPut.getStatus() == 500){
            ErrorBean error = userPut.getEntity(ErrorBean.class);
            System.out.println(String.format("The user: %s could not be added because %s",user.getName(), error.getMessage()));
        }
    }
}
Of interest here is what happens when there’s a problem.

If you run the ExcelUserManagerRunner more than once you’ll get a message saying that the user already exists. This is where the value of using ClientResponse comes in to play.

We can look at the response status and if we get a 500 (error code) we can try and parse the error into the WCS supplied ErrorBean.

That’s all for now but there are many things you could do to extend this project – for example:

POI can write Excel files as well as read them so perhaps you could create an output function as well
Perhaps you could look at storing other WebCenter Sites resources in the spreadsheet – assets for example. This could give you a good way to manage test data as part of your WCS development process.   

https://manifesto.co.uk/using-webcenter-sites-rest-api-part-2/