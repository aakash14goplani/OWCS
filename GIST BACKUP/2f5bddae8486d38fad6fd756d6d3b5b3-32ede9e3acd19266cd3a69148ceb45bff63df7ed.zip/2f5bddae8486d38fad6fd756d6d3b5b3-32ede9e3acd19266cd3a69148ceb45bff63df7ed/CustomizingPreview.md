# Customizing the Preview

Content Server has a preview feature that, you may know, open the door to InSite.
It is actually an application to visually edit and compose pages.

It is a  very interesting although... I do not use it too much :) In my experience,  users want  from a CMS they just have to add the content, then the site is built more or less automatically.

So, in a large number of case I do no not use "InSite"; also following a best practice, I have a single layout. In this case,  the whole preview window is redundant, and some users complains about it. Furthermore, it is sometimes annoying and confusing: often you forget to apply the default template to your assets, and you have to select template and wrapper to use. Users just wants to preview a page and see the end result.

Luckily, you can easily change the preview window. The key is the property xcelerate.previewurlpagename in futuretense_xcel.ini. Changing this property allows  to call your own code to render the page. Let's do an example (real world code can be a bit more complex than this...).

### Simplifying the preview window

I am showing here custom code to create a simplified preview window: when you click on the preview button, you will see directly the rendered page, with applied the standard  layout and without any intermediate frame.

Note that this trick has many limitations and requires that a number of conditions are met (you are basically crippling Fatwire to remove unwanted features):

1. first, your users are not requiring InSite, so all the web pages are rendered starting from a single layout
2. second, you don't need to preview the site in different dates
3. third, you have a single site in your content server (although this limitation can be easily overcome).
4. fourth, you are allowed to change the file futuretense_xcel.ini or you can ask your system administrator to do so.

So let's write our  "simple previewer". I will write the example referring to "FatPhone", my open source iPhone website for FatWire, but it can be applied to any site with straightforward modifications.

First step: you have to create a CSElement named fpSimplePreview with this code:

```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ taglib prefix="publication" uri="futuretense_cs/publication.tld"
%><cs:ftcs>
<publication:load
  name="theSite"
  objectid='<%=ics.GetVar("pubid")%>'/>
<publication:get
   name="theSite"
   field="name"
   output="site"/>
<render:calltemplate
   ttype='CSElement'
   tname='/fpLayout'
   tid='<%= ics.GetVar("eid") %>'
   site='<%= ics.GetVar("site") %>'
   c='<%=ics.GetVar("AssetType") %>'
   cid='<%=ics.GetVar("id") %>'
   slotname='layout'>
</render:calltemplate>
</cs:ftcs>
```

A couple of notes to this code: basically it is just a simple `call:template` to render the asset you are to previewing with a specific (fixed) layout.

Getting the publication name

In the call before, the only difficult part is retrieving the publication name, since the preview windows gets called with the publication id. We have "almost" all the parameters: the AssetType and his id (mapped as c and cid), but we do not have the site name, but only his numeric id; call:template instead requires the site name.

Luckily you can get the site name from his id using  "publication" tags.

Note that those tags are, as far as I know, undocumented, although you can see his usage a lot if you give a look to the internals of Content Server (there  are many others undocumented tags hidden around) , and his usage is straightforward and consistent with the other (documented) tags.

Nonetheless, using the `publication:load`/`publication:get` is the fastest way to get the name of the site.

### Extending for different sites and layout

The `call:template` before is just an example. If you have also a wrapper page you will have to add the "wrapperpage" attribute. Also, if you have more than one site, with different layouts, you will have to change the code and decode the name of the template from the name of the site.

Best practices are using a layout with a different site prefix for each site. For example in a CS with FirstSiteII and FatPhone, you will have "FSIILayout" and "fpLayout"

However, my code ha no hint of what the site prefix is, so you may have to add code like this:

```jsp
<%
   if(site.equals("FatPhone") layout="/fpLayout";
  else if(site.equals("FistSiteII")) layout ="/FSIILayout";
  else ...
 %>
```
### Configuring SiteEntry

Second step: create a Site Entry. Now you have a CSElement doing the preview, that is not by default accessible in any way from the outside. But since the previewer gets called as a full page window  you have to create a SiteEntry; see below:



Remember to make it uncached.

Third step is changing in futuretense_xcel.ini the property and restart content server.

`xcelerate.previewurlpagename=fpSimplePreview`

Now, if you did all the steps correctly, clicking on the preview link will simply open the asset with the given, fixed template.

Some users will be then happy they do not have any more to see a frame, then select the template and the wrapper page . And stop complaining.