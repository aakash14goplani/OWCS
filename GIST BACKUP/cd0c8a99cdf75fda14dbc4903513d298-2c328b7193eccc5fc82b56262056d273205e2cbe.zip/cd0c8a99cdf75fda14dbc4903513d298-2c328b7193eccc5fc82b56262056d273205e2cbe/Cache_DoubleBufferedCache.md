# CACHING:

Caching is one of the most powerful techniques of Fatwire. An efficient caching system improves the performance of the overall system performance, by reducing the un-necessary overload to the Content server, and as well as the web server.

1. The Content server caches the pages that available in the CS system.

2. The Co-Resident Satellite server provides a second level of caching for the CS.

3. The Remote Satellite server provides another level of caching, so that the content can be closer to the intended audience.

# Double – Buffered Caching:

When assets are updated and published, the Content Server and Satellite Server caches are automatically flushed and updated in the following order:

* Content providers publish updated assets to the delivery system. CacheManager checks the cache tracking tables to see which cached items are affected by the updatedassets.

* CacheManager flushes the outdated Pages from the Content Server cache, then reloads the Content Server cache with the updated Pages.

* CacheManager flushes the outdated items from the Satellite Server cache. As visitors come to the web site and request a page P1, the Satellite Server searches to see if page P1 is in its cache. Because P1 is not in the Satellite Server cache, the request is passed
on to Content Server.

* The Satellite Server system’s cache is filled with an updated version of page P1, taken from the Content Server cache. The updated page is served to the requestors. If pageP1 were requested again, the page would be served from the Satellite Server cache.

### References

[kksays](https://kksays.wordpress.com/2012/01/19/caching-and-double-buffered-caching-in-fatwire/)