[What is lucence search all about?](https://docs.oracle.com/cd/E29542_01/doc.1111/e29636/asset_type_search.htm#WBCSA949)   

### General Steps to follow   

1. [Setting Up Search Indices](https://docs.oracle.com/cd/E29542_01/doc.1111/e29636/asset_type_search.htm#WBCSA953)
2. Write a code to get value for which lucence search is to be performed
3. Write a code that Queries the Search Index   

**Get value for which lucence search is to be performed**   
```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ taglib prefix="satellite" uri="futuretense_cs/satellite.tld"
%><%@ page import="COM.FutureTense.Interfaces.*"
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if>
	<html>
		<head>
			<title>LUCENCE SEARCH</title>
			<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
			<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
			<script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
		</head>
		<body>
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<h1 class="text-center">LUCENCE SEARCH</h1>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<satellite:form name="lucence_form">
							<input type="hidden" name="pagename" value="LucenceAPI"/>
							<table class="table table-hover table-responsive">
								<tr>
									<th>Site</th>
									<td>
										<select name="selected_site" id="selected_site" required>
											<option value="">Select Site</option>
											<ics:sql table="Publication" listname="siteList" sql="select name from Publication" />
											<ics:if condition='<%=null!=ics.GetList("siteList") && ics.GetList("siteList").hasData() %>'>
												<ics:then>
													<ics:listloop listname="siteList">
														<ics:listget fieldname="name" listname="siteList" output="siteName"/>
														<option value='<%=ics.GetVar("siteName")%>'><%=ics.GetVar("siteName")%></option>
													</ics:listloop>
												</ics:then>
											</ics:if>
										</select>
									</td>
								</tr>
								<tr>
									<th>Asset Type</th>
									<td>
										<select name="selected_assetType" id="selected_assetType" required>
											<option value="">Select Asset Type</option>
											<ics:sql table="Publication,AssetPublication" listname="assetTypeList" sql="select distinct site.name, asset.assettype from Publication site, AssetPublication asset where site.id=asset.pubid" />
											<ics:if condition='<%=null!=ics.GetList("assetTypeList") && ics.GetList("assetTypeList").hasData() %>'>
												<ics:then>
													<ics:listloop listname="assetTypeList">
														<ics:listget fieldname="name" listname="assetTypeList" output="site_name"/>
														<ics:listget fieldname="assettype" listname="assetTypeList" output="asset_type"/>
														<option data-parent='<%=ics.GetVar("site_name")%>' value='<%=ics.GetVar("asset_type")%>'><%=ics.GetVar("asset_type")%></option>
													</ics:listloop>
												</ics:then>
											</ics:if>
										</select>
									</td>
								</tr>
								<tr>
									<th>Asset Name</th>
									<td><input type="text" name="asset_name" placeholder="Enter Asset Name"/></td>
								</tr>
								<tr>
									<th>Description</th>
									<td><input type="text" name="asset_description" placeholder="Some Description"/></td>
								</tr>
								<tr>
									<th>Tags</th>
									<td><input type="text" name="asset_tag" placeholder="Comma seperated values"/></td>
								</tr>
								<tr>
									<th>Id</th>
									<td><input type="text" name="asset_id" placeholder="Enter Asset Id" /></td>
								</tr>
								<tr>
									<th>Author</th>
									<td>
										<select name="selected_author" id="selected_author">
											<option value="">Created By</option>
											<ics:sql table="SystemUsers" listname="userList" sql="select username from SystemUsers" />
											<ics:if condition='<%=null!=ics.GetList("userList") && ics.GetList("userList").hasData() %>'>
												<ics:then>
													<ics:listloop listname="userList">
														<ics:listget fieldname="username" listname="userList" output="userName"/>
														<option id="userName" value='<%=ics.GetVar("userName")%>'><%=ics.GetVar("userName")%></option>
													</ics:listloop>
												</ics:then>
											</ics:if>
										</select>
									</td>
								</tr>
								<tr>
									<th>Modified</th>
									<td>
										From : <input type="date" name="from_date"><br/>
										To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type="date" name="to_date">
									</td>
								</tr>
								<tr>
									<td><input type="reset" value="CLEAR"></td>
									<td><input type="submit" value="SUBMIT"></td>
								</tr>
							</table>
						</satellite:form>
					</div>
				</div>
			</div>
			<script>
				$('#selected_site').change(function() {
				   var parent = $(this).val();
				   $('#selected_assetType').children().each(function() {
				      if($(this).data('parent') != parent) {
				      	$(this).hide();
				      }
				      else{
				      	$(this).show();
				      }
				   });
				});				
			</script>
		</body>
	</html>
</cs:ftcs>
```