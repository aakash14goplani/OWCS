In this section, we examine how templates need to be instrumented to allow editorial users to edit content or create content in the context of their website, instead of using the standard content forms.   

**To make this field editable in-context, add the following taglib directive:**   

`<@ taglib prefix="insite" uri="futuretense_cs/insite.tld" %>`   


### String Fields

```jsp
<%-- METHOD-1 : code for flex assets --%>
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="titleList" attribute="practice_title" typename="WebContent_A"/>
<%-- regular exp. to accept only alphabets with spaces in-between them --%>
<h1><insite:edit field="practice_title" list="titleList" column="value" params="{width: '300px', regExp: '[a-zA-Z][a-zA-Z ]+[a-zA-Z]$', invalidMessage: 'only alphabets allowed'}" /></h1>

<%-- METHOD-2 : code for basic assets --%>
<asset:load name="loadImageAsset" type='<%=ics.GetVar("c") %>' objectid='<%=ics.GetVar("cid") %>'/>
<asset:scatter name="loadImageAsset" prefix="image"/>
<ics:getvar name="image:width" output="imageWidth"/>
<insite:edit field="width" value='<%=ics.GetVar("imageWidth")%>' params="{noValueIndicator: '[ Enter width ]', width: '300px', regExp: '[0-9 ]+', invalidMessage: 'only numbers allowed'}"/>
```

### Multivalued Fields

   * When dealing with multivalued fields, beyond editing the existing values, editors need to access more features such as:
      + adding a new value
      + removing an existing value
      + reordering existing values

```jsp
<%-- METHOD-1 : code includes adding, removing, and reordering values --%>
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="IdList" attribute="practice_id" typename="WebContent_A"/>
<insite:list field="practice_id" assetid='<%=ics.GetVar("cid")%>' assettype='<%=ics.GetVar("c")%>'>
  <ics:listloop listname="IdList">
    <insite:edit list="IdList" column="value" params="{noValueIndicator: '[ Enter id here ]'}"/> <br/>
  </ics:listloop>
</insite:list>

<%-- METHOD-2 : code just enables to edit every text list --%>
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="IdList" attribute="practice_id" typename="WebContent_A"/>
<ics:listloop listname="IdList">
   <ics:listget listname="IdList" fieldname="#curRow" output="currentRowNb" />
   <insite:edit assetid='<%=ics.GetVar("cid")%>' assettype='<%=ics.GetVar("c")%>' field="practice_id" list="IdList" column="value" index='<%=ics.GetVar("currentRowNb")%>' />
  </ics:listloop>
```

### Text Fields   
(i.e. fields with data type **`text`** or editor: **ckeditor**)

```jsp
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="bodyTextList" attribute="body_text" typename="WebContent_A"/>
<ics:listget listname="bodyTextList" fieldname="value" output="BodyText" />
<h3><insite:edit field="body_text" variable="BodyText" editor="ckeditor" params="{noValueIndicator: '[ Enter body here ]', width: '100%'}" /></h3>
```

### Number Fields 
(i.e. fields with data type **`money`** or **`int|float|double`**)

```jsp
<%-- METHOD-1 --%>
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="priceList" attribute="practice_price" typename="WebContent_A"/>
<%-- constraints : digits should have fractions and max limit should be equal to or less than 10000.00 --%>
<h3><insite:edit field="practice_price" list="priceList" column="value" params="{constraints: {fractional: true, max: 10000.00}, invalidMessage: 'Price must include cents'}" /></h3>
  
<%-- METHOD-2 --%>
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="priceList" attribute="practice_price" typename="WebContent_A"/>
<ics:listget fieldname="value" listname="priceList" output="price"/>
<currency:create name="curname" isocurrency="INR" separator="dot"/> <%-- seperator = comma|dot|default --%>
<currency:getcurrency varname='curout' name="curname" value="price"/>  
<insite:edit field="practice_price" value='<%=ics.GetVar("curout")%>' params="{noValueIndicator: '[ Enter price here ]',currency:'INR'}"/>

<%-- METHOD-3 --%>
NOTE : Include -> <%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="priceList" attribute="practice_price" typename="WebContent_A"/>
<ics:listget fieldname="value" listname="priceList" output="price"/>
<fmt:formatNumber type="currency" value='<%=ics.GetVar("price")%>' var="formattedValue" currencySymbol="&inr;" /> 
The price is: <insite:edit field="practice_price" value="${formattedValue}" params="{noValueIndicator: '[ Enter price here fmt ]', currency: 'INR'}" />
```

### Date Field   
(i.e. field with data type **`date`**)  

Date fields are made editable in-context using the same `insite:edit` tag used for string or text fields. However, when dates need to be formatted, a few extra steps are required. The value of date fields when initially retrieved from the database is in JDBC format, which is,  `2012-01-01 00:00:00.0`. This format is unsuitable for rendering on a website where dates are generally rendered as a readable string, such as `January 1, 2012`.   

In addition, the date is interpreted in the server's time zone, which we can display in a different time zone. We first get the time zone ID by using the `java.util` TimeZone API. We then format the date by using the "long" date format (which is a predefined format).   

```jsp
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="dateList" attribute="practice_date" typename="WebContent_A"/>
<ics:listget fieldname="value" listname="dateList" output="postDate"/>
<dateformat:create name="df" datestyle="long" timestyle="long" timezoneid="IST"/>
<%-- for timestamp use getdatetime else use getdate --%>
<dateformat:getdatetime name="df" varname="formattedDate" valuetype="jdbcdate" value='<%=ics.GetVar("postDate") %>' />
<h3><insite:edit field="practice_date" value='<%=ics.GetVar("formattedDate") %>' params="{constraints:{formatLength: 'long'}, timePicker:true, timeZoneID:'IST'}"/></h3>
```

### Binary Field   
(i.e. field with data type **`blob`**)   

Binary fields are typically database `BLOB` or `CLOB` fields. Binary fields typically store images, or downloadable documents. By default, the `insite:edit` tag will make binary fields editable through a file upload component.   

In order to make this field editable in-context, we first need to retrieve the value of this field, which contains a `BLOB ID` (not the actual `BLOB value`)

_Case 1_: If blob field is from a flex family   

```jsp
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="imageList" attribute="practice_image" typename="WebContent_A"/>
<render:getbloburl outstr="imageURL" c='<%=ics.GetVar("c")%>' cid='<%=ics.GetVar("cid")%>' field="practice_image"/>
<insite:edit field="practice_image" assetid='<%=ics.GetVar("cid")%>' assettype='<%=ics.GetVar("c")%>' list="imageList" column="value" >
  <img src='<%=ics.GetVar("imageURL")%>' />
</insite:edit>
```   

_Case 2_: If blob field is from a basic asset   

When we try to work with basic assets that has blob fields using above code (mentioned in _Case 1_) we get error message as:   
> [ERROR] [.kernel.Default (self-tuning)'] [com.fatwire.logging.cs] com.fatwire.insite.exceptions.InsiteException: com.fatwire.insite.exceptions.UnsupportedAttributeTypeException: No default editor for attribute of type url   

This is because we don't have `BLOB ID` generated for basic assets.   

Note that passing the `BLOB ID` to the `insite:edit` tag is primarily used to determine whether the binary field is empty or not. If empty, the `insite:edit` tag shows a default empty value indicator.

The `<img>` tag should be the only HTML tad inside the `insite:edit` tag. The `<img>` tag is the only tag permitted inside the `inside:edit` tag. The `insite:edit` tag can also handle `<a>` tags (normally used when building hyperlinks to downloadable documents). Other types of binaries may be handled but might require specific customizing.

When hovering over the image, content contributors are now shown a tooltip, giving access to the upload component, and allowed to clear the largeThumbnail field.

```xml
<PROPERTY NAME="urlpicture" DESCRIPTION="Image File">
  <STORAGE TYPE="VARCHAR" LENGTH="255"/>
  <INPUTFORM TYPE="UPLOAD" WIDTH="36" REQUIRED="YES" LINKTEXT="Image"/>
</PROPERTY>
```
```jsp
<insite:edit field="urlpicture" variable="image_url" assetid='<%=ics.GetVar("cid") %>' assettype='<%=ics.GetVar("c") %>' editor="upload">
			Image : <img src='<%=imageURL%>' alt="<%=imageAltName%>" width="<%=imageWidth%>" height="<%=imageHeight%>" />
</insite:edit>
```   

The thing to note is - we need to attach an **editor="upload"** to insite tag.   

### ASSET fields

```jsp
<assetset:setasset name="loadPracticeAsset" type='<%=ics.GetVar("c")%>' id='<%=ics.GetVar("cid")%>'/>	
<assetset:getattributevalues name="loadPracticeAsset" listvarname="assetList" attribute="practice_assets" typename="WebContent_A"/>
<insite:slotlist field="practice_assets" slotname='<%=ics.GetVar("cid") + ":AssetDropzone" %>'>
    <ics:listloop listname="assetList">
      <ics:listget listname="assetList" fieldname="value" output="Id" />
      <asset:load name="loadCurrentAsset" type="WebContent_C" objectid='<%=ics.GetVar("Id")%>'/>
      <asset:get name="loadCurrentAsset" field="template" output="templateName" />
      <insite:calltemplate tname='<%=ics.GetVar("templateName")%>' c="WebContent_C" cid='<%=ics.GetVar("Id")%>' />
    </ics:listloop>
</insite:slotlist>
```   

### Editing an Association

When using an asset association instead of a flex attribute of data type asset, the `field` attribute needs to be specified as follows:   

`Association-named:<associationName>`   
For example, for an association called "topStory" the code would be:   

```jsp
<insite:calltemplate 
  field="Association-named:topStory"
  ...
/>
```   

### Editing a Parent Asset

It is also possible to edit a flex asset's parent asset. The syntax for the `field` attribute is as follows:   

`Group_<parentDefinitionName>`
For example, in the case of avisports, article assets have a "Category" parent definition:   

```jsp
<insite:calltemplate
  field="Group_Category"
  ...
/>
```

### References   

1. [Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_siteassets.htm#WBCSD1928)
2. [Fatwiredev Blog](https://fatwiredev.blogspot.in/2013/11/example-9-in-context-content-editing.html)
3. [insite:edit](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/insite-edit.html)
4. [insite:list](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/insite-list.html)
5. [insite:calltemplate](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/insite-calltemplate.html)
6. [insite:slotlist](https://docs.oracle.com/cd/E72987_01/wcs/tag-ref/JSP/insite-slotlist.html)