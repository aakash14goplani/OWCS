### General Steps to follow

1. Click on **Admin** tab.
2. Under `Site`, click on **List all sites**.
3. Select a site for which you want to enable start menu.
4. Click on **Enable Asset Types**
5. Check the asset type that you want in your start menu.
6. Click on **Enable Asset Type**
7. Check the options as per need.
8. Click on **Enable Asset Type**  

OR  

After step 3.  

4. Click on **List all Start Menu items for this site**
5. Click on **Add new start menu**
6. Fill in the required details and click on **Save**

### References

* [Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29636/managingaccess.htm#WBCSA410)