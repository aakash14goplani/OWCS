### Types of Database Tables

There are five different types of tables in the Content Server database:

1. **Object Tables**   
These tables hold the data as objects and provide a unique identifier for each row in the table. Object tables store data as an object and can be represented in hierarchies. The primary key for object tables is always the ID (id) column and that cannot be changed. When we add an object table, it creates an ID column automatically in that table.

2. **Tree Tables**   
These tables hold the hierarchical information about relationships between objects in object table, i.e., the object tables can be represented in hierarchies, but the hierarchy itself is stored in a tree table — the hierarchy is the tree.
The examples of tree tables are:
   * AssetRelationTree
   * SitePlanTree

3. **Content Tables**   
Content tables store data as flat data (rather than as objects) and that information cannot be organized in a hierarchy. You use content tables for simple lookup tables. The CS doesn’t provide a unique identifier for the rows in the table.

4. **Foreign Tables**   
A foreign table is one that Content Server does not completely manage. These can be the tables which can be:
   – Tables that are outside of the Content Server database but that Content Server has access to.
   – Tables that are in the Content Server database but that Content Server did not create.
Content Server can query foreign tables and cache the resultsets just as it does for its own object and content tables.

5. **System Tables**   
These are core Content Server application tables. The schema of these tables cannot be modified, i.e., these are the Content Server tables whose schema is fixed. You can add rows to some of the system tables (say using the Content Server Explorer tool or using some other way), but you cannot add or modify the columns in these tables in any way. Also, we cannot add system tables to the database.
The examples of System Tables are:
   + ElementCatalog
   + SiteCatalog
   + SystemACL
   + SystemInfo
   + SystemPageCache
   + SystemUsers .. etc…

### How to know the Table’s Type:

We can identify the type of any table using the SystemInfo table. The system table is the one that lists all the tables in the database.

Following are the steps to identify the Table’s type:

1. Open the Content Server Explorer and log in to the Content Server database.
2. Open the SystemInfo table.
3. Examine the systable column. The value in this column identifies the type of table represented in the row.

Here are the codes for identifying the tables:

1. YES = System table
2. NO = Content table
3. OBJ = Object table
4. TREE = Tree table
5. FGN = Foreign table

### Tables that store sites information when a site is created in Oracle WebCenter Sites 11g / Fatwire

In Oracle WebCenter Sites, when we create a site, few tables will be created by the Content Server.  These tables will be used by the CS to write information about the sites that are created in the system. Following are the tables that will be created.

1. **Publication Table:**   
This table is used by the CS to store all the info related to the sites that are created in your system. This holds the information like NAME, DESCRIPTION, PUBLICATION ID of the site. Each row in this table resembles a site in your system, and its information.

2. **PublicationTree Table:**   
This table is used by the CS to store the information about the asset types that are enabled for your site.  It stores the information about the different asset types that you have created  / shared from other sites in your system.

3. **SitePlanTree Table:**   
This table stores information about the hierarchical structure of a site and its page assets. This table lists sites and page assets. We can code your CSElements to extract and display information from the SitePlanTree table

There will be a top level node (Page), which will have the rest of the pages placed below it.

The SitePlan in the Admin console of WCS resembles this table in database.

### References

[kksays](https://kksays.wordpress.com/2012/12/05/database-tables-in-fatwire-oracle-webcenter-sites/)   
[kksays](https://kksays.wordpress.com/2013/08/26/tables-that-store-sites-information-when-a-site-is-created-in-oracle-webcenter-sites-11g-fatwire/)
[Developers Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/data_csdatabase.htm#WBCSD1420)