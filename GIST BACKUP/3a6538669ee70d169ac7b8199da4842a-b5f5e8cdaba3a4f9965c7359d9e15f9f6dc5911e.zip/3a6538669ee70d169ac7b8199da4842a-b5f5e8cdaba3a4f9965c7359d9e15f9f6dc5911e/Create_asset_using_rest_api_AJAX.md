```java
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ page import="com.fatwire.wem.sso.*"
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if><% 
	
	SSOSession ssoSession = null;
	String multiticket = null;
	try {
		ssoSession = SSO.getSSOSession();
		multiticket = ssoSession.getMultiTicket("fwadmin", "xceladmin");
	} catch (SSOException e) {
		e.printStackTrace();
	}
	
	%><button id="createAsset">Create Asset</button><br><br>
	<button id="deleteAsset">Delete Asset</button><br><br>
	<button id="getAsset">Get Asset</button><br><br>
	<button id="updateAsset">Update Asset</button><br><br>
	
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script>
		var ticket = "<%=multiticket%>";
		
		$("#createAsset").on('click', function() {
			var parser = new DOMParser();
			var text = '<ns2:assetBean xmlns:ns2="http://www.fatwire.com/schema/rest/1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.fatwire.com/schema/rest/1.0 http://localhost:9080/cs/schema/rest-api.xsd"><name>REST_API_ASSET</name><publist>ABC</publist><subtype>REST_API</subtype><attribute><name>insert_title</name><data><stringValue>test blob contents</stringValue></data></attribute><attribute><name>template</name><data><stringValue>/AssetAPI</stringValue></data></attribute></ns2:assetBean>';
			var xmlText = parser.parseFromString(text,"text/xml");
		    
		    $.ajax({
		    	type: "POST",
		    	dataType: "xml",
		    	contentType: "application/xml",
		    	data: xmlText,
		    	processData: false,
		    	headers: {'X-CSRF-Token': ticket},
		        url: "http://localhost:9080/cs/REST/sites/ABC/types/Widget_C/assets?multiticket=" + ticket,
		    	success: function(data) {
		    		console.log("Asset Created Successfully!" , data);
		    	},
		    	error: function(XMLHttpRequest, textStatus, errorThrown) {
		    		console.log("Status: " + textStatus + ", Error: " + errorThrown);
		    	}
		    });
		});
		
		$("#deleteAsset").on('click', function() {
			var assetId = "1374098813024";
			$.ajax({
		    	type: "DELETE",
		    	headers: {'X-CSRF-Token': ticket},
		        url: "http://localhost:9080/cs/REST/sites/ABC/types/Widget_C/assets/" + assetId + "?multiticket=" + ticket,
		    	success: function() {
		    		console.log("Asset deleted Successfully!");
		    	},
		    	error: function(XMLHttpRequest, textStatus, errorThrown) {
		    		console.log("Status: " + textStatus + ", Error: " + errorThrown);
		    	}
		    });
		});
		
		$("#getAsset").on('click', function() {
			var assetId = "1374098790808";
			$.ajax({
		    	type: "GET",
		    	headers: {'Accept': 'application/json','X-CSRF-Token': ticket},
		        url: "http://localhost:9080/cs/REST/sites/ABC/types/Widget_C/assets/" + assetId + "?multiticket=" + ticket,
		    	success: function(data) {
		    		console.log("Asset details Successfully!" , data);
		    	},
		    	error: function(XMLHttpRequest, textStatus, errorThrown) {
		    		console.log("Status: " + textStatus + ", Error: " + errorThrown);
		    	}
		    });
		});
		
		$("#updateAsset").on('click', function() {
			var assetId = "1374098790808";
			var parser = new DOMParser();
			var text = '<ns2:assetBean xmlns:ns2="http://www.fatwire.com/schema/rest/1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.fatwire.com/schema/rest/1.0 http://localhost:9080/cs/schema/rest-api.xsd"><publist>ABC</publist><subtype>NavigationLink</subtype><attribute><name>link_text</name><data><stringValue>AakashGoplani</stringValue></data></attribute></ns2:assetBean>';
			var xmlText = parser.parseFromString(text,"text/xml");
		    
		    $.ajax({
		    	type: "PUT",
		    	dataType: "xml",
		    	contentType: "application/xml",
		    	data: xmlText,
		    	processData: false,
		    	headers: {'X-CSRF-Token': ticket},
		        url: "http://localhost:9080/cs/REST/sites/ABC/types/Widget_C/assets/" + assetId + "?multiticket=" + ticket,
		    	success: function(data) {
		    		console.log("Asset Created Successfully!" , data);
		    	},
		    	error: function(XMLHttpRequest, textStatus, errorThrown) {
		    		console.log("Status: " + textStatus + ", Error: " + errorThrown);
		    	}
		    });
		});
		
		String.prototype.EncodeXMLEscapeChars = function () {
			return this.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
		};
	</script>
</cs:ftcs>
```