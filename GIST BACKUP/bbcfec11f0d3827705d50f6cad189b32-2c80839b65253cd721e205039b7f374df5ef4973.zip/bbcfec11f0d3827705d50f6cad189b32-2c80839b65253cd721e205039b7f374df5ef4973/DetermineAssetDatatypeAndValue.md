```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ page import="COM.FutureTense.Interfaces.*, com.fatwire.assetapi.def.*, java.util.*, com.fatwire.system.*"
%><%
 /******************************************************************************************************************************
   *    Element Name        :  Practice/Automation/DetermineAssetDatatypeAndValue 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (07/07/2018) 
   *    Description         :  This element determines the data type of each attribute of given asset definition. 
   *						   Also outputs value type of each attribute i.e. SINGLE, MULTI etc.
   *    Input Parameters    :  assetType, assetDefinition
   *    Output              :  Datatype map and Value Map
 *****************************************************************************************************************************/
%><cs:ftcs>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if><% 
	
	String assetType = ics.GetVar("assetType"), assetDefinition = ics.GetVar("assetDefinition");
	Session sessionFactory = SessionFactory.getSession();
	AssetTypeDefManager mgr = (AssetTypeDefManager) sessionFactory.getManager( AssetTypeDefManager.class.getName() );
	AssetTypeDef defMgr = null;
	
	if( Utilities.goodString(assetDefinition) ) {
		/* flex asset */
		defMgr = mgr.findByName(assetType, assetDefinition);	
	} else {
		/* basic asset */
		defMgr = mgr.findByName(assetType, "");	
	}
	
	/* values to be considered: asset, date, blob, webreference */
	Map<String, String> valueMap = new HashMap<String, String>();
	valueMap.clear();
	/* possible values: SINGLE, MULTI, MULTI_ORDERED, SINGLEUNIQUE */
	Map<String, String> dataTypeMap = new HashMap<String, String>();
	dataTypeMap.clear();
	
	for( AttributeDef attrDef : defMgr.getAttributeDefs() ) {
		AttributeDefProperties properties = attrDef.getProperties();
		if(null != properties.getValueCount()) {
			valueMap.put(attrDef.getName(), properties.getValueCount().toString());
			dataTypeMap.put(attrDef.getName(), attrDef.getType().toString());
		}
	}
	
	ics.setAttribute("dataTypeMap", dataTypeMap);
	ics.setAttribute("valueMap", valueMap);
	
	ics.RemoveVar("assetType");
	ics.RemoveVar("assetDefinition");
	
%></cs:ftcs>
```