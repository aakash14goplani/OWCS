* Fatwiredev 
  + https://fatwiredev.blogspot.in/2013/07/all-tutorial-links.html
  + https://plus.google.com/+Fatwiredev
  + https://fatwirecustomizations.blogspot.in/
  + https://fatwirecode.blogspot.in/
  + https://gist.github.com/fatwire-dev     

* TomRed
  + https://www.tomred.net/fatwire/   
  
* KKSAYS
  + https://kksays.wordpress.com/category/fatwire/   
  
* Sciabarra
  + http://www.sciabarra.com/fatwire/category/tips-and-trick/   
  
* Devble Website (unfortunately not functional anymore)   

* Miscellaneous
  + http://www.function1.com/tags/fatwire
  + https://mkbansal.wordpress.com/category/technical/cms-technical/oracle-wcs-fatwire/
  + https://manifesto.co.uk/category/fatwire-and-webcenter-sites/
  + http://sites.shishank.info/
  + https://www.linkedin.com/in/tusharwebcentersitestrainer/recent-activity/posts/