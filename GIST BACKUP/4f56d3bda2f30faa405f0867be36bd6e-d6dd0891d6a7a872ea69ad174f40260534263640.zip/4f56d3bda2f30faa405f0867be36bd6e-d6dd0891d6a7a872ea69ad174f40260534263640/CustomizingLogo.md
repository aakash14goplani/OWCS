When installing the Fatwire Instance in the client’s machine, some of the clients insist on replacing the Fatwire logos with their own logos. Then we need to change the logos accordingly. In this article, we are going to learn how to customize the logo in the Log-in page (Both Advanced UI, and WEM UI pages).

The following is the URL: `http://localhost:9080/cas/login` (where my Fatwire instance is running on 9080), where we need to change the fatwire logo to our own logo.

![Fatwire Logo](https://github.com/aakash14goplani/OWCS/blob/master/images/FatwireLogo.jpg)

In this case, we are changing the logo by replacing the images, and not using the property files.

Create your own logo, and paste it in the following location:

`<Fatwire installation directory>\App_Server\apache-tomcat-7.0.14\webapps\cas\fatwire\images\logos`

Now, go to the following location:

`<Fatwire installation directory>\App_Server\apache-tomcat-7.0.14\webapps\cas\fatwire\css`

Backup the file “login.css”. Open “login.css” file, and search for “FatWireBig.png”, and replace the name with your own logo name. If you want to customize for IE6 as well, you need to create a gif file of your logo, and replace “FatWireBig.gif” in login.css file with your gif file.

Done…!!!

Go to `http://localhost:9080/cas/login`.  You can find that your logo has been updated on the site. The same changes will be reflected while opening dash, advanced, and insite interfaces.

To make changes to the WEM UI at `http://localhost:9080/cs/wem/fatwire/wem/Welcome`  also, perform the following changes:

Paste the logo in the following location:

`<Fatwire installation directory>\App_Server\apache-tomcat-7.0.14\webapps\cs\wemresources\images\logos`

Backup “transition.css” file from the following location. Open “transition.css” and search for “FatWireBig.png”, and replace the name with your own logo name. If you want to customize for IE6 as well, you need to create a gif file of your logo, and replace “FatWireBig.gif” in login.css file with your gif file.

`<Fatwire installation directory>\App_Server\apache-tomcat-7.0.14\webapps\cs\wemresources\css\ui`

Done…!!!

Go to `http://localhost:9080/cs/wem/fatwire/wem/Welcome` and see whether your changes are reflected or not

### References

[kksays](https://kksays.wordpress.com/2012/02/15/logo-customizations-for-fatwire-login-page/)