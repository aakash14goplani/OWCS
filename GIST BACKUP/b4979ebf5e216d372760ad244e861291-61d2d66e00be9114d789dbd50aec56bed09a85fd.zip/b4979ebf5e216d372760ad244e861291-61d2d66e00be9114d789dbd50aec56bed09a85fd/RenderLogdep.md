Firstly before learning about this tag, and its significance, make sure that you read about the **Compositional Dependency**.

Compositional dependency is the dependency between the asset and the page in which it is being rendered. These dependencies are automatically logged when we use certain tags like `asset:load`, `assetset` tags, etc.

But, when we don’t those tags in our code, then how will the compositional dependency be logged?

If we don’t use such tags which log automatically dependencies, then it is our duty to log the compositional dependency.

Examples of such scenarios:

**Scenario 1:**

We have a template called SampleTemplate. From that SampleTemplate, I’m going to call a CSElement named SampleElement, to render some things. In such case, I will call the `render:callelement` as follows.

```jsp
// SampleTemplate code goes here
….
<render:callelement name=MySite/Common/SampleElement/>
…..
// SampleTemplate code goes here
```

In the above scenario, how will the compositional dependency between the CSElement asset and the page that it renders will be executed? It won’t be logged, as we haven’t used any `asset:load tags`, etc.

**Scenario 2:**

We are loading an asset using `asset:load`, and then without loading its children assets, we are getting the children’s info using `asset:children`. Under such circumstances, the compositional dependency is not logged between these assets and the page that is rendering these assets.

In both the above scenarios, its our responsibility to log the dependency.

Under such circumstances, the `render:logdep` tag is useful to log the COMPOSITIONAL DEPENDENCIES between the assets and the page that renders the asset.

If it is a CSElement , its syntax would be `<render:logdep cid=”Variables.eid” c=”CSElement”/>`

If it is a Template, its syntax would be `<render:logdep cid=”Variables.tid” c=”Template”/>`

### References

[kksays](https://kksays.wordpress.com/2012/12/18/significance-of-renderlogdep-tag-in-fatwire-oracle-webcenter-sites/)