# When to use Basic Assets

When the data for an asset type can be imagined before the creation, as a simple flat table where each asset of that type is a single record and every record has the same columns, that asset type should use the BASIC ASSET MODEL.

Nowadays Flex Assets are used in a predominant way to build your Fatwire website.   

Basic Assets are however still there, and there are some cases when they should be considered (and use) them.  Here is a couple of examples:

1. **Data Migration:**
   * Basic Assets are more close in their underlying structure to a database table than the Flex Assets. So it is viable to fill them with database queries. It is much more difficult to do so with Flex Assets.
   * For example migrating a large dataset that was not expected to change. It is simpler to create a basic asset and then move data in the generated table than use a flex asset and the Bulk Loader (that is nonetheless available for those tasks, as well).

2. **User Generated Content:**
   * Another case is to store User Generated content: for example, user registration. Instead of building a full feature Flex Asset (using for example the Asset API) it was simpler just to create a plain basic asset and register users creating new instances of that asset.


Is is also faster to create an instance of a Basic Asset than of a Flex Asset, and this can be a winning feature sometimes.


The structure in the database is as follows for the Basic Asset:

* Each basic asset has a database table.
* Each attribute has a field in the table.

The Basic Asset Model is the choice of developers, when the data has the following characteristics:

1. **FIXED / PREDICTABLE ATTRIBUTES:** This means that we know that the data has a fixed number of attributes, and in future, there is no necessity to add new attributes to the data type.
2. **HOMOGENEOUS:** This means that all the assets are of the same type, where all the assets have the same set of attributes.
3. **MODERATE ATTRIBUTES:** There are a very few attributes to the asset.
4. **USE STATIC PUBLISHING MODEL:** There are very rare cases, where the Flex model uses the Static publishing.
5. **NAVIGATION:** Visitors of the site browse your site by navigating through the links, and not automatically driven through their selected options.

### References

* [sciabarra](http://www.sciabarra.com/fatwire/category/tips-and-trick/index.html)
* [kksays](https://kksays.wordpress.com/2012/02/09/when-to-use-the-basic-model-in-fatwire/)