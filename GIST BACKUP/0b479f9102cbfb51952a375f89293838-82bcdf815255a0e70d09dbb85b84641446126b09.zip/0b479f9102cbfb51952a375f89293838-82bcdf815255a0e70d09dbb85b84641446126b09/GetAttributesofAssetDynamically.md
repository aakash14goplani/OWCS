### Get the Attributes of an Asset Dynamically

1. In the example below we are looking for the attributes of asset of type `MyAddressAsset` which has an asset definition called `MyAddressDefinition`.   

2. Create an instance of the `AssetTypeDefManager` called `assetDefManager` and pass it a reference to `ics`. 

3. This allows us to create an instance of `AssetTypeDef` called `assetDef`.   

4. To create an `AssetTypeDef` instance we need to specify the asset type and asset definition.   

5. Using the `getAttributeDefs()` method of the `AssetTypeDef` instance `assetDef`, we retrieve a Java List of all the attributes associate with that asset.

6. This list can then be iterated and the attributes retrieved. In the example below we print the attribute name each on a new line.

```jsp
String fatAssetType = "MyAddressAsset";
String fatAssetDefinition = "MyAddressDefinition";

//Gets instance of the asset definition manager
AssetTypeDefManager assetDefManager = new AssetTypeDefManagerImpl(ics);  
//Gets fatwire asset type by asset name and definition
AssetTypeDef assetDef = assetDefManager.findByName(fatAssetType, fatAssetDefinition); 

List attrDefsList = assetDef.getAttributeDefs();     
         
for (int i=0; i<attrDefsList.size(); i++) {
	AttributeDef def = (AttributeDef)attrDefsList.get(i);
	out.println("<br />" + ics.GetVar(def.getName()));
}
You may notice that some of the common attributes are returned along with the custom attributes of the FatWire asset definition.  These can be filtered out using the isMetaDataAttribute() method of the returned attribute.  The updated for loop is below.

for (int i=0; i<attrDefsList.size(); i++) {
	AttributeDef def = (AttributeDef)attrDefsList.get(i);
	if (!def.isMetaDataAttribute()) { //only show user created attributes
		out.println("<br />" + ics.GetVar(def.getName()));
	}
} 
```