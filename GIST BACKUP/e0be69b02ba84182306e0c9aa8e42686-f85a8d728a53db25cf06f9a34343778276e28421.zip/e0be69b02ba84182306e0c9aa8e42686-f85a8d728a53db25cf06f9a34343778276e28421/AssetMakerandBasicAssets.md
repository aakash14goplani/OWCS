# AssetMaker and Basic Assets

### Basic Assets

Xcelerate provides some built-in asset (an absolute requirement to build a site). However, since WCS  has a rich and flexible type system, you can define your own assets. Well, you actually should, unless you stick using sample assets, but you would lose a good deal of flexibility.   


There is a lot to say about all the available possibilities to define your assets. For now, we limit the exploration to the features  provided by Xcelerate, namely the Basic Assets.   

### Define a new Basic Asset with AssetMaker

Let's jump start on Basic Asset showing an example how you can define it.   


Although a bit technical as a approach (this is one of Basic Assets's drawback) you have to describe it creating an XML file.   


A very simple example of a Basic Asset descriptor looks like this:

```xml
<ASSET NAME="Simple" DESCRIPTION="Simple"  PROCESSOR="5.0"
       DEFDIR="c:\Fatwire\Shared\Storage\Simple">
  <PROPERTIES>
    <PROPERTY NAME="value" DESCRIPTION="Value">
        <STORAGE TYPE="VARCHAR" LENGTH="80"/>
        <INPUTFORM TYPE="TEXT" WIDTH="50"
          MAXLENGTH="80" REQUIRED="NO" DEFAULT="" MULTIPLE="NO"/>
    </PROPERTY>
  </PROPERTIES>
</ASSET>
```

### What a basic asset provide

It is a simple asset, maybe the simplest possible, but this example demonstrates what an Asset can provide.

First, as asset, like a database table, is essentially a sequence of fields, here called properties. As you can see here, each property has a storage type, so basically properties are translated in fields of a database table.   


But you can also note an important difference from database table: for each field, it is declared  how the field will be edited. In this example, you simply use a simple input text form, but with some constraints:
   * width 50 characters,
   * up to a maximum of 80,
   * the property is not required,
   * default value  is a void string.


It is however also pretty simple declare a property of type blob, that will generate a form with a file upload. The file, once uploaded, will be stored in a folder. Tables may have attachments, here we define the folder where attachments will be stored, and thus this information is mandatory.   

Please note that Basic Assets have however some limitation. Most notably:
   * they require coding to be defined
   * they are a bit inflexible so you cannot add fields later unless you manually alter database tables
   * they have limited relationship (actually provided by a feature called Association) 