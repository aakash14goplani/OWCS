If you are working on Oracle webcenter Sites application to develop your custom application or need to use a table which holds your business data apart form the assets/webcenter sites system data. Creating custom table in webcenter sites database by following the below steps.

### ORACLE WEBCENTER SITES DATABASE
Webcenter Sites can not access a custom table directly. The custom table should be registered to the webcenter sites databse.

**SYSTEMINFO** table holds the list of tables which are registered to the webcenter sites. So we need to register our custom table in SYSTEMINFO table after creating it. **SYSTEMINFO** table only holds the name of the table. It doesn’t holds the tables columns, structure, data. We can modify the custom table any time and don’t need to update teh **SYSTEMINFO** table. Registering a table into Oracle Webcenter Sites database is one time job.

### CREATING TABLE IN WEBCENTER SITES DATABASE
Oracle Webcenter Sites provides a tool for database transactions like querying, creating, modifying & registering tables. Below animated gif will show you creating table in webcenter sites database.

1. Login into Webcenter Sites
2. Go to Admin interface
3. Click on the Admin tab in the left side navigations.
4. Scroll to the bottom, and click on Management Tools and click on Sites Database.
5. Check Add table and click on OK button
6. Provide the tablename, Table Type, Directory, ACLs & finally the field names & their types. Make sure you have create a column with name “id“. It is mandatory.
7. Click OK.

Now you have create a table successfully.

The main advantage of using the Sites Database tool is, it creates a table & registers the table into **SYSTEMINFO** table automatically. So we don’t need to register the table manually.

### SEARCHING FOR A TABLE
Lets search for the newly created table to make sure it is created properly.

1. Login into Webcenter Sites
2. Go to Admin interface
3. Click on the Admin tab in the left side navigations.
4. Scroll to the bottom, and click on Management Tools and click on Sites Database.
5. Provide the table name and check Modify Table and click on OK button
6. The page will show you the list of tables which matches to the name you specified.
7. Click on the table we created in above steps.
8. It will show you the name, directory & ACLs data. You can alter the table like changing/adding the fields and their types.