### General Steps to follow

1. Click on **Admin** tab   

2. Click on **Add new Flex Family**   

3. Enter all required fields
   ```
   Naming Conventions to be followed (Not compulsory but used oftenly)
   Flex Family to be created : Car 
   Flex Attribute: Car_A	
   Flex Parent Definition: Car_PD	
   Flex Definition:	Car_CD or Car_D
   Flex Parent:	Car_P
   Flex Asset: Car_C	
   Flex Filter:	Car_F
   ```
   
4. Click on **Continue**   

5. Enter all required fields
   ```
   Example:   
   Flex Attribute:	Content_A
   *Description: Content Attribute
   *Plural Form: Content Attributes
   ```
6. Click on **Add New Flex Family**   

7. Enable the newly created flex family in start menu of your website   

8. In the **Admin** tab, click on **New** then click on **New Practice Attribute** (as per our example, in general it will be New Flex_Family_Name Attribute)   
   + Enter **Name** of Attribute. (e.g. title)
   + Enter **Description** for Attribute. (e.g. Please Enter Som Title for the Asset)
   + Enter **Attribute Type** for the required attribute. Available options in the dropdown are: asset (creates a drop zone that allows to drag and drop assets of other families and Complex/Basic assets), blob, date , float, int, money, string, text.   
   + **Number of Values**: _single_ or _multiple_
   + **Attribute Editor**: If you want your attribute to have the Attribute Type other than the ones mentioned in the dropdown field, you can create your personal attribute types (like checkbox, radio, dropdown etc) using Attribute Editors and assign it to your attribute.
   + Click on **Save**   
   
9. In the **Admin** tab, click on **New** then click on **New Practice Parent Definition** (as per our example, in general it will be New Flex_Family_Name Parent Definition)   
   + Enter **Name** of Parent Definition. (e.g. car_parent_definition)
   + Enter **Description** for Parent Definition. (e.g. Parent Definition for Car)
   + Select the **Attributes** you need to appear in Parent Definition (the one which will be inherited) . You can select them as _optional_ or _required_ attributes and also can rearrange the order of attributes.
   + Click on **Save**   
  
10. In the **Admin** tab, click on **New** then click on **New Practice Content Definition** (as per our example, in general it will be New Flex_Family_Name Content Definition | Definition)
   + Enter **Name** of Content Definition. (e.g. car_content_definition)
   + Enter **Description** for Content Definition. (e.g. Content Definition for Car)
   + Select the **Attributes** you need to appear in Content Definition (the one which will be displayed while creating assets to content editors) . You can select them as _optional_ or _required_ attributes and also can rearrange the order of attributes.
   + Click on **Save**   
  
11. In the **Contributor** tab, click on **New** then click on **New Practice Parent** (as per our example, in general it will be New Flex_Family_Name Parent)
   + Enter **Name** of Parent. (e.g. car_parent)
   + From the dropdown select any of the parent that you want to work on
   + Enter values for the attribute.
   + Click on **Save**    
  
12. In the **Contributor** tab, click on **New** then click on **New Practice Asset** (as per our example, in general it will be New Flex_Family_Name Asset)
   + Enter **Name** of Asset. (e.g. car_asset)
   + From the dropdown select any of the Content Definition that you want to work on
   + Enter values for the attribute.
   + Click on **Save** 

### References

* [Designing Flex Asset Types](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/data_designflextype.htm#WBCSD1574)
* [Creating a Hierarchical Flex Family](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/flex_asset_tutorial.htm#WBCSD2457)