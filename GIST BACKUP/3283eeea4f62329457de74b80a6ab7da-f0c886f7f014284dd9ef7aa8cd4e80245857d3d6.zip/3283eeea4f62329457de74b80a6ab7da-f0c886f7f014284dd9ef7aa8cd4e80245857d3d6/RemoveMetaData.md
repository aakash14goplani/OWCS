```jsp
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"
%><%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"
%><%@ taglib prefix="render" uri="futuretense_cs/render.tld"
%><%@ page import="COM.FutureTense.Interfaces.*, java.util.*"
%><%
 /******************************************************************************************************************************
   *    Element Name        :  Practice/Automation/RemoveMetaData 
   *    Author              :  Aakash Goplani 
   *    Creation Date       :  (09/06/2018) 
   *    Description         :  Element that removes meta data information
   *    Input Parameters    :  Variables required by this Element : cid and c
   *    Output              :  asset data without metadata
 *****************************************************************************************************************************/
%><cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if><% 
	
	try {
		String assetType = ics.GetVar("c");
		String assetId = ics.GetVar("cid");
		
		%><ics:logmsg msg='<%="Calling LoadAssetInfoEJ with " + assetType + " : " + assetId + " from RemoveMetaData" %>' severity="INFO" />
		<ics:callelement element="Practice/Logic/LoadAssetInfoEJ">
			<ics:argument name="cid" value="<%=assetId %>"/>
			<ics:argument name="c" value="<%=assetType %>" />
			<ics:argument name="assetPrefix" value="<%=assetId %>"/>
		</ics:callelement><%
		
		/* pre-defined array of meta values to be filtered */
		String[] metaData = new String[] {"SPTRank","SPTParent","flextemplateid","updateddate","id","Publist","path",
		"status","templateRootElement","urlexternaldoc","SPTNCode","Dimension","createddate","createdby","category",
		"startdate","updatedby","externaldoctype","filename","urlexternaldocxml","enddate","Dimension-parent","fw_uid",
		"SegRating","Relationships","renderid", "subtype"};
		Arrays.sort(metaData);
		
		Enumeration<?> e = ics.GetVars();
		Map<String,String> actualData = new HashMap<String,String>();
		actualData.clear();
		String variableName = "", temp = "";
		
		/* variableName = assetId:var_name, temp: var_name */
		while(e.hasMoreElements()) {
			variableName = e.nextElement().toString();	
			//out.println("<br/>DEBUG: variableName w/o : = " + variableName + "<br/>");
			if(Utilities.goodString(variableName) && variableName.contains(":")) {
				temp = variableName.substring(variableName.indexOf(":") + 1);
				//out.println("<br/>DEBUG: temp = " + temp + ",variableName = " + variableName + "<br/>");
				/* if temp(var_name) is not null and it is not one of pre-defined meta-data and temp(var_name) value is not null */
				if( Utilities.goodString(temp) && !Arrays.asList(metaData).contains(temp) && Utilities.goodString(ics.GetVar(assetId +":" + temp))) {
					/* replaceAll function to remove CSV special characters from body_text or any other field */
					actualData.put(temp, ics.GetVar(assetId +":" + temp).replaceAll("(\r\n|\n)", ""));
					//out.println("<br/>DEBUG: temp = " + temp + ",value = " + ics.GetVar(assetId +":" + temp).replaceAll("(\r\n|\n)", "") + "<br/>");
				}
			}
		}	
		
		ics.setAttribute("actualData", actualData);
		//out.println(actualData);
	}catch(Exception e) {
		out.println("<div class=\"error\">Exception Occured in RemoveMetaData element: " + e.getMessage() + "</div><br/>");
	}
%></cs:ftcs>
```