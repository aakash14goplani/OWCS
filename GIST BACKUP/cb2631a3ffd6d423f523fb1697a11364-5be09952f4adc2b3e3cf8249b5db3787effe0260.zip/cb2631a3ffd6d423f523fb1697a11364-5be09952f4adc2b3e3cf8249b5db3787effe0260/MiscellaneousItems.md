## Using Slots with CSElement and SiteEntry Assets   

A slot meant to contain a CSElement asset is typically defined as:

```jsp
<insite:calltemplate slotname="GetAssetInfoElement" clegal="CSElement" emptytext="CSElement Dropzone" context="Global|Local" />
```   

and for `SiteEntry`:   

```jsp
<insite:calltemplate slotname="GetAssetInfoSiteEntry" clegal="SiteEntry" emptytext="SiteEntry Dropzone" />
```

There is no need to specify a `tname` attribute in this case, since the `CSElement` and `SiteEntry` assets are directly referring to the JSP element in charge of rendering them.   

In order to see `SiteEntry` or `CSElement` in the list of allowed asset types for the slot, you need to make sure that both asset types have their **Can Be Child Asset** flag set to _True_ (which means that this asset type can be the child asset type in an association field for another asset type.)   

A SiteEntry asset does not hold any code, but simply points at a CSElement asset. The only difference between one case and the other is that, when using a SiteEntry, the element is invoked through the cache engine. Consequently, the same result can be achieved by dropping a SiteEntry asset or dropping its related CSElement asset.   

## Constraining Asset Types   

By default, WebCenter Sites allows the following asset types to be dropped into a slot:   

if `field` is defined (content-editable slot): any legal asset types given by the field definition   

if `field` is not defined (presentation-editable slot): any asset type for which the **Can Be Child Asset** flag is set to _True_.   

It is also possible to further restrict allowable asset types, using the `clegal` attribute:   

```jsp
<insite:calltemplate
  slotname="Main"
  clegal="Article,Product"
  ... 
/>
```   
The following syntax allows to additionally restrict by asset subtypes:

```jsp
<insite:calltemplate
  slotname="Main"
  clegal="type1:subtype1,type2:subtype2"
  ... 
/>
```   
**Note:**
Using `"type:*"` (with asterisk as wildcard) is also valid, and behaves as the "type" value.   

## Preventing CSS and JavaScript Conflicts   

The in-context UI is injecting styles and JavaScript into web pages, when rendered in the Contributor interface in **Web Mode / Edit View** (and only in this case).      

This may possibly result in:   

* **CSS conflicts**: for instance, slots are improperly displayed due to a site CSS rule applying to them)   

* **JavaScript conflicts**: the web page already has JavaScript which conflicts with the JavaScript injected in the page in the editing view. As a result, either the editorial UI or the page itself do not work properly.   

CSS conflicts are typically solved by adding extra CSS rules, which are loaded only when the template is rendered inside the editorial UI, in editing mode. This is done by using the insite:ifedit tag, which allows to execute JSP code only when the JSP template is ran in editing mode:

```
<insite:ifedit>
<%-- This stylesheet import will only occur in editing mode.
  -- It will not have any impact on the actual rendering of the
  -- live site.
  --%>
  <link rel="stylesheet" 
   type="text/css" 
   href="/css/editorial.css" />
</insite:ifedit>
```   

Extra CSS classes can be added to slots by using the cssstyle attribute of the insite:calltemplate tag, to specify specific CSS rules for slots.   

CSS conflicts typically when rendering slots around elements which are floated: in this case, the blue or green overlay which is marking the slot area is likely to not have the proper dimension.   

JavaScript conflicts are normally solved by degrading the behavior of the web page in editing mode only, in order to let the scripts injected by the editorial UI function properly. This may mean disabling some of the page functionality in Web Mode / Edit View of the Contributor interface.


### References

[Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_siteassets.htm#WBCSD1961)