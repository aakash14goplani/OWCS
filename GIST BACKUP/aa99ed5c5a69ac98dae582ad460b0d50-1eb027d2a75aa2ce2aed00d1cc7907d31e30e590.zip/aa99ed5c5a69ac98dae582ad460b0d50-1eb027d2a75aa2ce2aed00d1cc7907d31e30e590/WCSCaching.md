# Fatwire multiple caches

Fatwire Content Server has many caches, and it is very important to understand all of them.

Here a short list of the caches you have to consider

1. **Content Server Cache:**
   * This is a content cache (html primarily) This cache is stored on disk. It can became very large because it caches a rendered html in full. It is fast but it read the content from disk and this can slow down a busy website.
   * ContentServer generates pagelets on request of Satellite, executing template code (either JSP or XML). It also caches the output of the rendering, for 2 reasons:
      * First reason, Satellite is optional, and Content Server can run a  site without Satellite, and must do it efficiently.
      * Second reason , multiple Satellites can be  deployed, so you may need to serve the same pagelets more than once. Also a Satellite can crash, or another satellite be added, so serving pagelets must be fast as well.
   * ContentServer cache is  the second cache in place. You can inspect the Content Server Cache looking at the SystemPageCache database table and its attachments. The servlet to clean the content server cache is CacheServer.
   * Please note that when you inspect the ContentServer cache you will see the pagelets generated for satellite, however cached pagelet  for Satellite are stored in memory within satellite. So empting ContentServer cache won't clean also Satellite cache. If you want to clean also Satellite cache, that you have to do it manually.
   * A complete reset of the front-end cache involves both all the Satellite Servers and Content Servers.
   * Next up is the core Content Server cache. This executes the code from your CSElements and Templates and from this generates and stores pagelets at the request of Satellite Server.
   * Note that Satellite Server itself cannot generate the pagelets, it only assembles them.  Note also that the caching parameters can be set separately on Content Server and Satellite Server.
   * Content Server can also assemble pages without the assistance of Satellite Server, but this is not recommended. It is more expensive than using the extra layer of caching that Satellite Server provides.

2. **Satellite Server Cache:**
   * This is another content cache (html). This cache is stored in memory. To limit the memory required, it does not store the full html but keeps the content split in different pieces, and reassemble it on demand.
   * When you visit a Fatwire website, you normally access to one of the Satellite Servers. In a normal deployment we have many satellite servers, ideally geographically distributed in net, and the possibly located close to your browsing location, internet-wise.
   * Satellite Servers are the ultimate cache in place. They cache the site, splitting web pages in pagelets. A pagelet is a piece of already rendered html. It is important to understand that a pagelet is not a whole webpage, but actually only a part of a page (think to the header, a summary, a generic block).
   * Pagelets are assembled in place by Satellite to build complete web pages. Note that because pagelets are expected to be small enough to be kept in memory, assembling of a page is expected to be very fast (no database is involved, mostly of the cache is kept in-memory except bigger files are stored on the disk). Actually Satellite spools to disk pagelets larger than a given threshold (configurable in property files).
   * However Satellite does not have the ability to render templates, so when a pagelet expires or is invalidated, Satellite must grab the updated pagelet from Content Server.
   * Satellite cache can be inspected using a specific tool, the Inventory servlet (using the appropriate username and password), and can be flushed using the FlushServer servlet.
   * All initial requests to a Content Server installation should (ideally) hit the Satellite servlet first. If they don’t, you’re probably doing something wrong. Satellite Server has no database and most of the contents of its cache will generally be held in memory, although this is configurable.
   * In general, Satellite Server spends most of its time assembling pagelets and proxying requests to the ContentServer and BlobServer servlets. Pagelets are smallish parts of a page which are subsequently turned by Satellite Server into an entire webpage.
   * There is an an ideal number of pagelets which compose a page.
   * If there are too few, it can result in large swathes of the cache being invalidated during a publish.
   * If there are too many, Satellite Server can end up spending large amounts of time putting together all the tiny fragments. Generally you’ll want no more than a couple of dozen pagelets in any given page.

3. **Blob Server Cache:**
   * This cache is for binary content. It is a memory cache as well up to a certain limit, then it became a disk cache.

4. **ResultSet Cache:**
   * This cache is for the result of queries. To avoid running the same query again and again, Fatwire store the result and keep it in memory for a while. Since many queries are the same, this can help a lot. Actually, thank to this cache, Fatwire often performs well even with very slow databases.
   * When you query a database, you store the result in a list in memory (in Fatwire they are generally IList, that caches the output of Java ResultSets). As long as no one accesses any more to the table from where the IList was generated, running the same query will produce the same result, so it may be cached.
   * Result Set cache is caching results of database queries for each query executed. ResultSet are associated to tables, so  the cached results are valid until the underlying database table changes. The result set cache is invalidated table by table whenever someone write in the database table from where content was retrieved.
   * This cache is helpful because ultimately all the content must be extracted by the database, but is is useful also when you write custom queries. It can be tuned editing futuretense.ini and flushed using CatalogManager servlet.
   * Content Server maintains the Resultset Cache which sits between the database and the CatalogManager servlet which governs database access.
   * Content Server caches the resultsets in memory. The first time a query is executed, the results of that query are stored in memory. When the same query is ran, the results are served from memory rather than querying the database again.
   * The Resultset Cache Settings are specified in the futuretense.ini configuration file and include:
      * default number of resultsets to keep in memory
      * default amount of time to keep resultsets in memory
      * how to calculate the expiration time
      * table-specific settings
      * When the maximum is reached, the least recently used resultset is flushed. When a table is updated, all corresponding resultsets are flushed.
   * Using the Support Tools, it is possible to inspect a graphic representation of the contents of the Resultset cache, including which resultsets are full, and the percentage of queries that are hitting (or missing) the cache.
   * The idea is to maximise the number of queries that hit the cache, and to size the caches big enough that the maximum is rarely reached.

5. **InCache Cache**
   * So far we have seen caches that store  pagelets, that are fragments of rendered  html. Those caches works with templates having cache enabled.
   * However it is common to have some templates that cannot be cached. Typically this happens with certain templates that  always return a different rendering (for example, searches), and caching the output pagelet can is difficult and fundamentally pointless.
   * The most recent addition to the family of Fatwire caches is InCache, that basically caches the  underlying "pojos" used for rendering. You may ask what those pojos are.
   * When you execute template code, you perform calls like `<asset:load  name="theAsset" ...>` or `<assetset:setasset  name="theAssetSet" ...>` to load assets. Please note that "theAsset"  or "theAssetSet" are actually Java Objects (POJO  = Plain Old Java Objects) that will be used to render the content. Loading them is expensive because a lot of database requests may be required (or at least once, that is by far the slower operation).
   * Enabling InCache, those pojos are cached as well. So this cache helps to speed up the rendering of uncached templates. Indeed, the vast majority of the time is spent querying the database, and reusing already queried POJO helps a lot in speeding up also uncached templates. It also helps saving memory and reducing garbage collection.
   * Historically, the Content Server cache utilised the database and filesystem to store its cache fragments. These fragments were stored in a table called SystemPageCache, and on the filesystem in the location [shared_foler]/SystemPageCache.
   * The issue with this was that that table could get big very quickly, and there are also three files stored on the filesystem for every entry in the table (the .qry, .hdr, and .txt files).
   * The files are stored in nested, numbered directories, and can easily run into millions of files. To work around the limitations with this system, InCache was developed.
   * This system is built on top of Ehcache, a product from Terracotta. Compared to the legacy method of caching to the database, inCache offers improved website performance. This is because the cache is moved from the filesystem and database into memory.
   * Naturally, this move can drastically increase the usage of the JVM heap, so careful sizing of the heap is necessary when migrating from the old caching method to InCache.
   * It is also decentralised as opposed to the older solution, so each Content Server instance in a cluster maintains its own cache, and invalidation messages are sent to each cluster node when a cache entry is invalidated.
   
6. **Asset Cache**
   * This is a relative newcomer in the caching architecture, only becoming available with the 7.6 release of the product, because it is based on the InCache framework mentioned above.
   * Rather than caching pagelets, it caches the results of loading an asset, for instance with the asset :load tag, the AssetDataManager.read Java method, or the REST API.
   * It protects WebCenter Sites’ performance by taking up load that would otherwise affect the database.
   
### Summary

What all of these caches are working towards is to reduce the load on the various components of your system, particularly the database.

If you think of the application stack as a funnel, a good caching strategy will ensure that the vast majority of the requests are dealt with at the upper levels of the stack.

The Satellite Server cache should field most of the traffic, a few requests may be dealt with by the Content Server cache and Asset Cache, a small number might get as far as the resultset cache, and very few would be reaching all the way to the database.  


### References

[manifesto](https://manifesto.co.uk/webcenter-sites-caching-strategies/)   
[sciabarra](http://www.sciabarra.com/fatwire/category/tips-and-trick/index.html)   
[Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_caching_chapter.htm#WBCSD2541)