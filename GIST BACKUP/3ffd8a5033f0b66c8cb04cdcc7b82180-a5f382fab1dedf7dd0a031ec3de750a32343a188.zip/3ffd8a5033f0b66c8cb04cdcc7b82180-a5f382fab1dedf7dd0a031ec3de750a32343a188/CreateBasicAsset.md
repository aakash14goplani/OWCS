### General steps to follow

1. Create the _Asset Descriptor File_.
   * General syntax of file
   ```xml
   <?xml version="1.0" ?>
   <ASSET NAME="assetName"...>
      <PROPERTIES>
         <PROPERTY.../>
            <STORAGE.../>
            <INPUTFORM.../>
            <SEARCHFORM.../>
            <SEARCHRESULTS.../>
         </PROPERTY>
         <PROPERTY... />
            <STORAGE.../>
            <INPUTFORM.../>
            <SEARCHFORM.../>
            <SEARCHRESULTS.../>
         </PROPERTY>
      </PROPERTIES>
   </ASSET>
   ```
   * The name you assign to `ASSET NAME="assetName"`, the xml file should be saved with that name itself (in this case assetName.xml)   
   
2. Click on `Admin` tab.   

3. Under `AssetMaker` click on `Add New AssetMaker Asset Type`.

4. Click in the **Name** field and enter the name of the new asset type. The string that you enter into this field must exactly match the string specified by the ASSET NAME parameter in the asset descriptor file that you are going to upload.

5. Click the **Browse** button next to the Descriptor File field and select the asset descriptor file.

6. Click **Save**.

7. Select **Create Asset Table**

8. Select **Register Asset Elements** and then click the **Register Asset Elements** button

9. Configure start menu to enable this asset type for current site.

### Demo Asset Descriptor File

```xml
<?xml version="1.0" ?>
<ASSET NAME="GenericBasicAsset" DESCRIPTION="Generic Basic Asset" DEFDIR="D:\WebCenter">
  <PROPERTIES>
    <PROPERTY NAME="username" DESCRIPTION="Username">
      <STORAGE TYPE="VARCHAR" LENGTH="24"/>
      <INPUTFORM DESCRIPTION="Username" TYPE="TEXT" REQUIRED="YES" />
    </PROPERTY>
    <PROPERTY NAME="comments" DESCRIPTION="Comments">
      <STORAGE TYPE="VARCHAR" LENGTH="255"/>
      <INPUTFORM DESCRIPTION="Comments" TYPE="TEXTAREA" COLS="5" ROWS="3" />
    </PROPERTY>
    <PROPERTY NAME="urlpicture" DESCRIPTION="Image File">
      <STORAGE TYPE="VARCHAR" LENGTH="255"/>
      <INPUTFORM TYPE="UPLOAD" WIDTH="36" REQUIRED="NO" LINKTEXT="Image"/>
    </PROPERTY>
    <PROPERTY NAME="gender" DESCRIPTION="Gender">
      <STORAGE TYPE="VARCHAR" LENGTH="10"/>
      <INPUTFORM DESCRIPTION="Gender" TYPE="SELECT" SOURCETYPE="STRING" OPTIONDESCRIPTIONS="Male,Female,Other" OPTIONVALUES="m,f,o" />
    </PROPERTY>
    <PROPERTY NAME="married" DESCRIPTION="Marital Status">
      <STORAGE TYPE="VARCHAR" LENGTH="10"/>
      <INPUTFORM DESCRIPTION="Marital Status" TYPE="RADIO" SOURCETYPE="STRING" RBDESCRIPTIONS="Yes,No" RBVALUES="y,n" />
    </PROPERTY>
    <PROPERTY NAME="urlbody" DESCRIPTION="Body Text">
      <STORAGE TYPE="VARCHAR" LENGTH="250"/>
      <INPUTFORM TYPE="CKEDITOR" WIDTH="300" HEIGHT="300" REQUIRED="NO" INSTRUCTION="Be concise! No more than 3 paragraphs."/>
    </PROPERTY>
  </PROPERTIES>
</ASSET>
```

### References

* [Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/data_designbasictype.htm#WBCSD1498)
* [AssetMaker tag reference](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/MISC/TOC_AssetMaker.html)