<p>
  This blog post will outline a detailed, step-by-step guideline to set up an Oracle WebCenter Sites (OWCS) development environment that runs on Tomcat, connects to Git and integrates with Eclipse and the Content Server Developer Tools (CSDT).
</p>
<ol>
  <li>Install a fresh OWCS JumpStart Kit (JSK), with no sample sites
    <ul>
      <li>The JSK could be a fresh local installation of OWCS</li>
    </ul>
  </li>
  <li>Start the JSK</li>
  <li>Create a new ContentServer (CS) workspace in Eclipse</li>
  <li>Open eclipse, switch to Oracle WebCenter Sites (or ContentServer) perspective</li>
  <li>Connect to the JSK (it will prompt you for the project name)
    <ul>
      <li>The new CSDT workspace will always default to the directory "&lt;ContentServer_Root&gt;/export/envision/cs_workspace"</li>
    </ul>
  </li>
  <li>Once connected to the JSK via CSDT, continue</li>
  <li>Rename the "/cs_workspace/" folder to "/cs_workspace_old/"</li>
  <li>Create a new, empty "/cs_workspace/" folder</li>
  <li>Switch to Git perspective in Eclipse</li>
  <li>Clone an existing remote repository
    <ul>
      <li>Enter the Git repository URL</li>
      <li>Example: `https://github.com/aakash14goplani/repo_name.git`</li>
    </ul>
  </li>
  <li>The destination for this clone should be your new, empty "/cs_workspace/" folder (if need be, delete the ".project" file).  Other than that, accept all the defaults.  This will download all files from the remote repository onto your local machine.</li>
  <li>Copy the ".classpath" and ".project" files from your old "/cs_workspace_old/" folder into the new one</li>
  <li>Back in Eclipse, change back to the Oracle WebCenter Sites (or ContentServer) perspective</li>
  <li>Right-click on project in the Project Explorer in Eclipse</li>
  <li>Select Team `-->` Share Project</li>
  <li>Choose Git</li>
  <li>If available, check the box for "Use or create repository in parent folder of project"</li>
  <li>Select a ".git" file that points to the repository you cloned in your local CSDT workspace (&lt;ContentServer_Root&gt;/export/envision/cs_workspace)</li>
</ol>
<div>
  At this point, we’ve connected our local CSDT workspace to a remote Git repository via Eclipse.
</div>

### Contents of `.gitignore` file

### References

1. [Function 1](https://www.function1.com/2012/12/setting-up-a-development-environment-in-oracle-webcenter-sites)
2. [A new repo from an existing project](http://kbroman.org/github_tutorial/pages/init.html)