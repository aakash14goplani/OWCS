# Cache Dependencies

One of the best kept "secret" of Fatwire is the cache invalidation mechanism.

1. Rendering an asset is slow.
   * Really slow. It is slow because there are many database queries involved. So, once a template is rendered, the result is cached (at least, if you have enabled caching for that template).
   * But, when you cache a component, what happens if the source asset change? I mean, what happens if you render an article, and then the article is updated? Of course, when the source asset is updated the cached element is invalidated.

2. Asset dependencies
   * There is actually a database table tracking all the dependencies. For each cached element (called "pagelet") in the database, a dependency is stored in that table. That is, the information: "which pagelet must be invalidated when an asset is updated".

3. Publishing invalidate the cache
When you publish it happens that the cache is updated, as well. For each published asset,
   * all the dependencies are searched for
   * all the cached pagelet that depends on the published asset are invalidated.
Please note that this happens only for the pagelets that have dependencies on the published assets.

4. Smart Cache
   * So you don't need to rebuild the whole cache, but only the pagelet that are invalidated. Just a bunch of them. Those who depends on the new assets.
   * It is a smart and powerful mechanism. Unfortunately, is is also a mechanism easy to break if you don't follow a design and some simple rules in coding templates.
   * Or worse, if you ignore the caching and the dependency mechanism.
   
WC Sites  (formerly Fatwire ContentServer) is a content oriented CMS, as opposed to other page oriented CMS. The exact meaning of being driven by the content is that you are required only to describe your content without considering how this content will be actually rendered .

This idea has a few consequencies that must be taken in appropriate consideration when you design and code a WCS implementation.

The biggest problem in this separation is that you must keep some track of the relation beetween your content and its rendering.

(Well this is not actually totally true, considering insite editing, that is a presentation oriented technology, however it does not change the concept - content and presentation are separated but related).

### The relation between presentation and content

To better explain the problem consider a generic content, let's say an article in your site.

On the CMS you want to add it usually just once, but on the site the same article can appear a number of times in different web pages, in different formats.

For example an article can be displayed as a full text in a web page, as a summary in another web page or just as a simple link in many others.

All those occurrencies appears in different web pages, and you have to update all of them when the underlying content model changes. For this reason WCS stores in the database dependency informations.

The main reason to keep those informations is because they are needed for an easy and efficient updating of the cache when the content changes. In fact, when the site is rendered, blocks of html (conventionally called pagelet) are generated from the content model and usually cached.

For each of those  pagelet a dependency is generated and stored. 

When the content model is changed all the stored dependencies are walked through and the dependent pagelets are invalidated and regenerated.

### In practice:

You can see all of this in action simply inspecting the table `SystemItemCache`. This table is somewhat obscure but it keeps one of the more important informations used in publishing: _dependencies between assets and pagelets_.

This table is calculated while rendering the content model in an actual live site. Many dependencies  are actually calculated by the render:calltemplate. When you call a template, you are also declaring that a new pagelet (the one that will be rendered by the template you are invoking) will depend on the asset specified by c and cid. So a new dependency will be recorded for this asset.

Dependencies can also be recorded explicitly using the `render:logdep` tag. Indeed, you may notice that when you create a new template, some code involving a logdep is automatically added.

That code should NOT be removed: it is adding a dependency between the template itself (the code generating the pagelet) and the generated pagelet. Obviously, when you change the code generating the pagelet, that pagelet must be regenerated.

In general, a pagelet rendering a given asset (identified by `c` and `cid`) depends always on the asset itself (so a `c:cid` dependency is required) and the template that render it (so a `Template:tid` dependency is also required).

However things can became much more complex than this. There are other sources of dependencies: for example `searchstate` calls usually generate some dependencies, and an index gathered by a search can depend on so many assets that... an  "unknown dep" can be generated.

Those special dependencies basically invalidate each pagelet when any asset of a given type changes.

### Common Errors

Unfortunately, caching and even worse dependency management are often misunderstood.

Some (untrained) developers are somewhat vaguely aware of the caching, but very often they completely ignore dependencies.

A common error is to create a template that depends on two or more assets (the first one being the `c/cid`, while the other is specified with extra parameters). Unfortunately, only the dependency specified by `c/cid` is actually recorded, so when the other asset change, the corresponding pagelet is NOT invalidated.

The net effect is a website that won't be updated when the content change (unless you invalidate all the cache).

# Approval & Compositional Dependencies in Oracle WebCenter Sites

**Approval Dependency:**   
This is the dependency that is logged when an asset is approved for publish. When you approve your asset for publishing, the Approval dependency is logged. This dependency is between the asset that is being approved and its dependent (child) assets. This dependency will verify whether the asset that is being approved can be published to the target machine or not. If there are dependent assets, that need to be approved, then this asset cannot be published.

The Approval dependency is logged when the asset is approved for publish.

**Compositional Dependency:**   
This can be called as Page Composition Dependencies. As the name itself specifies, it is the dependency between the asset and the pages/pagelets that are rendering this asset. This dependency determines whether the page needs to be regenerated, in case when assets are modified.

The CS logs compositional dependencies when it renders the pages.  On the other hand, the CacheManager checks the dependency log, whether to regenerate any pages, whose content has been outdated.

### How Approval dependencies are logged?

The dependencies are logged based on the type of publishing methodology.

**Export To Disk:**  If the publishing methodology is Export to Disk, the dependencies are calculated basing on the tags that are present in the code of the template that renders the asset.

**Mirror To Server:** If the publishing methodology is Mirror to Server, the dependencies are calculate basing on the Family Relationships (for Flex Assets )  / Associations (for Basic Assets) between the assets. Both these type of relationships create approval dependencies.

### Types of Approval Dependencies:

The Approval dependency type for CSElements and SiteEntry assets, embedded links and pagelets cant be changed. The approval dependency type for the flex family asset types also can’t be changed. The approval dependency of basic asset types can be modified. We set the type of approval dependency for their associated assets when you configure the associations.

Approval dependency can be of three types:

1. **Exists:**   
If this dependency is selected, then the dependent assets (child asset) must just exist on the target machine, and the version number of the child asset doesn’t matter, as long as the child asset is approved and published to the same machine. This means that the asset that is approved (parent asset) can be published even if the child assets changes (in version, content, etc) between source and target machines.
2. **Exact:**   
If this dependency is selected, then the dependent asset must be of the same and exact version on the target machine. The parent asset can’t be published, if the versions of parent and child assets on the source machine do not match the versions of parent and child assets on the target machine.
3. **None:**   
If this dependency is selected, then the approved asset can be published to the target machine, without bothering about the version / state of the dependent assets.

### How Compositional Dependencies are logged?

Compositional dependencies are recorded in different ways. There are several tags that log compositional dependencies.

When Content Server executes an asset:load tag, it automatically logs a compositional dependency for the asset that is loaded, and the page that is going to be rendered

Similarly, `assetset:setasset`, `ssetset:setsearchedassets`, `assetset:setlistedassets` tags render compositional dependency. When an asset from the assetset is rendered, the compositional dependency is logged.

When these tags are executed, Content Server logs a dependency between the rendered page and the asset by writing this information in the `SystemItemCache` table.

### References

[sciabarra](http://www.sciabarra.com/fatwire/category/tips-and-trick/index.html)   
[kksays](https://kksays.wordpress.com/2012/12/18/approval-compositional-dependencies-in-fatwire-oracle-webcenter-sites/)