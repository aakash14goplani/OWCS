The `insite:calltemplate` tag allows editorial users to edit associated content and edit the layout. This section explains the difference between a _content-editable slot_ and a _presentation-editable slot_ and how to combine the functionality of both to allow editorial users to edit both the associated content and the template used to render the content.   

`insite:calltemplate` tag can replace `render:calltemplate` in order to allow content contributors to:   

* **edit content**, i.e. whenever `insite:calltemplate` renders an asset field containing one or more asset references.The `field` attribute must be specified to enable content editing mode.   

* **edit presentation**, i.e. allowing to select alternate templates to the ones specified by developers and/or allowing to specify template arguments from the in-context UI.   
   + the `slotname` attribute has to be specified to enable presentation editing mode.
   + the `variant` has to be specified in order to specify acceptable alternate templates.
   + the template arguments which are editable by contributors must be registered as **legal arguments**   

* **both**, if `slotname` and `field` are specified

**Content-editable slots** allow users to edit associated content by providing a droppable zone for the user. **Presentation-editable slots** allow users to select a different template to render the content.   

To create a **content-editable slot** (creates a droppable zone for the user) the `insite:calltemplate` tag is used with the following defined parameters:   

```
assetid: The edited asset ID.

assettype: The edited asset type.

field: The edited field.

cid: The ID of the asset to be rendered by the called template.

c: The asset type to be rendered by the called template.

tname: The pagelet template used to render the associated asset.
```

This code defines a **content-editable slot** that creates a droppable zone for the user:   

```jsp
<insite:calltemplate
  assetid=" "
  assettype=" "
  field=" "
  cid=" "
  c=" "
  tname=" " 
/>
```   

To create a **presentation-editable slot** (allows users to select a different template to render content) the `insite:calltemplate` tag is used with the following defined parameters:

```
slotname: This attribute defines an identifier for the slot that is being filled with the called template. It should be reasonably easy to understand and should be unique across all templates.

cid: The id of the asset to be rendered by the called template.

c: The asset type to be rendered by the called template.

tname: The default pagelet template to be called.
```

This code defines a **presentation-editable slot** that allows users to select a different template to render the content:

```jsp
<insite:calltemplate
  slotname=" "
  cid=" "
  c=" "
  tname=" " 
/>
```   

To combine the functionality of both **content-editable slots** and **presentation-editable slots**, the `insite:calltemplate` tag is used along with all the attributes required for both a **content-editable slot** and a **presentation-editable slot**.

* These attributes are required for a **content-editable slot** (creates a droppable zone for the user): `field`, `assetid`, `assettype`   
* This attribute is required to define a **presentation-editable slot** (allows users to select a different template to render the content): `slotname`   

This code combines the attributes for a **content-editable slot** and a **presentation-editable slot**:

```jsp
<insite:calltemplate
  slotname=" "
  assetid=" "
  assettype=" "
  field=" "
  cid=" "
  c=" "
  tname=" " 
/>
```

This can also be achieved using:   
```jsp
<insite:slotlist field="practice_assets" slotname='<%=ics.GetVar("cid") + ":AssetDropzone" %>'>
    <ics:listloop listname="assetList">
      <ics:listget listname="assetList" fieldname="value" output="articleId" />
      <asset:load name="loadCurrentAsset" type="Practice_C" objectid='<%=ics.GetVar("articleId")%>'/>
      <asset:get name="loadCurrentAsset" field="template" output="templateName" />
      <insite:calltemplate tname='<%=ics.GetVar("templateName")%>' c="Practice_C" cid='<%=ics.GetVar("articleId")%>' />
    </ics:listloop>
</insite:slotlist>
```

### References

[Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/dev_siteassets.htm#WBCSD1951)