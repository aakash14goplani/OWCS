# Named Associations

1. Click on **Admin** tab.
2. Click on **List all Asset Types**
3. Select the particular asset type for which you want to enable association
4. Under that asset type, from dropdown menu, select **Associations**
5. Click on **Add new Associations**
6. Fill in all the details as per requirements and select **Add new Associations**

# Unnamed Associations

**Query Assets**

1. Click on Contributor UI
2. Click on **New -> New Query** (Query assets must be enabled in start menu)
3. Enter the **Name** to be assigned to Query asset.
4. In **Result of Query** dropdown select the asset type for which query is being fired.
5. You can write Query in two ways:
   * paste your sql query in **Database** text area
   * Create a CSElement and write your SQL query. Make the reference(name along path) of that element in **Element** field
6. Click on **Save**


**Colloection assets**

1. Click on Contributor UI
2. Click on **New -> New Collection** (Collection assets must be enabled in start menu)
3. Enter the **Name** to be assigned to Query asset.
4. In **Subtype** dropdown select the asset type for which collection is created.
5. In **Associated Queries** select the query assets that are required as per requirement
6. Click on **Save** 


### References
[Developer's Guide](https://docs.oracle.com/cd/E29542_01/doc.1111/e29634/creating_collections.htm#WBCSD2060)