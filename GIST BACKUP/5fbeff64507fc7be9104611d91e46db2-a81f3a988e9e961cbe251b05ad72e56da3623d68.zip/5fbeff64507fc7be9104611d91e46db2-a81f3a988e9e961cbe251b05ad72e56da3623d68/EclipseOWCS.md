# How to directly edit the Fatwire JSP   

Fatwire keeps templates as assets. So each template has some metadata, stored in the database, but the actual code is still in a file inside a folder. This folder is located in the `Shared/elements` folder. The location of the Shared folder depends on the installation. JumpStart places it under `INSTALL-DIR/ContentServer/11.1.x.x/Shared`. In a custom install you decide where the `Shared` folder is.

So, if you create a typeless template named "Layout", usually you can find the actual code inside the folder `Shared/elements/Typeless/Layout.jsp`, while a typed template (for example Body for a Page) will be under `Shared/elements/Page/Body.jsp`. The actual name of the file is show in the template itself, in the Element section. Fatwire for versioning purposes can change the name in something like `Layout,0.jsp`, `Body,1.jsp` and so on. So definitely you have to consult your template asset to know the actual file name.

So it is a pretty obvious idea trying to edit the JSP directly on the disk... However, if you do this in a default installation, you will have the surprise that... nothing happens (unless you restart the application servers). Your changes are apparently completely ignored by `ContentServer`.

To directly edit the JSPs under elements, and ContentServer actually immediately reflecting the change we need to update a property of `futuretense.ini`: `ft.filecheck`   

If you change this property to `yes`, you can simply edit JSP on the file system, reload your page and the result will reflect your page! Extremely agile and flexible.

So, now that I know I can actually edit JSP directly on the disk, after enabling this property all I need now is a good JSP editor. For example eclipse. Here is how to configure Eclipse for Fatwire Editing in 5 simple steps.

### Configuring Eclipse for editing templates

You need a recent version of eclipse, at least H(elios) that supports linked resources, and the Web Development Tools (so you can edit the JSP). Previous versions do not support resource linking, and without linking, configuring the eclipse project became difficult and tricky.

Let's see how to do this step by step.   

1. Create a new Dynamic Web Project

First step is to create a  new project, more precisely a Dynamic Web Project. You can create it in a workspace, it does not matter where you place it. You will actually refer to the JSP inside the elements folder through a link.   

2. Link with the `WEB-INF` folder

Now, we need jar libraries and tag descriptors from Fatwire to enable JSP editing, tag library recognition, java completion and the like. Basically, all the stuff in the `WEB-INF` folder in the `webapp` part of your content server installation.

You do not need to copy them in the project (although you can do it if you like). Instead, as shown in the next image, all you need to do is to drag and drop the `WEB-INF` folder of the `cs webapp` in the `WebContent` folder, then LINK it.  

Please remember to select **LINK** (**not COPY**) when eclipse asks you what to do.

3. Link with the elements folder

Now you can actually link the elements folder for direct editing. So just select the elements folder under the Shared directory and drag it into the root of the project.   

Again, remember to **LINK** (**not COPY**). Here you cannot copy, it would not work.

Now you can start to edit the JSP. That is all, except that eclipse will show a few errors. Next steps are here only to fix them, but if you can survive with a few errors showing up you are basically done.

4. Disable XML validation

The first error is related to XML validation. Many xml files in fatwire have still the `<?XML` prefix with a capital XML, and this is wrong for the Eclipse XML parser (strictly speaking, Eclipse is right, those "XML"s follow a draft xml standard, not the official one). So what you have to do is disabling the XML validation.

Open preferences -> go to Validation and then -> disable XML Validator.

5. Hide a couple of JSP Directories

Some JSP present in Fatwire cannot be validated by Eclipse. Most notably, many contains a reference to the portlet jar, others have umbalanced HTML and so on. All those problems are in the system JSP that I am not generally interested in editing. So I generally just  hide them from Eclipse eyes (and validation).

The simplest way is to go in Preferences|Resources and add an exclusion rule to hide the 2 folders "elements/OpenMarket" and "elements/fatwire".

In this case all I did is to drag a void directory named fatwire and another void directory OpenMarket under elements. I created 2 new links to void directories hiding the 2 folders creating the validation errors.

**BE CAREFUL HERE:** if you drag a void directory over fatwire or `OpenMarket`, it once happened all the files inside were also removed! So I suggest you temporarily rename the 2 directory to another name, drag the void directory to create the hiding link and then restore them to the original name.

### Final Result and Benefits

You may notice the 2 links pointing to elements and WEB-INF and the two links to hide the OpenMarket and fatwire folder. Combined with the trick described in the first section of this post, you can now can edit the JSP using the complete power of eclipse (including validation and completion) and immediately see any change reflected in Fatwire .   


### References 

[sciabarra](http://www.sciabarra.com/fatwire/category/tips-and-trick/)