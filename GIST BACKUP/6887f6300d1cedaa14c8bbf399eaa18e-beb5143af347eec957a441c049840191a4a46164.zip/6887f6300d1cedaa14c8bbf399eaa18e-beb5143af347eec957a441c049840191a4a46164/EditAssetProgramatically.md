### Background

Some times, we need to modify the Fatwire Flex Content Definitions, that have been already created.

Say for example, there are thousands of Flex Assets, created using a Flex Content Definition. I would wish to remove / add few attributes to the content definition. I’ve done it.

Now, how the new attributes will reflect in the existing thousands of assets?

Simple answer: Just edit and save the assets. The new attributes will be reflected in the existing assets as well.

This is okay, if there are assets in tens, or around that. But, there will be thousands of assets, in reality. We can’t go and edit all the assets which are there in the system, as it is a lot of time taking process.

### Simple Solution

We can load all the assets through code, and use the tags like `asset:load`, `asset:canedit`, `asset:save`, etc to perform our job.

Here is a sample code, which loads and edits the asset, adding a value for the `DESCRIPTION` field.

```jsp
//Checkout the asset. This is optional. But, suggestible to be used.
<asset:checkout type=”<%=ics.GetVar(“c”)%>” objectid='<%=ics.GetVar(“cid”)%>’>

//Load the asset.
<asset:load name=”SampleAsset” type='<%=ics.GetVar(“cid”)%>’ objectid='<%=ics.GetVar(“cid”)%>’ editable=”true” >

//Scatter the asset’s attributes.
<asset:scatter name=”SampleAsset” prefix=”Sample“/>

//Set the new value
<ics:setvar name=”Sample:description” value=”THIS IS NEW DESCRIPTION” />

//Gather all the variables
<asset:gather name=”SampleAsset” prefix=”Sample” />

//Save the asset to the database
<asset:save name=”SampleAsset” />

//Checkin the asset.
<asset:checkin name=”SampleAsset” />
```

Now, INSPECT the assets from the Admin UI. You will find them updated.