To make our work of building websites simple, Fatwire ships with a few Tools and Utilities. These are called **CONTENT SERVER TOOLS AND UTILITIES**. Using these tools, we can see the tables, modify them and their data, export the tables, view and edit the properties, etc. Following are the CS Tools and Utilities that ship along with Fatwire.

1. Content Server Explorer
2. CatalogMover
3. PROPERTY EDITOR
4. XMLPost

### Content Server Explorer
One of the most popular Tools used by the developers to make their work easy. It is called as **CS-Explorer**. It has many features that attract the developers. We can edit, update the tables and rows in the CS Database. We can edit, update the Templates, CSElements written XML, JSP. Following are some of its uses.

 * Maintains Revision Tracking
 * Can edit the templates, elements etc, instead of going to the advanced UI, and editing there.
 * Add entries to the tables of database
 * Create and delete the tables
 * Export and Import the tables and records.
 
### References

[kksays](https://kksays.wordpress.com/2012/11/30/fatwire-content-server-tools-and-utilities/)