### 1. CRUD Operation
There is sample code for using the Java REST API in the WebCenter Sites install package, under `misc\Samples\WEM Samples\REST API samples`. You can check this code:
1. `CreateAsset.java`
2. `UpdateAsset.java`
3. `DeleteAsset.java`
4. `ReadAsset.java`

### 2. Setting Associations Using Java REST API in WebCenter Sites

1. Read the asset
2. Get the associations
3. Find the association you want to set
4. Add your asset to the association, as a String in the form "{asset type}:{asset id}"
5. Save the asset.

```java
AssetBean resultAsset = builder.get(AssetBean.class); // 1. Read the asset

Associations assocs = resultAsset.getAssociations();  // 2. Get the associations
ListassocList = assocs.getAssociations();

for(Association assoc: assocList) {                   // 3. Find the association you want to set
  List assetsList = assoc.getAssociatedAssets();
  if(assoc.getName().equals("MyAssociation")) {
  assetsList.add("<c>:<cid>");            // 4. Add your asset to it
  }
}

builder = builder.header("X-CSRF-Token", multiticket); // This line is necessary as of WebCenter Sites 11.x.x
builder.post(AssetBean.class, resultAsset);            // 5. Save the asset
```

* If the asset doesn't have associations yet, or you're creating a new asset, you can use the following to set the association:

```java
Association newAssoc = new Association();
newAssoc.setName("MyAssociation");
newAssoc.getAssociatedAssets().add("<c>:<cid>");
```

* You can specify the associations of an asset using a POST request to the asset's URL: `http://{server}:{port}/{context}/REST/sites/{site}/types/{asset type}/assets/{asset id}`

In XML you would specify the association names and associated assets as follows:
```xml
  <associations>
    <association>
      <name>theAssociationName</name>
      <associatedAsset>Document_C:1114721404472</associatedAsset>
    </association>
  </associations>
```

### 3. Use the REST API to place a page under another page in the Site Plan Tree

* Pages can be placed in the SitePlan Tree using REST by POSTing changes to the Page URL: `http://{server}:{port}/{context}/REST/sites/{site}/types/Page/assets/{page id}`   

* You will have to specify the Parent Page, Rank, and NCode (use "Placed"). E.g. using XML, the following snippet places the page under parent Page with id 1234567890, as rank 1:   

```xml
<attribute>
  <name>SPTParent</name>
  <data>
    <stringValue>Page:1234567890</stringValue>
  </data>
</attribute>
<attribute>
  <name>SPTRank</name>
  <data>
    <integerValue>1</integerValue>
  </data>
</attribute>
<attribute>
   <name>SPTNCode</name>
  <data>
    <stringValue>Placed</stringValue>
  </data>
</attribute>
```

* In Sites 11.1.1.8.0, if the Page needs to be placed in the root, set the SPTParent to the appropriate SitePlan asset, e.g. SitePlan:1478523690.   

* To unplace a page, change the SPTNCode to UnPlaced, with upper case U and upper case P.   

Using Java, this could work as follows:

```java
List<Attribute> attributes = assetToUpdate.getAttributes();
for(Attribute attribute: attributes) {
  if(attribute.getName().equals("SPTParent")) {
    attribute.getData().setStringValue("Page:1118867611403");
  }
}
```
and similarly for the other attributes.

* To unplace the page, use:

```jave
  if(attribute.getName().equals("SPTNCode")) {
    attribute.getData().setStringValue("UnPlaced");
  }
  if(attribute.getName().equals("SPTParent")) {
    attribute.getData().setStringValue(null);
  }
```

### 4. Use the REST API to share an asset with another site

You can share assets between sites by adding the sites to their publists and POSTing to the asset's REST URL: `http://{server}:{port}/{context}/REST/sites/{site}/types/{asset type}/assets/{asset id}`

In XML that is done as follows.

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns2:assetBean xmlns:ns2="http://www.fatwire.com/schema/rest/1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.fatwire.com/schema/rest/1.0 http://localhost:18080/cs/schema/rest-api.xsd">
<id><c>:<cid></id>
<name>MyAsset</name>
<createdby>fwadmin</createdby>
<createddate>2018-11-05T15:25:19.852Z</createddate>
<description></description>
<publist>NameOfSite1</publist>
<publist>NameOfSite2</publist>
<status>ED</status>
```

Each `<publist>` entry specifies a Site that the asset will be shared to. Leaving out `<publist>` entries will unshare the asset from that Site.

### 5. Specify a flex asset's parent asset using the REST API?

You can specify the parent of a new Flex asset by providing the `parentDefName` (name of the parent definition) and `asset` (asset type and id of the parent) using a `POST` request to the asset's URL: `http://{server}:{port}/{context}/REST/sites/{site}/types/{asset type}/assets/{asset id}`

In XML that is done using the following snippet

```xml
<parent>
  <parentDefName>Asset Parent Definition</parentDefName>
  <asset><c>:<cid></asset>
</parent>
```

### 6. Populate an attribute of type Asset using REST?

This is done the same way as an attribute of type string. The value should be set to `{asset type}:{asset id}`, e.g. `ABC_C:1230987654321`.    

In XML this looks like:

```xml
<attribute>
<name>MyAttributeOfTypeAsset</name>
<data>
  <stringValue><c>:<cid></stringValue>
</data>
</attribute>
```

* For multi-value attributes, use a stringList instead of stringValue:

```xml
<attribute>
<name>MyAttributeOfTypeAsset</name>
<data>
  <stringList><c>:<cid1></stringList>
  <stringList><c>:<cid2></stringList>
</data>
</attribute>
```

* You can use `com.fatwire.rest.beans.Attribute.Data.getStringLists()`. This method returns a `java.util.List<String>` reference, to which you can add items. It also returns an empty `java.util.List<String>` if your `Attribute.Data` was originally empty. There are similar methods for other types of attributes, such as `com.fatwire.rest.beans.Attribute.Data.getBlobLists()` for blob attributes.

The following sample code shows how to add a new value to a multi-value attribute of type string.

```java
List<Attribute> attributes = resultAsset.getAttributes();
for(Attribute attribute: attributes) {
  ...
  // Updating MyAttribute:
  if(attribute.getName().equals("Attribute_Name")) {
    // Get a String List and add new values to it:
    attribute.getData().getStringLists().add("This text gets added as an additional value to the multi-value attribute Attribute_Name.");
    attribute.getData().getStringLists().add("Second value that gets added.");
  }
  ...
}
```

* It works the same when creating new assets through the REST API:

```java
// 1. Create a new Articles attribute
Attribute sourceAssetAttribute = new Attribute();
sourceAssetAttribute.setName("Articles");

// 2. Create new Data for the attribute        
Data sourceAssetAttributeData = new Data();

// 3. Use getStringLists() to get a list, to which you can add multiple string values.
sourceAssetAttributeData.getStringLists().add("c:cid");
sourceAssetAttributeData.getStringLists().add("c:cid");
       
// 4. Set data in the attribute
sourceAssetAttribute.setData(sourceAssetAttributeData);

// 5. Add attribute to asset
sourceAsset.getAttributes().add(sourceAssetAttribute); 
```

### 7. Create assets with blob attributes via REST

```xml 
<attribute>
 <name>attribute_name</name>
 <data>
   <blobList>
     <filename>testfile.js</filename>
     <foldername>C:/Aakash/ContentServer/11.1.1.8/Shared/ccurl/</foldername>
     <filedata>bGV0IG1lIHRlc3QgdGhpcyBhZ2Fpbg== [BASE 64 encoding]</filedata>
   </blobList>
 </data>
</attribute>
```
 
* You can define multiple blobs by adding another blobList:   

```xml
<attribute>
 <name>attribute_name</name>
 <data>
   <blobList>
     <filename>file1.jsp</filename>
     <foldername>C:/Aakash/ContentServer/11.1.1.8/Shared/ccurl/</foldername>
     <filedata>bGV0IG1lIHRlc3QgdGhpcyBhZ2Fpbg== [BASE 64 encoding]</filedata>
   </blobList>
   <blobList>
     <filename>file2.js</filename>
     <foldername>C:/Aakash/ContentServer/11.1.1.8/Shared/ccurl/</foldername>
     <filedata>bGV0IG1lIHRlc3QgdGhpcyBhZ2Fpbg== [BASE 64 encoding]</filedata>
   </blobList>
 </data>
</attribute>
```

### 8. Search assets using the id of a parent asset

Example URL: example: `http://localhost:8280/cs/REST/types/<assettype_name>/search?field:ImmediateParents=1234567890`