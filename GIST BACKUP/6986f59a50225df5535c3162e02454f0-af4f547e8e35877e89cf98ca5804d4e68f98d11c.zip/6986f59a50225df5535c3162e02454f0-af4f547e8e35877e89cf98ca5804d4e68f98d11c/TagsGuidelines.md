1. Never hardcore assettypes and specifically, assetids in tags i.e. don't write them as they are present in FatWire. This is very important because after publishing your site from environment to other, assetids changes and hence, hardcording is never an option. Use tags to retrieve assetids. (Faced one such issues while working with 11g) For eg: If you want assetid of  a Page Asset, just load the Page asset using `<asset:load>` by providing name/value pair and retrieve assetid or use Template/CSElement mapping (`render:lookup` tag). This helps when 2 assets have same name but you have mapped the correct required one in the MAP.

2. Read what tag does before you use them. This is really important as I have seen people in past using tags without reading them and suffering from long hours of resolving many issues. For eg: Retrieving a flex asset using asset:load is NOT recommended. Site would work with no issues even if you use `asset:load` to retrieve flex assets, but later on when you site grows, you will face many performance issues. Hence, use correct tags to retrieve assets.

3. Check the attributes which are included while using tags. For eg: use of 'scoped' attribute while calling CSElement via render:callelement tag. Please read documentation before using any tags to leverage their full use. Another thing which I noticed in performance was using some tags attributes properly. For e.g. Using `<ics:listloop>` tag; suppose you want only 2 results, use maxrows argument so that loop does not iterate over full list, its just like adding break in for loop.

4. This may be new to many. XML tags and JSP tags can perform different in functionality. You may get some attributes/tags which are available in XML but not in JSPs and vice versa.

5. Use tags which sets compositional dependencies for cache management automatically. FatWire is all about Caching and Designing. If your design (creation of minimal flex family and basic family, less number of templates, proper use of subtype dispatching, etc. ) is proper and Caching strategies are well prepared, your site would be very fast and fluid. Some tags are unaware of what type of assets they are going to be deal with and hence, those tags generates undeterminable dependencies , which may again lead to performance issues. Eg: use `<render:unknowndeps>` when you querying for large number of assets. Please read about dependencies from documentation, it is very necessary to know about them.

6. Retrieving One attribute vs Multiple attributes: This may seems like very easy but again when your site grows large, you may face performance issues. For eg: Consider `asset:load` tag to retrieve basic asset. After using this tag, if you code to get every attribute of its asset using `asset:get` tag, it tries to fetch info every-time from db which is very performance costly, so use `asset:scatter` which will retrieve the required attributes in one go. Similarly is the case with flex assets. Check out `assetset:getattributevalues` and `assetset:getmultiplevalues` in tag reference.

7. Search tags: Searching assets via `asset:search` or `asset:list` is very costly than using searchstate tags for large amount of data. Check the use of searchstate tags explained in one of my blogs.

8. Always perform `NULL` checks and make use of  ics:geterrno to check if your tags threw any error. For eg: After retrieving attributes of flex assets in list, we should always check if the list is empty or not.

9. Flush the variables which are not required using `ics:removevar` or `ics:removessvar`. This may seem like waste of line of code but let me give you one example of its use. Suppose, you are looping through list of assets and retrieving their attributes and setting in HashMap, we can make use of one variable to assign that value and remove its variable after putting in Map for the next data to be set. Eg: If we have list of username set in Map with no values and you want their ages to be set in values, so rather than calling a particular template repeatedly, its better to use loop. For eg:                                                                         
```jsp
<%
   for(Entry<String,String> entry: userMap.entrySet()) { 
      %><render:callelement elementname='GetAge' scoped="global" >                                               
          <render:argument name="name" value='<%= entry.getKey() %>'/>
      </render:callelement><%  
      if(Utilities.goodString(ics.GetVar("age"))){
        userMap.put(entry.getKey(),ics.GetVar("age"));} ics.RemoveVar("age");
      }
      ...
    }
%>
```

10. Use CatalogManager tags wisely, they have ability to delete/edit database tables.

11. Passing arguments: Developers often tend to forget to include the arguments in cache criteria, when we pass any argument to call other template from current template. 

12. Passing multiple values: Pass as comma separated values as one string while passing through arguments in tags. Less arguments - less dependencies. Avoid large number of arguments as possible.

13. Use tags for date formatting, decimals, currency and string provided by Fatwire rather than using Java classes.

14. You might use same variable in one template, either remove that variable after its use or use the variable as - `Variables.assettype:fieldname`

15. Use `ics.RegisterList("IList Name",null)` to de-register the list which would avoid any clashing between two lists on same page with same name.

16. Sometimes, we require asset name, page name or their asset ids which are not associated with our assets or page and hence, these can not be generated on template or CSElement dynamically. For eg: Suppose you want to load homepage on your template for generating siteplan, so you end up using asset:load to load the page either with its name or id, which is again hardcoding values. So to avoid that, use "Map" functionality in CSElement or Template where you can provide key-value and bind the page asset with template, ensuring intended asset is called dynamically. Use `render:lookup` tag for this.

17. Variables: GLOBAL vs LOCAL - Global variables (including reserved variables) have more precedence than Local variables. For e.g. "site" variable which is present in URL act as Global variable. So suppose you want to pass site names to some particular element to get some value and if you are using variable - "site", you are in trouble because using "site" variable will provide you same value which is present in URL in the calling template.

18. Try to minimize loading of assets. For e.g. Rather than using `asset:load` tag and then using `asset:children` tag to get association, don't use asset:load. You can directly load association by providing asset id and asset type info to `<asset:children>` tag (Check how in tag reference)

19. If you want to know metadata attributes of flex or basic asset, use <asset:load> and `<asset:scatter>` tag. `<asset:scatter>` tag has ability to scatter all the metadata attributes of the loaded asset using `asset:load` tag.

### Reference

[fatwiredev blogspot](https://fatwiredev.blogspot.in/2013/11/example-11-basic-guidelines-for-using.html)