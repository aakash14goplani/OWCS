Oracle WebCenter Sites provides us with few tools that will be useful in our day-to-day activities as a developer like managing the page cache, asset cache, viewing logs, etc.

_The **System Tools** node on the Admin tab provides a range of diagnostic utilities that general administrators can use to troubleshoot directly from the WebCenter Sites administrator’s interface. Features include configuring log4j loggers, accessing various types of system information, managing caches, searching the contents of the WebCenter Sites log, and testing the performance of the shared file system._

One can find the **SYSTEM TOOLS** as follows in Oracle WebCenter Sites:

1. Log into the Admin UI of Oracle WebCenter Sites.
2. Go to ADMIN Tab in the tree.
3. You will find a node called SYSTEM TOOLS at the bottom of the available nodes.

Double click on the SYSTEM TOOLS node to explore the various options provided by Oracle WebCenter Sites. Below screenshots shows the System Tools in Admin Tab.

 ![SYSTEM TOOLS 1](https://github.com/aakash14goplani/OWCS/blob/master/images/system_tools_1.png)
 
# System Information Tool

The System Information tool provides access to various information like WCS information, database information, and thread information for troubleshooting and checking the health of your application.

We can either view information directly in the admin interface or download information to a file.

This tool consists of the following options:

1. Sites Info
2. DB Info
3. Thread Info

### Sites Info Node:

This node provides us the following facilities:

1. Memory Information: This has the info about Total memory, free memory, etc.
2. Option to download the WCS Property files like the .ini files
3. Option to download the Webapp property files like the .properties, .xml files
4. Info about Jar files available in Web-Inf/Lib folder
5. Info about Session variables
6. Info about System variables

 ![sites information](https://github.com/aakash14goplani/OWCS/blob/master/images/system_tools_2.png)

### DB Info Node:

This node provides us with the following information.

1. Database Server Information
2. JDBC Driver Info
3. JDBC Driver Url
4. JDBC Version
5. JNDI Data Source
6. Information about System Tables
7. Information about Tree Tables
8. Information about Object Tables
9. Information about Other Tables

 ![database info](https://github.com/aakash14goplani/OWCS/blob/master/images/system_tools_3.png)
 
### Thread Info Node:

You can download or view thread dumps to analyze the runtime state of the application server. This can be especially useful when trying to detect problems that might result in resource starvation or thread hangs.

 ![thread info](https://github.com/aakash14goplani/OWCS/blob/master/images/system_tools_4.png)

# Log Viewer Tool

This is one of the SYSTEM TOOLS. This tool enables you to view, tail, download, and search the contents of the **WebCenter Sites logs** directly from the WebCenter Sites administrator’s interface.

The options available in this tool are pretty simple, and can be understood upon viewing it. Hence, I’m not going to explain much about it. Below is the screenshot of the tool from Admin UI.

 ![log](https://github.com/aakash14goplani/OWCS/blob/master/images/system_tools_5.png)

By default, it displays upto 100 lines of the log file. We can change it as per our wish upto 100o lines.

Alternatively, instead of going to this utility, we can directly use the following url to view the log file. The maximum number of lines to be displayed can be entered at the end of the url.

`http://localhost:8080/cs/ContentServer?pagename=fatwire/systemtools/logs/logTailViewer&pageSize=100`

Replace the **localhost** with your server name, and **9080** with your port number.
 
 
 ### References
 
 [kksays - 1](https://kksays.wordpress.com/2014/01/27/system-tools-in-oracle-webcenter-sites/)   
 [kksays - 2](https://kksays.wordpress.com/2014/01/27/system-tools-in-oracle-webcenter-sites-part-2/)   
 [kksays - 3](https://kksays.wordpress.com/2014/01/27/system-tools-in-oracle-webcenter-sites-part-3/)