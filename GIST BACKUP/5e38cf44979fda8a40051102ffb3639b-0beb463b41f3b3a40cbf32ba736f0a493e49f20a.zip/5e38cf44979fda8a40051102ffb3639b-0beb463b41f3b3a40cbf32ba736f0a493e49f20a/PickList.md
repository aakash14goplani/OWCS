# Creating a PickList and PickList Category

A picklist allows to dynamically update options in select statements. This is easily achieved using `picklists`.   


1. The first step involved is to create the PickList category, this is non-intuitively available in New Picklists for attribute editors option.  You enter the name of the category you wish to create, and match this with the value that will appear in the picklist. Select save to finish.   

2. The second step is to enter the initial values that will be held by the picklist category you created in step 1.  You return to New Picklists for attribute editors and enter the name of the first value you wish to add.  Follow this up with the value both of these options are mandatory and so marked with `*`.  The final step is to assign it to the category you created in the step 1.  This is entitled picklist for the value to be included in.  You can repeat this for each value you want to add. This table can be found in `Content Server Explorer Tables > ElementCatalog > picklist`.  Here you can see all options available and quickly edit and save the values associate with the names you created.   
  

# Using PickList for HTML select

This allows users to retrieve the values for their HTML `<select>` option boxes from the database using a tag.  This tag `asset:list` allows the user to specify the attributes and it returns them in a list that can then be iterated as in the example below. The list can also be ordered using the order attribute of the tag.   


The type attributes of `asset:list` will need to be changed to match your type as this tells that we are looking for a picklist (which is the type has been define in our example but may be different in you project).  The list is the name of your output. The pubid does not need to change this gets the site id.  The `excludevoided` can be true or false.  If `excludevoided` is set to true then no voided(deleted) results will be returned, if set to false then all attributes will be returned.  The value1 attribute is the name of the picklist. order dictates under which column to order the results.

This can then be output in a standard `ics:listloop`.

```jsp
<asset:list type="picklists" list="resultsList" pubid="<%=ics.GetVar("site")%>" excludevoided="true" field1="picklisttype" value1="YOUR LIST NAME HERE" order="picklistvalue"/>
 
<ics:listloop listname="resultsList">
	<ics:listget listname="resultsList" fieldname="picklistvalue" output="optionValue"/>
	<option><%=ics.GetVar("optionValue")%></option>
</ics:listloop>
```  

# Output HTML or XHTML Compliant Images

There are only two edits necessary to make this work firstly you need to change the <%=ics.GetVar("Image")%> in the render:getbloburl tag to get the variable holding your image list output. The same is necessary for the ImageAltText in the alt attribute of the <img> tag.
Note:

HTML 4.01 compliance there is no / at the end of the <img> tag.
XHTML 1.x compliance there is a / at the end of the <img tag.
It is necessary to have an alt attribute in either case. If the image is a graph/map etc then it is also advised to have a longdesc attribute which is a URL to a page describing the Image in detail.

```jsp
<render:getbloburl outstr="SRC_URL" blobtable="MungoBlobs" blobkey="id" blobcol="urldata" 
	blobwhere="<%=ics.GetVar("Image")%>" blobnocache="false" />
 
<%-- HTML 4.01 no closing / --%>
<img src="<%=ics.GetVar("SRC_URL").replaceAll("&","&amp;")%>" 
	alt="<%=ics.GetVar("ImageAltText")%>"
	class="infoicons">
 
<%-- XHTML 1.0 with closing / --%>
<img src="<%=ics.GetVar("SRC_URL").replaceAll("&","&amp;")%>" 
	alt="<%=ics.GetVar("ImageAltText")%>" 
	class="infoicons" />   
```
	
https://gist.github.com/aakash14goplani/0b479f9102cbfb51952a375f89293838#get-the-attributes-of-an-asset-dynamically   

https://gist.github.com/aakash14goplani/c2971d2d75914509f05d7f5a54f24257   

https://gist.github.com/aakash14goplani/5794f88b07faf08bfcb55cd3f1d7d640   

https://gist.github.com/aakash14goplani/bcd5f2ce7d73a8ad765af36ea8ab7097   
