Webcenter Sites can cache entire web pages or components/pagelets that make the webpages. An efficient Webcenter Sites caching strategy improves system performance by reducing load on server. Webcenter Sites Caching mechanism stores the final results of pagelet or pages after completing the execution of the logics/code in page. The content in the cached page will always be the same until it is refreshed.

Below are the two types of Caching mechanisms can be done in Webcenter Sites.

1. Content Server Caching
2. Satellite Server Caching

Webcenter Sites can also utilise both the Webcenter Sites Caching & Satellite Server Caching to create an efficient caching strategy improves system performance.

### WEBCENTER SITES CACHING / CONTENT SERVER CACHING

Webcenter Sites Caching gets the executed code from CSElements & Templates and cached the final content on disk cache in the content server. When a request come for a page/pagelet, System checks for the content in Webcenter Sites Cache. If the content is already cached then it serves the result. If it is not cached, it requests the content server for the page and adds the result to cache and serves back to the user. It calculate the expiration time for the page and stores in the etime column of **SystemPageCache** table. The time is calculated based on the cscacheinfo column of **SiteCatalog** table.

The expiration of cached page/pagelets is time based and governed by properties defined in `futuretense.ini` file.
SiteCatalog tables, it has two columns
a. **cscacheinfo** – webcenter sites servlet
b. **sscacheinfo** – satellite server servlet

#### WebCenter Sites Page Caching Properties
The following properties in futuretense.ini control disk caching on WebCenter Sites:

* **cs.pgCacheTimeout**, which specifies the default timeout for pages in the WebCenter Sites cache. The default value is 0
* **cs.freezeCache**, which controls whether the cache pruning thread should run to remove expired entries from the cache. The default value is no
* **cs.nocache**, which disables the entire WebCenter Sites page cache. The default value is false
* **cc.SystemPageCacheTimeout**, which specifies the number of minutes a cached page is held in memory. The default value is 1440
* **cs.alwaysUseDisk**, which specifies the default behavior for page entries in the SiteCatalog that have no cache override property specified. It is not configured by default.
* **cc.SystemPageCacheCSz**, which specifies the maximum number of pages that can be cached in memory. The default value is 10000

### SATELLITE SERVER CACHING
Satellite Server Caching provides a second level of caching for Webcenter Sites System. Satellite Server improves website’s performance by reducing the load on WebCenter Sites and moving content closer to the website visitors who will view it. Satellite Server caches pages, pagelets & blobs to disk or memory.

Satellite Server can be configured in the following ways
1. **Co-Resident**
By default the Webcenter Sites comes up with a Satellite server which is installed and configured in the same machine. Means it is local satellite server. The co-resident satellite server is meant for development & management systems those delivers the pages on the production system(live environment).

   Co-resident Satellite Server provides a layer of caching in addition to that provided by the WebCenter Sites cache. Satellite Server and the WebCenter Sites caches work in tandem to provide double-buffered caching, where copies of cached pages are stored in both the Satellite Server and the WebCenter Sites caches. The disadvantage of this configuration is increased memory utilization, as there are now two copies of each object stored in memory.

2. **Remote Server**
It is recommended that to have a remote satellite server for active/production systems. Remote servers installed in a separate machine & configured to the Webcenter Sites which lies in another machine. It caches small items to memory & large items to disk. We can control this small & large definitions by file_size property.

Satellite Server has two sets of properties (given in detail in the Oracle WebCenter Sites Property Files Reference):

One set of properties is in the futuretense.ini file on your WebCenter Sites system and includes the following:
* **satellite.page.cachecontrol.default**, a deprecated property that specifies a default value for the cachecontrol parameter for the `satellite.page`, and `RENDER.SATELLITEPAGE` tags and their JSP equivalents.
* **satellite.blob.cachecontrol.default**, which specifies a default value for the cachecontrol parameter for the `satellite.blob`, and `RENDER.SATELLITEBLOB` tags and their JSP equivalents.

The other set of properties is in the `satellite.properties` file on each Satellite Server host and comprises the following:
* **cache_folder**, which specifies the directory into which Satellite Server will cache pagelets to disk.
* **file_size**, which separates disk-cached pagelets and blobs from memory-cached pagelets and blobs according to the size that you specify.
* **expiration**, which sets the default value for the length of time blobs stay in Satellite Server’s cache.
* **cache_check_interval**, which controls the frequency of the cache cleaner thread, and therefore when expired objects are pruned from cache.
* **cache_max**, which specifies the maximum number of objects (pagelets and blobs) that can be cached (memory cache and disk cache combined) at a time.

#### Check the contents cached in satellite server
The inventory servlet allows us to view the various items stored in the cache. Use the below link to invoke the servlet: `http://localhost:9080/cs/Inventory?username=fwadmin&password=xceladmin`