Purpose of this topic is to send email notfications to the users tat have created the assets but haven't modified them since last 30 days.   

We can use `javax mail` service or `send:mail` tag to achieve this purpose.   

Before we begin we need to make following changes to `futuretense.ini` file   

    futuretense.ini:cs.emailauthenticator=com.openmarket.framework.mail.ICSAuthenticator
    futuretense.ini:cs.emailcontenttype=
    futuretense.ini:cs.emailhost=smtp.gmail.com\:587
    futuretense.ini:cs.emailaccount=
    futuretense.ini:cs.emailpassword=
    futuretense.ini:cs.emailcharset=
    futuretense.ini:cs.emailreturnto=
    xcelerate.emailnotification=true
    xcelerate.emailattr=mail   
    
### Demo Code    

```jsp
<%@page import="java.util.Calendar"%>
<%@page import="java.util.Locale"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>

<%@page import="javax.mail.Message"%>
<%@page import="javax.mail.Session"%>
<%@page import="javax.mail.Transport"%>
<%@page import="javax.mail.internet.InternetAddress"%>
<%@page import="javax.mail.internet.MimeMessage"%>
<%@page import="java.util.Properties"%>
<%@page import="javax.mail.Multipart"%>
<%@page import="javax.mail.internet.MimeBodyPart"%>
<%@page import="javax.mail.internet.MimeMessage"%>
<%@page import="javax.mail.internet.MimeMultipart"%>

<%@ page import="COM.FutureTense.Interfaces.*"%>
<%@ taglib prefix="cs" uri="futuretense_cs/ftcs1_0.tld"%>
<%@ taglib prefix="ics" uri="futuretense_cs/ics.tld"%>
<%@ taglib prefix="render" uri="futuretense_cs/render.tld"%>
<% 
/******************************************************************************************************************************
   *    Element Name        :  	EmailNotification 
   *    Author              :  	Aakash Goplani 
   *    Creation Date       :  	(03/06/2017) 
   *    Description         :  	Element to send email notification to the users that have created assets but not have 
   *   							updated	them for 30 days or more.
   *    Input Parameters    :  	Variables required by this Element 
   *                            1. for_site (Name of site)
   *    Output              :  	Email notification to users who fail to update assets for period of days greater than 30
   *	Guidelines			:	1. Using site name (for_site) fetch publication id of site from Publication table
   *							2. Select all the asset_types from AssetPublication using publication id from step 1.
   *							3. Loop through each asset_type table and fetch its meta data.
   *							4. if last update date is greater than 30 days then:
   *								a. fetch the id of user from SystemUsers table
   *								b. using id fetch mail of user from SystemUserAttr table
   *								c. Send the mail to user
 *****************************************************************************************************************************/
%>
<cs:ftcs>
	<%-- Record dependencies for the SiteEntry and the CSElement --%>
	<ics:if condition='<%=ics.GetVar("seid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("seid")%>' c="SiteEntry" />
		</ics:then>
	</ics:if>
	<ics:if condition='<%=ics.GetVar("eid") != null%>'>
		<ics:then>
			<render:logdep cid='<%=ics.GetVar("eid")%>' c="CSElement" />
		</ics:then>
	</ics:if>
<%
	String currentSite = ics.GetVar("for_site");
	if(Utilities.goodString(currentSite)){
		String fetch_pubid = "select id from publication where name = '" + currentSite + "'";
%>
		<ics:sql table="Publication" listname="getPubidList" sql='<%=fetch_pubid %>' />
	 	<ics:if condition='<%=ics.GetList("getPubidList") !=null && ics.GetList("getPubidList").hasData()%>'>
			<ics:then>
				<ics:listget listname="getPubidList" fieldname="id" output="pubid"/>
			</ics:then>
			<ics:else>
				<ics:logmsg msg='<%="Cannot loop list getPubidList : " + fetch_pubid %>'/>
			</ics:else>
		</ics:if>
	<%
		String fetch_asset_types = "select distinct assettype from AssetPublication where pubid=" + ics.GetVar("pubid");
	%>
	 	<ics:sql table="AssetPublication" listname="assetTypeList" sql='<%=fetch_asset_types %>' />
	 	<ics:if condition='<%=ics.GetList("assetTypeList") !=null && ics.GetList("assetTypeList").hasData()%>'>
			<ics:then>
				<ics:setvar name="count" value="0"/>
				<ics:setvar name="emailFrom" value="some.username@gmail.com"/>
				<ics:setvar name="emailPassword" value="**********"/>
				<ics:listloop listname="assetTypeList">
					<ics:listget listname="assetTypeList" fieldname="assettype" output="assettype"/>
					<%
						String assetType = ics.GetVar("assettype");
						if(Utilities.goodString(assetType)){
							String fetch_asset_details = "select id, createdby, createddate, updatedby, updateddate, name from " + assetType + " where status != 'VO'";
					%>
							<ics:sql table='<%=assetType %>' listname="assetList" sql='<%=fetch_asset_details %>' />
							<ics:if condition='<%=ics.GetList("assetList") !=null && ics.GetList("assetList").hasData()%>'>
					 			<ics:then>
					 				<ics:listloop listname="assetList">
					 					<ics:setvar name="count" value='<%=String.valueOf(Integer.parseInt(ics.GetVar("count")) + 1) %>'/>
					 					<ics:listget listname="assetList" fieldname="createdby" output="createdby"/>
					 					<ics:listget listname="assetList" fieldname="createddate" output="createddate"/>
					 					<ics:listget listname="assetList" fieldname="updatedby" output="updatedby"/>
					 					<ics:listget listname="assetList" fieldname="updateddate" output="updateddate"/>
					 					<ics:listget listname="assetList" fieldname="name" output="name"/>
					 					<ics:listget listname="assetList" fieldname="id" output="assetId"/>
					 					<%
				 							String content = "createdby : " + ics.GetVar("createdby") + "<br/>" + 
				 											 "createddate : " + ics.GetVar("createddate") + "<br/>" + 
				 											 "updatedby : " + ics.GetVar("updatedby") + "<br/>" + 
				 											 "updateddate : " + ics.GetVar("updateddate") + "<br/>" + 
				 											 "name : " + ics.GetVar("name") + "<br/>" + 
				 											 "assetId : " + ics.GetVar("assetId") + "<br/>" + 
				 											 "assetType : " + assetType + "<br/>";
				 							String startDate = ics.GetVar("updateddate");
											Date startDateInstance = new SimpleDateFormat("yyyy-MM-dd H:m:s.SSS", Locale.ENGLISH).parse(startDate);
										    Calendar c1 = Calendar.getInstance();
										    Calendar c2 = Calendar.getInstance();
										    c1.setTime(startDateInstance); 
										    
										    String endDate  = ics.ResolveVariables("CS.SQLDate");
										    Date endDateInstance = new SimpleDateFormat("yyyy-MM-dd H:m:s", Locale.ENGLISH).parse(endDate);
										    c2.setTime(endDateInstance);
										    
										    long milliseconds1 = c1.getTimeInMillis();
										    long milliseconds2 = c2.getTimeInMillis();
										    long diff = milliseconds2 - milliseconds1;
										    long diffDays = diff / (24 * 60 * 60 * 1000);
										    out.println("Time in days: " + diffDays + " days. <br/>");
										    if(diffDays > 30){
										    	try{
										    		String fetch_user_id = "select id from SystemUsers where username = '" + ics.GetVar("updatedby") + "'";
										    	%>
										    		<ics:sql table="SystemUsers" listname="systemUserIdList" sql='<%=fetch_user_id %>' />
													<ics:if condition='<%=ics.GetList("systemUserIdList") !=null && ics.GetList("systemUserIdList").hasData()%>'>
											 			<ics:then>
											 				<ics:listget fieldname="id" listname="systemUserIdList" output="userId"/> 
											 				User Id : <ics:getvar name="userId"/><br/>
											 				<% 
											 					String fetch_user_mail = "Select value from SystemUserAttr where id=" + ics.GetVar("userId") + "and name='mail'";
											 				%>
											 				<ics:sql table="SystemUserAttr" listname="systemUserMailList" sql='<%=fetch_user_mail %>' />
															<ics:if condition='<%=ics.GetList("systemUserMailList") !=null && ics.GetList("systemUserMailList").hasData()%>'>
													 			<ics:then>
													 				<ics:listget fieldname="value" listname="systemUserMailList" output="emailTo"/> 
													 				User Mail : <ics:getvar name="emailTo"/><br/>
													 			</ics:then>
													 		</ics:if>
											 			</ics:then>
											 		</ics:if>
										    	<%
													String username = ics.GetVar("emailFrom");;
													String password = ics.GetVar("emailPassword");;
													String sendTo = ics.GetVar("emailTo");
													String subject = "[IMPORTANT] Please review your Asset with type : " + assetType + " and id : " + ics.GetVar("assetId");
													String body = "Dear " + ics.GetVar("updatedby") + ",<br/><br/> In our database we have following records" + 
													" for the <b>assets you have created but not updated for more than 30 days</b> <br/>" + content + 
													" <br/><b>Please update the assets within a week else they will be auto deleted from system!</b><br/><br/> " + 
													" Thanks, <br/> Aakash Goplani";
													out.println("Subject : " + subject + "<br/> Body : <br/>" + body + "<br/>");
												
													Properties props = System.getProperties();
													props.put("mail.smtp.starttls.enable", "true");
													props.put("mail.smtp.host", "smtp.gmail.com");
													props.put("mail.smtp.user", username);
													props.put("mail.smtp.password", password);
													props.put("mail.smtp.port", "587");
													props.put("mail.smtp.auth", "true");
													
													Session session1 = Session.getDefaultInstance(props, null);
														
													MimeMessage message = new MimeMessage(session1);
													message.setFrom(new InternetAddress(username));
													InternetAddress[] toAddresses = { new InternetAddress(sendTo) };
											        message.addRecipients(Message.RecipientType.TO, toAddresses);
													message.setSubject(subject,"UTF-8");
													message.setSentDate(new Date());
													Multipart mp = new MimeMultipart();
													MimeBodyPart htmlPart = new MimeBodyPart();
													htmlPart.setContent(body, "text/html; charset=utf-8");
													mp.addBodyPart(htmlPart);
													message.setContent(mp);
													
													Transport t = session1.getTransport("smtp");
											        t.connect("smtp.gmail.com", 587, username, password);
											        message.saveChanges();
											        t.sendMessage(message, message.getAllRecipients());
											        t.close();
											        
													out.println("Email successfully send to : " + sendTo);
												}catch (Exception e) {
													out.println("Exception Occured : " + e.getMessage() + "<br/><br/>" + e + "<br/><br/>" + e.getStackTrace());
												}
										    }
					 					%>
					 					<br/><br/>
					 					<ics:removevar name="createdby"/>
										<ics:removevar name="createddate"/>
										<ics:removevar name="updatedby"/>
										<ics:removevar name="updateddate"/>
										<ics:removevar name="name"/>
										<ics:removevar name="assetId"/>
										<ics:removevar name="emailTo"/>
					 				</ics:listloop>
					 			</ics:then>
					 			<ics:else>
					 				<ics:logmsg msg='<%="Cannot loop list assetList : " + fetch_asset_details %>'/>
					 			</ics:else>
					 		</ics:if>							
					 <%
					 	}
					 %>
					 <ics:removevar name="assettype"/>
				</ics:listloop>
				<ics:removevar name="pubid"/>
			</ics:then>
			<ics:else>
				<ics:logmsg msg='<%="Cannot loop list assetTypeList : " + fetch_asset_types %>'/>
			</ics:else>
		</ics:if>
		Total Assets : <ics:getvar name="count"/> <br/><br/>
		<ics:removevar name="count"/>		 	
<%	
	}	
%>		
</cs:ftcs>
```