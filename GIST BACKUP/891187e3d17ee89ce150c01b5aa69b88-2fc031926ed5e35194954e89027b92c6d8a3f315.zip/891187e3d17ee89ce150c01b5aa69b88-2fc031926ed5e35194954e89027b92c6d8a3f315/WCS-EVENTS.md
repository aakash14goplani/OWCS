Working with Publish Events in WebCenter Sites – Part 1

Sometimes it’s useful to perform an action in response to a WebCenter Sites publishing event. Good use cases include archiving and audit.

This tutorial, which is the first of a two-parter, will help you to understand what’s available to you as a developer for listening and responding to Publish Events.


webcenter-sites-publish-events

Getting Started

To start with you’ll need the following installed:

Two local instances of WCS
Eclipse
Maven
The two instances of WebCenter Sites should be running on different ports. They should have some content in them (avisports for example) and the first should be set up so that the delivery destination is set to the host and port of the second. You’ll also need a copy of eclipse which is capable of running a Maven build.

An Introduction to PublishEvents

In essence publish events are fairly simple to work with.

Firstly we have an interface that we need to implement to create an Event Listener.

PublishEventListener requires we implement one method called onEvent. This method receives an object that conforms the interface PublishingEvent.

PublishingEvent has the following methods described:

getPubSessionId() – this helps us to identify which publish the event refers to
getMessage() – returns a message describing the event
getStatus() – returns one of the predefined publish status as described in the enum PublishingStatusEnum
getTaskName() – returns one the predefined publish tasks as described in the enum RealTimeConstants.PublishingTasks
Publishing Tasks

The tasks in RealTimeConstants.PublishingTasks map broadly to the standard phases of RealTime publishing and can be described as follow

Task	Description
SESSION	The session task describes the overall publish. If you want to know when everything has started or finished this is the task to look for
GATHERER	The gatherer task is the process of getting the list of all the assets that will need to be published
PACKAGER	The package task serialises the publish candidates and groups them into logical units
TRANSPORTER	The transporter task physically moves the logical units of data from the editorial server to the delivery server
UNPACKER	The unpacker takes the freshly delivered units of data and deserialises them and then saves them to the delivery database
CACHEUPDATER	Finally the cache updater determines which of the delivery server caches have dependencies on the resources published in this session and updates them accordingly
Publish Tasks Status

The statuses in in the PublishStatusEnum can be described as follows

Status	Description
STARTED:	Indicates that the current task has started
SUBTASK_FINISHED:	Indicates that subtask of the current task has finished
DONE:	Indicates that the current task has completed – and by inference was successful
CANCELLED:	Indicates that the current task was cancelled by a user
FAILED:	Indicates that the current task has failed
Creating a project

With all of that in mind lets get a simple project setup with a sample PublishEventListener that allows us to view all the events that are fired during a RealTime publish. At this point you can either clone the sample project from our GitHub repo or you can follow along and build it from scratch.

To start with we need to create a simple maven project with a POM similar to this

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>uk.co.manifesto.wcs</groupId>
  <artifactId>publish-events</artifactId>
  <version>0.0.1-SNAPSHOT</version>
  <packaging>jar</packaging>

  <name>publish-events-part1</name>
  <url>http://maven.apache.org</url>

  <properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
  </properties>

  <dependencies>
    <!--  sites -->
    <dependency>
        <groupId>com.fatwire.cs</groupId>
        <artifactId>xcelerate</artifactId>
        <version>11.1.1.8.0</version>   
    </dependency>
    <dependency>
        <groupId>com.fatwire.cs</groupId>
        <artifactId>cs-core</artifactId>
        <version>11.1.1.8.0</version>   
    </dependency>
    <!-- logging -->
    <dependency>
        <groupId>commons-logging</groupId>
        <artifactId>commons-logging</artifactId>
        <version>1.1.1</version>
        <scope>provided</scope>
    </dependency>           
    <!-- test -->
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.10</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
  <build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-compiler-plugin</artifactId>
            <version>2.0.2</version>
            <configuration>
                <source>1.6</source>
                <target>1.6</target>
            </configuration>
        </plugin> 
    </plugins>
  </build>
</project>
We only need two WebCenter Sites jars to build our PublishEventListener class and you can add them to your local maven repository by running these maven commands from within the WEB-INF/lib directory of the cs web application:

mvn install:install-file -Dfile=xcelerate.jar -DgroupId=com.fatwire.cs -DartifactId=xcelerate -Dversion=11.1.1.8.0 -Dpackaging=jar -DgeneratePom=true
mvn install:install-file -Dfile=cs-core.jar -DgroupId=com.fatwire.cs -DartifactId=cs-core -Dversion=11.1.1.8.0 -Dpackaging=jar -DgeneratePom=true
Then we’re going to create a simple class that implements the PublishEventListener interface. My sample class isn’t very complicated at all – it simply listens to all the publish events and dumps information about them to the sites.log

package uk.co.manifesto.wcs.publishevents;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fatwire.cs.core.event.EventException;
import com.fatwire.realtime.event.PublishingEvent;
import com.fatwire.realtime.event.PublishingEventListener;

public class PublishListener implements PublishingEventListener {

    private static final Log log = LogFactory.getLog(ExportListener.class);

    public void onEvent( PublishingEvent event ) throws EventException {
        log.info(String.format("Publish task: %s",event.getTaskName()));
        log.info(String.format("Publish status: %s",event.getStatus()));
        log.info(String.format("Publish message: %s",event.getMessage()));
    }

}
Now we need to compile our project and deploy register the listener.

Running mvn clean package will produce us a jar file that we can then deploy to the lib directory of the cs webapp.

Finally we need to register our listener. You can use the exported table in the eclipse project if you want and import that with catalogmover or you can create an entry in the table FW_PublishingEventRegistry with the following data:

id: <LetWCSAutoGenerate>
location: uk.co.manifesto.wcs.publishevents.PublishListener (or whatever the fully qualified name of your class is)  
blocking: Y
The blocking parameter determines whether your listener runs in the same thread as the publish itself.

Once the listener is registered we need to test it. Let’s do this by running a publish from system one.

Find an asset an approve it for publish to the delivery destination. The go to the admin tab, select Publishing from the menu and then select the Delivery destination. You should see at least one asset ready to publish.

Click the publish button and wait for the publish to finish. You will be able to test whether it was successful by looking at the history tab.

If everything went well you should have a look at the sites log ${sitesInstallDir}/logs/sites.log where you’ll see some output similar to this:

[2013-11-07 17:25:15,425 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: SESSION
[2013-11-07 17:25:15,425 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: STARTED
[2013-11-07 17:25:15,425 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: publishing started for pubsession 1374098078090
[2013-11-07 17:25:15,427 UTC] [INFO ] [http-bio-9080-exec-1] [logging.cs.xcelerate.publish] Starting RealTime publish session 1374098078090
[2013-11-07 17:25:16,701 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: GATHERER
[2013-11-07 17:25:16,701 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: STARTED
[2013-11-07 17:25:16,701 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: Gatherer started for pubsession 1374098078090 with gatherer: com.fatwire.realtime.DataGathererImpl
[2013-11-07 17:25:16,835 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: GATHERER
[2013-11-07 17:25:16,835 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: SUBTASK_FINISHED
[2013-11-07 17:25:16,835 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: Gatherer finished for pubsession 1374098078090 with gatherer: com.fatwire.realtime.DataGathererImpl
[2013-11-07 17:25:16,845 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: PACKAGER
[2013-11-07 17:25:16,845 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: STARTED
[2013-11-07 17:25:16,845 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: Start Packaging
[2013-11-07 17:25:18,030 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: PACKAGER
[2013-11-07 17:25:18,030 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: SUBTASK_FINISHED
[2013-11-07 17:25:18,030 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: All the resources have been packaged
[2013-11-07 17:25:18,083 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: TRANSPORTER
[2013-11-07 17:25:18,083 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: STARTED
[2013-11-07 17:25:18,083 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: Transportating started for pubsession 1374098078090 with Transporter: com.fatwire.realtime.MirrorBasedTransporterImpl
[2013-11-07 17:25:18,885 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: TRANSPORTER
[2013-11-07 17:25:18,886 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: SUBTASK_FINISHED
[2013-11-07 17:25:18,886 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: Transportating finished for pubsession 1374098078090 with Transporter: com.fatwire.realtime.MirrorBasedTransporterImpl
[2013-11-07 17:25:34,271 UTC] [INFO ] [http-bio-9080-exec-1] [logging.cs.xcelerate.publish] Completed RealTime publish session 1374098078090
[2013-11-07 17:25:34,276 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish task: SESSION
[2013-11-07 17:25:34,276 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish status: DONE
[2013-11-07 17:25:34,276 UTC] [INFO ] [http-bio-9080-exec-1] [manifesto.wcs.publishevents.PublishListener] Publish message: publishing finished for pubsession 1374098078090
If you see your output in the log, congratulations you’ve successfully written and deployed your first PublishEventListener.

Stay tuned for part two of this series where I’ll show you how to audit the assets delivered with each publish.   

https://manifesto.co.uk/publish-events-webcenter-sites-part-1/   

------------------------------------------------------------------------------------  

Working with Publish Events in WebCenter Sites – Part 2   

This is the second part of our introduction to PublishEventListeners in WebCenter Sites. The first part was published in December so if you need to refresh your memory take a look here.


PUBLISH-EVENTS

This time we’re going to something a bit more useful with our event listener. We’re going to have a look at how we get a list of the assets published for each publish session and write them into a file. This could be useful from an audit or archive perspective as once we’ve got a handle on the asset in code we can do all sorts of things with it.

We can start by utilising the project we created for part one. Next we need to add a few new dependencies to our POM.

These two are WCS supplied jars:

<dependency>
    <groupId>com.fatwire.cs</groupId>
    <artifactId>assetapi</artifactId>
    <version>11.1.1.8.0</version>   
</dependency>   

<dependency>
    <groupId>com.fatwire.cs</groupId>
    <artifactId>cs</artifactId>
    <version>11.1.1.8.0</version>   
</dependency>

<dependency>
  <groupId>com.fatwire.gst</groupId>
  <artifactId>gst-foundation-all</artifactId>
  <version>11.6.1</version>
</dependency>
So we can install them to our local respository in the same way as before:

mvn install:install-file -Dfile=cs.jar -DgroupId=com.fatwire.cs -DartifactId=cs -Dversion=11.1.1.8.0 -Dpackaging=jar -DgeneratePom=true
mvn install:install-file -Dfile=assetapi.jar -DgroupId=com.fatwire.cs -DartifactId=assetapi -Dversion=11.1.1.8.0 -Dpackaging=jar -DgeneratePom=true
The third is the GST foundation project. This dependency isn’t strictly necessary but it does make working with WCS a bunch easier.

The download can be found here.

We’ll talk more about the GSF in another post. For now just install it to your maven repository as with the others:

mvn install:install-file -Dfile=gst-foundation-all-11.6.1.jar -DgroupId=com.fatwire.gst -DartifactId=gst-foundation-all -Dversion=11.6.1 -Dpackaging=jar -DgeneratePom=true
We now have two main tasks to complete.

The first is to amend our PublishEventListener so that instead of just logging information about the publish events it does something with particular events. In our case we want to listen out for events related to the publish session (SESSION) and only act once it has completed (DONE).
The second task involves getting a list of the assets published in the current session and noting them in a file.
To start we create a method that looks like this:

private boolean isPublishSessionComplete(PublishingEvent event) {
    return event.getTaskName().equals(SESSION) && event.getStatus().equals(DONE);
}
This method will return true when the event captured is related to the publish session (SESSION) and when that task has been completed.

Next we have a couple of methods to help us write our log file. For convenience we’re reusing the filesystem location that CSDT uses to output it’s exports.

private File getPublishSessionLogFile(PublishingEvent event, ICS ics) {
    String exportLocation = ics.GetProperty("cs.csdtfolder") + "/publish";
    makeSureFolderExists(exportLocation);
    File file = new File(String.format("%s/pub-session-%s.txt",exportLocation, event.getPubSessionId()));
    return file;
}

private void makeSureFolderExists(String exportLocation) {
    File dir = new File(exportLocation);
    if (!dir.exists()) {
        dir.mkdirs();
    }
}
and then a method to help us write out a file containing a list of asset published messages.

private void writePublishedAssetsToFile(PublishSession pubSession, File file) throws IOException {
    PrintWriter publishedAssetsWriter = new PrintWriter(new FileWriter(file));
    for (AssetId assetId : pubSession.getPublishedAssets()) {
        publishedAssetsWriter.println(String.format("Published asset: %s", assetId.toString()));
    }
    publishedAssetsWriter.close();
}
This method includes a new class that we need to write called PublishSession.

This class is a wrapper around two main database tables in WCS – PubSession and PubMessage. PubSession contains a row for each publish session and PubMessage records each of the messages that your see in you publish log. We can parse the data in PubMessage to identify the assets that have been published and log them to a file.

The meat of this class is the following SQL query:

SELECT ps.id as session_id, pm.cs_text as message FROM PubSession ps, PubMessage pm WHERE ps.id=pm.cs_sessionid AND ps.id= ? AND pm.cs_type='RESOURCE'
It returns all the rows in PubMessage where the type is RESOURCE (this helps us to exclude general messages).

We then look to filter out any messages that refer to tables being saved and to filter in any messages where the string contains  ‘:’

This isn’t perfect by any means but gives you a starting point for working with PubMessage.

if (!message.startsWith("TABLE") && message.contains(":")) {
    AssetId candidate = AssetIdUtils.fromString(message);
    publishedAssets.add(candidate);
}
So altogether our listener now looks like this:

package uk.co.manifesto.wcs.publishevents;

import static com.fatwire.realtime.event.PublishingStatusEnum.DONE;
import static com.fatwire.realtime.util.RealTimeConstants.PublishingTasks.SESSION;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import uk.co.manifesto.wcs.publishevents.session.PublishSession;
import COM.FutureTense.Interfaces.ICS;

import com.fatwire.assetapi.data.AssetId;
import com.fatwire.cs.core.event.EventException;
import com.fatwire.gst.foundation.facade.ics.ICSFactory;
import com.fatwire.realtime.event.PublishingEvent;
import com.fatwire.realtime.event.PublishingEventListener;

public class PublishListener implements PublishingEventListener {

    private static final Log log = LogFactory.getLog(PublishListener.class);

    public void onEvent( PublishingEvent event ) throws EventException {
        if (isPublishSessionComplete(event)) {
            ICS ics = ICSFactory.getOrCreateICS();
            PublishSession pubSession = new PublishSession(event.getPubSessionId(), ics);
            log.info(String.format("Logging data for publish session %s", event.getPubSessionId()));
            File file = getPublishSessionLogFile(event, ics);
            log.info(String.format("Creating log file  %s", file.getAbsolutePath()));

            try {
                writePublishedAssetsToFile(pubSession, file);
            } catch (IOException e) {
                log.error(e.getLocalizedMessage());
            }
        }
    }

    private File getPublishSessionLogFile(PublishingEvent event, ICS ics) {
        String exportLocation = ics.GetProperty("cs.csdtfolder") + "/publish";
        makeSureFolderExists(exportLocation);
        File file = new File(String.format("%s/pub-session-%s.txt",exportLocation, event.getPubSessionId()));
        return file;
    }

    private void makeSureFolderExists(String exportLocation) {
        File dir = new File(exportLocation);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    private void writePublishedAssetsToFile(PublishSession pubSession, File file) throws IOException {
        PrintWriter publishedAssetsWriter = new PrintWriter(new FileWriter(file));
        for (AssetId assetId : pubSession.getPublishedAssets()) {
            publishedAssetsWriter.println(String.format("Published asset: %s", assetId.toString()));
        }
        publishedAssetsWriter.close();
    }

    private boolean isPublishSessionComplete(PublishingEvent event) {
        return event.getTaskName().equals(SESSION) && event.getStatus().equals(DONE);
    }
}
And our PubSession class looks like this:

package uk.co.manifesto.wcs.publishevents.session;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import COM.FutureTense.Interfaces.ICS;
import COM.FutureTense.Interfaces.IList;
import COM.FutureTense.Util.IterableIListWrapper;

import com.fatwire.assetapi.data.AssetId;
import com.fatwire.cs.core.db.PreparedStmt;
import com.fatwire.cs.core.db.StatementParam;
import com.fatwire.gst.foundation.facade.assetapi.AssetIdUtils;

public class PublishSession {

    private ICS ics;
    private String pubSessionId;
    private String pubSessionSql = "SELECT ps.id as session_id, pm.cs_text as message, ps.cs_sessiondate as session_startdate, ps.cs_enddate as session_enddate FROM PubSession ps, PubMessage pm WHERE ps.id=pm.cs_sessionid AND ps.id= ? AND pm.cs_type='RESOURCE'";

    public PublishSession(String pubSessionId, ICS ics) {
        this.ics = ics;
        this.pubSessionId = pubSessionId;

    }

    public List<AssetId> getPublishedAssets() {
        List<AssetId> publishedAssets = new ArrayList<AssetId>();

        PreparedStmt publishMessages = new PreparedStmt( pubSessionSql,Arrays.asList(new String[]{"PubMessage" , "PubSession"}));
        publishMessages.setElement(0, "PubSession", "id");
        StatementParam pubSessionIdParam = publishMessages.newParam();
        pubSessionIdParam.setString(0, pubSessionId);

        for (IList row : new IterableIListWrapper(ics.SQL(publishMessages, pubSessionIdParam, true))) {
             try {
                String message = row.getValue("message");
                if (!message.startsWith("TABLE") && message.contains(":")) {
                    AssetId candidate = AssetIdUtils.fromString(message);
                    publishedAssets.add(candidate);
                }   
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }
        }       
        return publishedAssets;
    }

}
Assuming that you’ve followed the instructions from part one about registering the listener we can now build and deploy our jar and run another publish.   

https://manifesto.co.uk/working-publish-events-webcenter-sites-part-2/