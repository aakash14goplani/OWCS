`asset:load` is used to load basic assets and complex assets like Page, Collection, Query etc.  

### GENERAL STEPS TO FOLLOW:

1. Load the basic asset (using `asset:load` tag)
2. Scatter the loaded basic asset (using `asset:scatter` tag) OR get the loaded basic asset (using `asset:get` tag)
3. Retrieve information after scattering the asset via `prefix:attributename` (using `ics:getvar` tag)  

## CASE 1   
If you know asset type(`c`) and asset id (`cid`). This is basically used to retrieve information from the basic asset usually to render on page.
Following example shows retrieving name after the basic asset is loaded and scattered.

```jsp
<asset:load name="anyName" type='<%=ics.GetVar("c")%>' objectid='<%=ics.GetVar("cid") %>' flushonvoid="true" /> 
<asset:scatter name="anyName" prefix="asset" /> 
<ics:getvar name="asset:attribute_name" />
```
OR
```jsp
<asset:load name="anyName" type='<%=ics.GetVar("c")%>' objectid='<%=ics.GetVar("cid")%>' flushonvoid="true" />
<asset:get name="anyName" field="attribute_name" output="outputVariable"/>
<ics:getvar name="outputVariable" />
```  

## CASE 2:   
If you know asset type, a field, value and site. This is generally used to get association using `asset:children` tag after the asset is loaded.

```jsp
<asset:load name="anyName" type='<%=ics.GetVar("c")%>' field="attribute_name" value="attribute_value" site='<%=ics.GetVar("site")%>'/>
<asset:get name="anyName" field="attribute_name" output="outputVariable"/> 
<ics:getvar name="outputVariable"/>
```   
# XML Version   
```xml
<ASSET.LOAD NAME="assetName" TYPE="assetType" OBJECTID="object.id" FLUSHONVOID="true" / >
<ASSET.SCATTER NAME="assetName" PREFIX="variablePrefix" />
<CSVAR NAME="Variables.variablePrefix:attribute_name"/>

<ASSET.LOAD NAME="assetName" TYPE="assetType" FIELD="fieldName" VALUE="fieldValue " SITE="siteName" />
<ASSET.GET NAME="assetName" FIELD="fieldName" OUTPUT="outputVariable" />
<CSVAR NAME="Variables.variablePrefix:attribute_name"/>
```   
[JSP Documentation for asset:load](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/asset-load.html)   
[XML Documentation for ASSET.LOAD](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/XML/ASSET.LOAD.html)