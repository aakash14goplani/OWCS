### What is Dynamic Publishing?

Dynamic publishing is the process of copying assets and their underlying schema from one WebCenter Sites system to another. This Dynamic Publishing is of two types.

1. **Mirror to Server:** Mirror to Server is the method used to copy database rows to remote dynamic server

2. **Real time Publishing:** Real time Publishing is the method used to copy assets to remote dynamic server.

### What is RealTimePublishing?

RealTime publishing is a dynamic publishing process. In RealTime publishing, this process is broken up into five stages. The System performs all the five steps in an order, to perform the RealTime publishing.

RealTime publishing is the preferred method for publishing. Using the RealTime user interface, an administrator can monitor the progress of a publishing session, bulk publish selected assets using the on demand queue, bulk un-approve the assets that are approved for publishing, cancel publishing process, and redo publishing sessions, etc.

#### Complete Publishing Mode:
When the destination is configured for complete publishing mode, the process proceeds without interruption.

#### Delayed Publishing Mode:
When configured for delayed publishing mode, the process pauses before the fourth step. User interaction is needed for the session to complete. It continues to stage 4 only after the administrator selects the Resume button on the “Publish Console” or “Publishing Status” screen.

As the publishing session proceeds, you can monitor the progress of each stage on the ‘Publishing Status’ screen.

### Five Stages of Publishing:

1. **Gathering data to publish:**
   * The WebCenter Sites source system locks the assets that are approved for this publishing session.  This ensures the assets that need to be published from being edited during publishing.
   * The list of assets to be published from source to destination systems are created in a file called MANIFEST. The manifest identifies the assets that must exist together on the destination to prevent broken links and incomplete pages.

2. **Serializing data:**
   * The WebCenter Sites source system mirrors the following items:
      * Asset types
      * Tables
      * Approved assets
   * The data that needs to be published to the target will be serialized at the source system (i.e, translation into binary format).

3. **Sending data to the target:**
   * The destination WebCenter Sites database locks assets that are approved for this publishing session. When assets on the target are locked, they cannot be edited.
   * The WebCenter Sites source system sends the serialized data and the manifest file to the destination.

 ![RealTime Publishing](https://github.com/aakash14goplani/OWCS/blob/master/images/realtime_publishing.png)

4. **Deserializing and saving data:**
   * The WebCenter Sites destination system de-serializes (to WebCenterSites format) the mirrored asset types, tables, and approved assets.
   * The destination system’s database updates asset types and tables with the deserialized ones, or adds them as new data.
   * The destination system uses the manifest to determine when to commit assets to its database.

5. **Updating page caches:**   
   * The destination system completes the publication process, and does the following tasks:
      + To remove the expired pages, the page cachce is flushed.
      + If any new pages are added, they are added to the cached.
   
### References

[kksays](https://kksays.wordpress.com/2013/10/23/realtime-publishing-in-oracle-webcenter-sites-fatwire/)