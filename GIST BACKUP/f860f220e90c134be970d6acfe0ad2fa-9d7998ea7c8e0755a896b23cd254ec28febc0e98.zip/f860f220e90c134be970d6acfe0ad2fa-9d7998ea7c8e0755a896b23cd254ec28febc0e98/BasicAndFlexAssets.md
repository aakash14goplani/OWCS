# Basic and Flex assets

In Fatwire, there are 2 types of custom assets: Basic Assets and Flex Assets.

Some Fatwire sites, developed ages ago, are still based on Basic Assets, but the vast majority of recent Fawire web sites are instead based on Flex Assets.

### Why Flex Assets?

Modern sites are based on Flex Assets for a reason. Flex Assets are… well, flexible. The fundamental feature of a Flex Asset is the ability to add fields at any moment. You can update your site at any time, adding new fields but keeping all the existing content. Also Flex Asset are organized in Families, so you can easily build hierarchies and render them in a treetab.

But this flexibility comes with a cost.
   * The underlying database structure of flex assets is pretty complex.
   * Attributes are not stored simply as database fields, so the underling database structure is pretty obscure.
   * Asset creation is slower that Basic assets
   * Searching attributes has some limitations and can require complex code.

That said, it is not to discourage use of Flex Assets. On the contrary, they are the best choice for almost all the common uses cases.


However, there are a few of them you can still consider the use of Basic Assets

### Why Basic Assets?

On the contrary, basic assets  do not have all this flexibility. Once created, they have a fixed structure. The normal way to upgrade them is to drop them and recreate with the new format. You can still save the content but you may require to use some database magic. But the underlying structure is simpler and straightforward.

Basically

   * for each basic asset there is a database table,
   * for each attribute there is a field in the table.
   * This property turns to be useful in many cases. So I do not consider Basic asset to be obsolete, but simply a Fatwire feature useful in certain tasks.

So far, I found basic asset to be useful for example to:

1. store user generated content: This because it is faster and simpler to create a basic asset than a flex asset

2. store legacy content: because the straightforward structure of a flex asset make easy to load the content with simple database queries