When the user enters a URL in the browser, and hits on enter, the following sequence of actions take place in order to complete the request and give the webpage as a response.

1. The Webserver / load balancer routes the HTTP request to the Satellite Server.
2. The Satellite server checks for the page in its cache.
3. If the page is found in its cache, the page is returned as response.
4. If the page is not found in its cache, the Satellite server routes the request to the Content Server.
5. The Content Server checks for the page in its cache.
6. If the page is found in its cache, the page is returned to satellite server.
7. If the page is not found in the Content Server’s cache, the page is rendered by the Content Server, and it is stored in the CS Cache. Then sends the copy of the page to the Satellite Server.
8. The Satellite server then stores the page in its cache, and returns it to the user.

### References

[kksays](https://kksays.wordpress.com/2012/11/26/handling-a-http-request-in-fatwire/)