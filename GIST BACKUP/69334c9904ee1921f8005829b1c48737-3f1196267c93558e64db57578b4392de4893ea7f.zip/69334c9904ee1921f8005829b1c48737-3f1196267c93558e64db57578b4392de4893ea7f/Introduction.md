Oracle WebCenter Sites is a high-performance, large-scale content management and delivery system. Oracle WebCenter Sites is used to create and manage large and complex websites, sites that run businesses, and other types of sites, all of which are generically referred to as "online sites" or "websites."   

When site visitors visit your website, you want them to have an interactive, personalized When site visitors visit your website, you want them to have an interactive, personalized When site visitors visit your website, you want them to have an interactive, personalized experience that keeps them loyal to your brand. You want them to access the most up-to-date experience that keeps them loyal to your brand. You want them to access the most up-to-date content relevant to their interests, navigate your pages seamlessly, and encourage them to participate in commenting and rating your content (articles, products, services, and so on).   

Site visitors neither see what is driving this interactive, personalized experience in the back end nor the WebCenter Sites and the intricacies between Sites and its supplemental offerings that enhance the user experience (UX) with your website.   

Job of WebCenter Sites developer is to create the content entry forms which contributors will then use to create the content for your website. In addition, they also develop the JSPs that render content entry forms in Web Mode as well as render published content on the website. When content is ready for public delivery, it can be published to the website using either dynamic or static publishing.      

## Oracle WebCenter Sites 11g: Product Architecture

![webcentersites-product-architecture](https://github.com/aakash14goplani/OWCS/blob/master/images/webcentersites-product-architecture.JPG)   

Explanation of Oracle WebCenter Sites 11g and its supplemental product offerings:    

1. **WebCenter Sites** 
The base application for web experience and content management.   

2. **WebCenter Sites: Community** 
Management of user-generated content, such as comments, ratings, and polling   

3. **WebCenter Sites: Gadgets**   
Management of gadgets for use on websites such as iGoogle 

4. **WebCenter Sites: Engage**   
Management of segments and strategic marketing tools   
Content Connectors For integration with other source repository systems, such as WebCenter Content, Documentum, Sharepoint, or file systems   

5. **WebCenter Sites: Analytics**   
Reporting of website content usage   

6. **Remote Satellite Server**   
Edge caching application for larger-scale deployments   


## Oracle WebCenter Sites 11g: n-TieredArchitecture   

![n-TieredArchitecture](https://github.com/aakash14goplani/OWCS/blob/master/images/n-TieredArchitecture.gif)   

The Oracle WebCenter Sites "ecosystem" consists of several different environments, each with its own Sites installation, database, and application server. At the very least, it is recommended that you have a four-tier ecosystem that comprises the following:   

1. **Development Environment:**
where functional and design specifications, and template development for the application are carefully put into place   

2. **Management Environment:**   
where content contribution workflows take place   

3. **Testing Environment:**   
where content and templates are tested   

4. **Delivery Environment:**   
where site visitors visit your public website.   

Depending on your specific needs, however, you may find yourself with more environments or name them differently and use them for different purposes.   

## Oracle WebCenter Sites 11g: Core Architecture   

![Core Architecture](https://github.com/aakash14goplani/OWCS/blob/master/images/Webcenter-Site-11g-Core-Architecture.png)   

Digging deeper into the core of the Oracle WebCenter Sites application, you can see that it consists of six major pieces:   
1. User Interfaces   
2. Application Programming Interfaces (API)   
3. Authentication, Authorization, and Single Sign-on (SSO)   
4. Asset Framework   
5. Content Services   
6. Storage   

## Data Modelling   

WebCenter Sites supports the following data models:

**WebCenter Sites basic asset model**, supports a flat data structure, which means that basic assets cannot inherit each other's properties (called attributes in this guide). Content is entered by WebCenter Sites users and is stored as objects called assets in the WebCenter Sites database. Each type of asset is contained in one primary storage table in the database, such that basic assets of one type can be associated with basic assets of another type.   

**WebCenter Sites flex asset model**, is a comprehensive data model in which each asset type uses several storage tables such that hierarchical data structures can be created, and child assets inherit attribute values from their parent assets. The flex asset model also supports flat data structures, within its own framework. (Note that the flex asset model functions independently of the basic asset model; tables created within the two models do not intersect.)   

## The main WebCenter Sites servlets are as follows:

**ContentServer**: Generates and serves pages dynamically. This servlet provides disk caching, session management, event management, searching, and personalization services.   

**CatalogManager**: Provides most of the database management for the WebCenter Sites database, including revision tracking, security, resultset caching, and publishing services.   

**TreeManager**: Manages the tree tables, which store hierarchical information about other tables in the WebCenter Sites database.   

**BlobServer**: Locates and serves binary large objects (blobs). Blobs are not processed in any way. They are served as is, as they are stored.   

**DebugServer**: Provides tools that help you debug your XML code.   

**CookieServer**: Serves cookies for WebCenter Sites pages, whether those pages are delivered by the ContentServer servlet or by the Satellite Server application.   

**HelloCS**: Displays version information about the WebCenter Sites software installed on your system.   

## WebCenter Sites Utilities

WebCenter Sites provides utilities, which are the developer's tools for managing the WebCenter Sites database and various code. The utilities are GUI-based and must be manually installed (unless otherwise noted). They are:

**Developer Tools**, which integrates WebCenter Sites with the Eclipse Integrated Development Environment (IDE). The Developer Tools kit enables WebCenter Sites developers to work in a distributed environment using tools such as Eclipse and version control system (VCS) integration.   

**Sites Explorer**, for viewing and editing tables in the WebCenter Sites database. If by any reason the Sites Explorer tool is unable to launch, you can hit the following URL: `http://localhost:9080/cs/CatalogManager?ftcmd=selectrow(s)&tablename=`      

**CatalogMover**, for exporting and importing database tables.   

**XMLPost**, for incrementally importing data into the WebCenter Sites database.   

**BulkLoader**, for quickly importing large amounts of data into the WebCenter Sites database.   

**Property Editor**, for viewing and organizing property files (system configuration files).   

## WebCenter Sites Interfaces   

1. **Admin Interface**:   
   + is designed for developers and administrators. This interface allows administrators to manage and configure WebCenter Sites.
   + The Admin interface supports code-based operations, and enables you to graphically complete the creation of basic asset types. For example, to create a basic asset type, you would:
      * Write an XML file (called asset descriptor files) to define the basic asset type.
      * Upload the file to WebCenter Sites.
      * Use the WebCenter Sites interface to invoke the AssetMaker utility. One of the functions of the interface (AssetMaker) is to read the asset descriptor file and, from it, create a storage table for the asset type. Other functions in the interface allow you to configure the asset type (for example, name its authorized users).
      * The same interface is used by administrators to create content management sites, manage system users, control their permissions to content, establish workflow processes, and configure WebCenter Sites features (such as Sites Desktop).   
      
2. **Contributor Interface**:   
   + is designed specifically for content providers and business users. The Contributor interface provides ease of use and quick access to most WebCenter Sites content management functions, such as previewing, creating, editing, deleting, and approving assets.   
   + When you work with assets in the Contributor interface, you may see fields enabled with the following WYSIWYG editors:
      * _CKEditor_ is an open source WYSIWYG text editor from CKSource which requires no client-side installation. Developers can use CKEditor to create basic assets whose text-entry fields use CKEditor as the input mechanism for the field. Developers can also create attribute editors for flex attributes that use CKEditor as the input medium.
      * _Clarkii Online Image Editor (Clarkii OIE)_ is a popular third-party image editor from InDis Baltic. Developers can enable Clarkii OIE to allow users to edit images directly in the Form Mode of the WebCenter Sites Contributor interface eliminating the need for an external image editor.   
      
3. **WEM Admin Interface** (WEM = Web Experience Management):   
   + The WEM Admin interface supports centralized application management and user authorization. 
   + Its single sign-on capability enables users to log in to WebCenter Sites and access all of the applications that they have been assigned permissions to. 
   + Administrators can accomplish the following when they log in to the WEM Admin interface:
      * Create and manage content management sites
      * Manage applications assigned to content management sites
      * Create new users and manage user authorization to the Admin, Contributor, or other applications (such as Community, Analytics, Gadgets, or Engage) for specific content management sites   
   
## WebCenter Sites : Content-Centric Content Management System.   

There are two families of Content Management Systems (CMS):   

1. **Page-Centric Content Management Systems**:   
A page-centric content management system is one in which the content displayed on a web page is tightly coupled with that web page. The web page serves as the unit of management, and the content is not necessarily reusable on other pages. Additionally, links to other web pages are typically manually defined.   

2. **Content-Centric Content Management Systems**:    
A content-centric content management system is one in which the content displayed on a web page is managed separately from the page it is displayed on. In some cases, a physical page does not exist in the system, yet the site visitor believes they are viewing a web page. In this case, the site visitor is viewing a dynamic page composed of several different pieces of content. This allows for the dynamic composition and delivery of a web page to a site visitor. In a content-centric content management system, the content items themselves are the unit of management. Links to other dynamic pages are dynamically created and managed by the system.   

_WebCenter Sites is a content-centric content management system._