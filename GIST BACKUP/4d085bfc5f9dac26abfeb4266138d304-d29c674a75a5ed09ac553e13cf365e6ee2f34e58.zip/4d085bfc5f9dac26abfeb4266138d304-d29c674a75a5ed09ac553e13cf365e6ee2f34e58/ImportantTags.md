### Content Server Context tag:
This is the tag that Creates the Content Server Context. This is the first tag , and also the last tag of the JSP or XML. What ever the code that falls between these tags, should be rendered by the content server. The Full form of FTCS tag is Future Tense Content Server tag.

**JSP Syntax:**
```jsp
<cs:ftcs>
	Content Server tags here
</cs:ftcs>
```

**XML Syntax:**
```xml
<FTCS>
  ———
</FTCS>
```

### Tag for displaying the value of a variable:
The tag for displaying the value of a variable is given below for both xml and jsp. It displays the value of a variable, session variable, built-in, etc.

JSP Syntax: `<ics:getvar name=”variableName”/>`   

XML Syntax: `<CSVAR NAME=”variableName”/>`   

**Example:**
```
String l_C =<ics:getvar name=”c”/>     // Gets the value of “c”, i.e., the asset type, and returns the value to a string variable.
String l_C = ics.GetVar(“c”);    // Similar kind of Usage in different form
```

### Tag for setting the value of a variable:
`SETVAR` is the tag for setting the value of a content server variable. The syntax is given below for both xml and jsp:

JSP Syntax: `<ics:setvar name=”variableName” value=”variableValue”/>`

XML Syntax: `<SETVAR NAME=”variableName” VALUE=”variableValue”/>`

Example:

`<ics:setvar name=”errno” value=”0″/>`

### Tag for setting the session variable:
`SETSSVAR` is the tag for setting a session variable. The syntax is given below for both xml and jsp:

JSP Syntax: `<ics:setssvar name=”variableName” value=”variableValue”/>`

XML Syntax: `<SETSSVAR NAME=”variableName” VALUE=”variableValue”/>`

Example:

`<ics:setssvar name=”preferred_locale”  value='<%=ics.GetVar(“default:locale:id”)%>’/>`

### IF/THEN/ELSE:
This is one of the most common tag used by the object oriented programmers. The working of the construct is similar to that of other language constructs (like java,c, c++,etc). However, it has a different syntax compared to others. Lets see the syntax.

JSP Syntax:
```jsp
<ics:if condition=”logical expression”>
<ics:then>
tags or text
</ics:then>
<ics:else>
tags or text
</ics:else>
</ics:if>
```

XML Syntax:
```xml
<IF COND=”LOGICAL_EXPRESSION”>
<THEN>
tags or text
</THEN>
<ELSE>
tags or text
</ELSE>
</IF>
```

Example:
```jsp
<ics:if condition='<%=ics.GetList(“a:mypage”) == null%>’>
<ics:then>
No values available for this attribute
</ics:then>
<ics:else>
<ics:listloop listname=”a:mypage”>
<ics:listget listname=”a:mypage” fieldname=”value” output=”mypage_id”/>
</ics:listloop>
</ics:else>
</ics:if>
```

### LOOP:
This is the looping construct of FATWIRE. This tag is used to iterate through items in a list. Remember that excess code within these tags affects the performance of the template. Lets see the syntax.

JSP Syntax:

```jsp
<ics:listloop   listname=”some list” [maxrows=”number of loops”] [startrow=”start row”] [endrow=”end row”]/>
```

XML Syntax:
```xml
<LOOP [FROM=”START”] [COUNT=”LOOP_TIMES”] [LIST=”LIST_NAME”] [UNTIL=”END”]>
…
</LOOP>
```
Example:
```jsp
<ics:listloop listname=”a:mypage”>
<ics:listget listname=”a:mypage” fieldname=”value” output=”mypage_id”/>
</ics:listloop>
```

### `render:satellitepage`
This tag is used to insert another page as a pagelet. This page is something which has been created by a siteentry. We can pass arguments to the page using `render:argument` tag. This tag will invoke the page specified by the pagename parameter of this tag.

Example:
```jsp
<render:satellitepage pagename=”Sample\Header”>
   ...
</render:satellitepage>
```
### `render:callelement`
Say if I want to call someother element from my page, to perform some logic, we can use this `render:callelement` tag. This tag will invoke the element specified in the elementname parameter.

Here, elementname is a required field, and scoped is an optional field. The possible values for scoped field are local, stacked, global.

Example:
```jsp
<render:callelement elementname=”Sample\BusinessLogic” scoped=”global”>
    <render:argument name=”variable1″ value=”value” />
</render:callelement
```

### `render:calltemplate`
If I want to call another template from my template, to display some pagelet / perform some logic, then we should use this `render:calltemplate` tag. This tag will invoke the template specified in the tname /  tid field.

Here, we have three required fields : `site`, `slotname`, `tid`.

The optional fields are as follows: `tname`, `ttype`, `c`, `cid`, `context`, `style`

The style field helps us in determining whether this tag is going to invoke the template as a pagelet or as an element. The possible values of style field are: pagelet, element, embedded. If embedded is the value of style field, then the template is going to be called as a pagelet, without being cached as an independent page in satellite server.

Example:
```jsp
<render:calltemplate
site='<%=ics.GetVar(“site”)%>’
slotname=”MainBodySlot”
tid='<%=ics.GetVar(“tid”)%>’
ttype=’Template’
c='<%=ics.GetVar(“c”)%>’
cid='<%=ics.GetVar(“cid”)%>’
tname'<%=ics.GetVar(“templateName”)%>’ >
<render:argument name=”variable1″ value=”value” />
</render:calltemplate>
```

### `asset:load`
This tag queries the database for the asset which is specified in the type field, along with the objectid. Then loads the asset into the memory. This tag is to be used only with Basic assets. Or else, performance issues may arise. To load flex assets, use `assetset:setasset` tag.

Example:
```jsp
<asset:load name=”sample” type=”sampleassettype” field=”samplefield” value=”value” site=”sitename” deptype=”exists” />
```

### `asset:get`
This tag gets a single attribute value from the asset, which has been loaded earlier into the memory using `asset:load`

Example:
```jsp
<asset:get name="Article1" field="description" output="headline"/>
<ics:getvar name="headline"/>

<asset:get name="Article1" field="abstract" />
<ics:getvar name="abstract"/>
```

### `asset:scatter`
Retrieves and scatters all the field values from the object loaded in the memory using `asset:load`

Example: scatter vs get
```jsp
<asset:scatter name=”MainArticle” prefix=”main” />
<ics:getvar name=”first:name”/>,

<asset:load name=”NewsSectionFront” type=”Page” field=”name” value=”News” site='<%=ics.GetVar(“site”)%>’/>
<asset:get name=”NewsSectionFront” field=”name” />
<asset:get name=”NewsSectionFront” field=”description” />
<ics:getvar name=”name”/>,
```

### `asset:children`
After loading the asset with `asset:load`, the `asset:children` tag is used to load the children of that particular asset. This tag queries the `AssetRelationTree` table and builds the children list.

Example:

This code retrieves the page assets that has been associated under LatestNews association with the parent. This code is to be used only after `asset:load`.

`<asset:children name=”HomePage” list=”LatestPages” objectype=”page” code=”LatestNews”/>`

This code retrieves the page assets that have been associated under LatestNews association with the asset specified in the assetid field. This code can be used without loading the asset:

`<asset:children type=”Page” assetid='<%=ics.GetVar(“cid”)%>’ list=”LatestNewQuery” objectype=”Query” code=”LatestNews”/>`

### `render:logdep:`

This is the most common tag, that every Fatwire programmer knows. This tag is used in situations, in which your code can obtain an asset’s data without actually loading the asset.In such a case, be sure to log the compositional dependency yourself with the render:logdep tag. According to the Developer’s guide, **Use the `RENDER.LOGDEP` tag if your template uses tags that obtain an asset’s data without loading the asset, such as` ASSET.CHILDREN`.**

At the beginning of the element for each CSElement asset, you include the following line of code:
`<render:logdep cid=”Variables.eid” c=”CSElement”/>`

At the beginning of the element for a Template asset, the render.logdep statement would be as follows:
`<render:logdep cid=”Variables.tid” c=”template”/>`

When you try to create a Template or a CSElement, Content Server automatically includes an appropriate `render:logdep` statement in the code.

The following is the syntax for `render:logdep`:

JSP Syntax:

`<render:logdep asset=”asset name” cid=”asset id” c=”asset type”/>`

XML Syntax:

`<RENDER.LOGDEP ASSET=”asset name” CID=”asset id” C=”asset type”/>`

### `render:unknowndeps:`

Use the `<render:unknowndeps/>` tag when there are dependent assets but that there is no way to predict the identities of those assets because they came from a query or change frequently. You use this tag to cover those coding situations in which you truly cannot determine what the dependent assets might be.

When a compositional dependency is set to “unknown,” it means the page must be regenerated during each Export to Disk publishing session and updated in the page caches after each Mirror to Server publishing session, whether it needs it or not. This tag causes the page or pagelet to be regenerated at every publish because the dependencies cannot be determined. This means that you should use this tag sparingly.

This tag logs a compositional dependency of “unknown” for the rendered page.

The following is the syntax for logdep:

JSP Syntax:

`<render:unknowndeps/>`

XML Syntax:

`<RENDER.UNKNOWNDEPS/>`

You must use this tag carefully because the more pages that must be regenerated, the longer it takes to publish your site.

### `render:lookup`

The `render:lookup` tag is one of the important tag, which is used in looking up a  map value for a given Template or CSElement. We will now see the syntax of this tag, and its usage.

**USAGE:** This `render:calltemplate` tag is used to Look up a map value for a given Template or CSElement.

**SYNTAX:**
The following is the JSP syntax of the `render:calltemplate` tag. This is in reference with the “Tag Reference” guide.
```jsp
<render:lookup
        key="name of lookup key"
        varname="output variable name"
        site="site name"
       [tid="id of template or cselement"]
       [ttype="CSElement|Template"]
       [match="x|x:|:x"]
/>
```
We will now discuss the some important arguments which are specified above.

1. Key:  The name of the key corresponding to the value. The key is the only thing that can be hard-coded in a template; hard-coding asset names, types, or values is discouraged.

2. Varname: The output variable name to contain the value corresponding to the key.

3. Site: The name of the site corresponding to this mapping. (mapped values differ across sites).

4. Tid: The id of the template that owns the mapping (defaults to the id of the current template). If this tag is present in a CSElement, then the default is the CSElement id, and ttype must be set to CSElement.

Example usage of `render:callelement`:
```jsp
<%-- Look up the name of the layout template --%>
<render:lookup
        site='<%=ics.GetVar("site")%>'
        varname="LayoutVar"
        key="Layout" 

<%-- Look up the name of the wrapper page's site entry.
     Note we want the asset name only, so we must specify
     the match filter. --%>
<render:lookup
        site='<%=ics.GetVar("site")%>'
        varname="WrapperVar"
        key="Wrapper"
        match=":x"/>
```

### `assetset:setasset`

To load and get the attributes from a flex asset it is recommended to use the `assetset:setasset` tag.

Syntax
```jsp
<assetset:setasset
      name="assetsetname"
      type="assettype"
      id="assetid"
      [locale="localeobject"]
      [deptype="exact|exists|none"]/>
```

The `assetset:setasset` is similar to `asset:load` in a sense that it returns the reference to the flexasset as name and the type parameter is for the type of the flex asset as it is in `asset:load`.

The id is the asset id of the flex asset. There is no parameter for field and value because it is a flex asset which can have attributes as asset type.

Example

Loading a flex asset of type `Article_C` representing an article.

```jsp
<assetset:setasset
      name="articleAsset"
      type="Article_C"
      id='<%=ics.GetVar(“cid”)%>'/>
```
   * If `cid` is the article asset id.

### `assetset:getattributevalues`

Assetset is the basic tag to load a flex asset and the first step to get/manipulate the attribute(s) of a flex asset. Once the asset is loaded tags like `assetset:getattributevalues` and `assetset:getmultiplevalues` can be used to retrieve attribute value(s).

Retrieving value(s) from an attribute of a flex asset can be achieved by using `assetset:getattributevalues` tag.

Syntax
```jsp
<assetset:getattributevalues
      name="assetset name"
      attribute="attribute name"
      listvarname="list name"
      [typename="attribute asset type name"]
      [immediateonly="true|false"]
      [ordering="ascending|descending"]/>
```
The name parameter represents the name of the asset that is loaded, for example the articleAsset flex asset we loaded above. In attribute parameter give the name of the flex attribute.

`listvarname` gets the name of the list which stores the value(s) of the attribute. It can be an already existing list or a new list.

Example

After we have loaded flex asset article we want to get its attribute named Body which represents the main body of article.
```jsp
<assetset:getattributevalues
      name="articleAsset"
      attribute="Body"
      listvarname="bodyList"
      typename="articleAsset_A"/>
```
The typename is for the attribute type. So, in our example the attribute type is `articleAsset_A`.

### Other Important Tags

1. `<ics:geterrno/>` or `ics.GetErrno` - Get error number, if error number is not equal to Zero, something error occured. One can check againt errno description here.
```jsp
<asset:load name="thisAsset" field="name" value="SomeAssetName"/>
if(ics.GetErrno == 0) success
else print error
```

2. `<ics:LogMsg>` or `ics.LogMsg` - To print any info in logs. Use with `<ics:debug>` tag.

3. `<time:set>` and `<time:get>` - Finding time response for any particular Template/CSElement in milliseconds. Enable `logging.cs.time=DEBUG`
```jsp
<time:set name="timeVar"/>
//Call template
<time:get name="timeVar" output="elapsedTime"/>
```

4. `<string:stream>` - This tag is important when you want text to be shown as exactly as its saved in database. Useful in case of translated asset as it take cares of all other characters which contains diacrtic for other languages like spanish. Furthermore, this tag can retreive value from both ics variable and IList.

5. `<render:stream>` - All body or summary attributes which may contain hyperlinks or embedded asset can be rendered properly with use of this tag. Similarly, like `<string:stream>` tag, it can also take both ics variable and IList tag.

6. `<asset:children>` - It can find associated assets to an asset without loading the asset.

7. `<asset:filterassetsbydate>` - Very important tag when you want to show versions of an assets. It acts on basis of end date and start date. Read full details here.

8. `<asset:setdimparents>`, `<asset:getdimparents>` and `<asset:removedimparents>` are bunch of tags to set translation for asset, gets dimensionable asset parents and removes dimensional asset parents respectively.

9. `<asset:getassettypeproperties>` - Get all the properties related to assets as described here.

10. `<asset:getlocale>` and `<asset:locales>` - Get asset locale/s.

11. `<asset:getsubtype>` - Get subtype (definition) of an asset. Usually used in layout template for dispatching request to correct template.

12. `<asset:load>`, `<asset:get>` and `<asset:scatter>` - Tags related to Basic asset details

13. `<assetset:*>` - Tags related to Flex asset details

14. `<searchstate:*>` - Tags related to searching flex assets

15. `<asset:revision>` and `<asset:rollback>`: Useful when something goes wrong with batch update/edit and saving assets.

16. `<asset:edit>`, `<asset:checkout>`, `<asset:save>` and `<asset:undocheckout>` - useful during mass editing and saving assets.

17. `<asset:search>` and `<asset:list>` - Tags related to searching basic assets

18. `<asset:delete>`, `<asset:deleterevision>` and `<asset:void>` - Tags related to deleting assets

19. `<render:logdep>` and `<render:unknowndeps>` - Tags for generating dependencies.

20. `<ics:sql>`, `<ics:callsql>`, `<ics:sqlexp>` and `<ics:selectto>` - Tags to get data drom database.

21. `<insite:*>` - In-context editing tags

22. `<ics:getproperty>` and `<property:get>` - Get property from properties files

23. `<render:*>` and `<satellite:*>` - Mostly all tags are used to render content. Note: use ics tags if asset is not rendered. For e.g. if your CSElement is just performing some calculation and NOT rendering any data, then use `ics:callelement` rather than `render:callelement`.

24. `<ics:setssvar>`, `<ics:getssvar>` and `<ics:removessvar>` - Session related tags

25. `<dimensionset:filter>` and `<dimensionset:filtersingleasset>` - Gets translation of asset/s by applying dimensionset filter

26. `<listobject:*>`, `<ics:listget>` and `<ics:listloop>` - List tags

27. `<ics:if>`, `<ics:then>` and `<ics:else>` - Conditional tag. Note: Don't use `<ics:if>` alone, you always with <ics:then>

28. `<render:packargs>` and `<render:unpackarg>` - Send args in form of one string and retreive them later by unpacking them. Usage depends on different situations, check tag library.

29. `<satellite:cookie>` and `<ics:getcookie>` - Cookies related tags

30. `<vdm:*>` and `<commercecontext:*>` - Engage related tags

31. `<siteplan:*>` - Tags related to loading siteplan tree

32. `<satellite:normalizeurl>` - Generates satellite safe url

33. `<proxy:*>` - Tags related to proxy asset

### References

* [kksays 1](https://kksays.wordpress.com/2012/12/17/important-tags-in-fatwire-with-usage-examples/)
* [kksays 2](https://kksays.wordpress.com/2012/02/07/important-tags-in-fatwire-part-1/)
* [kksays 3](https://kksays.wordpress.com/2012/02/09/important-tags-in-fatwire-part-2/)
* [kksays 4](https://kksays.wordpress.com/2012/02/09/important-tags-in-fatwire-part-3/)
* [kksays 5](https://kksays.wordpress.com/2012/02/07/how-to-use-the-render-lookup-tag-in-fatwire/)
* [manifesto](https://manifesto.co.uk/important-fatwire-webcenter-sites-tags/)
* [fatwirecode](https://fatwirecode.blogspot.in/2015/07/important-list-of-tags.html)
* [JSP Tags](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/JSP/TOC_annotated.html)
* [XML tags](https://docs.oracle.com/cd/E29542_01/apirefs.1111/e39371/XML/TOC_annotated.html)